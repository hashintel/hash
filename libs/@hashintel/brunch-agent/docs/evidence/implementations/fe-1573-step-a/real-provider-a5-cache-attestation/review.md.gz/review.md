# Focused independent A5 terminal/transport re-review

## Disposition

**The exact original missing-final-output-usage blocker and retention-callback cleanup failure are corrected at the tested boundary. A remaining raw-attestation accounting blocker is independently reproduced: accepted input/cache evidence can still normalize to understated billing, release the US$7 hold, and allow a second request.** This is not an acceptance claim for generic normalized-only production accounting.

Reviewed HEAD `9cef6310816e9e630851c7df2c188039df2f6077`, code commits `7b167f5328796d9ed988bb3c926c3c5c6a1b7d86` and `2610b4d3f321a60c0497c6d74bf28ee4b57d6ab2`, evidence `7d86df283b2ac330cd5e187c357117610b517352`. Applicable AGENTS/MISSION were read in the original review and verified unchanged since that review. No source edits, installs, rebuilds, real-mode launches, live ledger reads, credential checks, external DNS, real HTTPS connections or paid calls occurred. All execution used the identity-checked deny-network profile. Tests use synthetic auth and HTTPS events, not real TLS.

## Confirmed remaining blocker: input/cache attestation does not protect normalized billing

`apps/brunch-agent/src/evaluations/real-provider-a5/native-response.ts:19–42,95–97,110–116` validates input/cache counters individually but preserves neither their cross-frame consistency nor correspondence to counters the installed Pi parser actually consumes. Only output usage has an explicit regression check. `transport.ts:98–99` treats successful attestation as sufficient to release raw bytes to Pi; the driver uses the same attester.

Two small synthetic mutations of the legitimate existing mounted fixture passed through **actual built ChatAgent registration, native provider/SDK, real-mode `pinnedNativeRequest`, admission, and RequestLedger**:

| Discriminator | Actual first settlement | Second request |
| --- | --- | --- |
| Initial input100/output1; terminal output20 plus `input_tokens: 0` | `complete`, input0/output20, US$0.0003, hold0. The earlier explicit input100 disappears. | Successful; second HTTPS dispatch counted. |
| Initial input100/output1; terminal output20 plus `cache_creation_input_tokens:100`, `cache_creation:{ephemeral_1h_input_tokens:100,ephemeral_5m_input_tokens:0}` | `complete`, input100/output20/cacheWrite100/**cacheWrite1h0**, US$0.000975, hold0. Raw native evidence says those 100 cache-write tokens are one-hour writes; the corresponding catalogue total would be US$0.0012. | Successful; second HTTPS dispatch counted. |

The installed parser updates input/cache totals from delta fields (`node_modules/@earendil-works/pi-ai/dist/api/anthropic-messages.js:540,546,549`) but sets `cacheWrite1h` only from `message_start` (`:390`). Thus the new attester accepts the later one-hour evidence while Pi silently drops that distinction. The unchanged ledger verifies the normalized estimator against itself and settles it.

These are malformed/ambiguous or SDK-unsupported-response discriminators, not a claim that Anthropic normally emits them. The required failure mode is still unknown accounting with US$7 held and refusal before a second dispatch—not accepted contradictory counters or silently discarded cost evidence. Both probes demonstrate the opposite. The cache case is independently consequential even if final input replacement semantics need owner/provider-contract interpretation.

**Necessary correction within this instrument:** do not certify a response when its raw cost-bearing input/cache evidence regresses inconsistently or cannot be represented faithfully by the unchanged parser. Preserve legitimate omitted/null delta input/cache behavior. Reject unsupported late one-hour-cache changes rather than manufacturing normalized counters or settlement. Add actual mounted negative controls requiring unknown/no `actualUsd`/US$7 held/next-dispatch refusal. No reply repair, context/output policy change, generic accounting rewrite or upstream infrastructure is required by this finding.

Evidence: `TEST-review-bypass-g4bjQZ/{input-regression,delta-one-hour-cache}-{first,second}.json`, `retained-native.json`, `result.json`, and `bypass-fixed-import.log` beneath this directory. `bypass.integration.ts` is a temporary derivative of the existing mounted probe: imports are rebased, two raw terminal payload mutations are added, and first/second outcomes are recorded instead of asserting the pre-existing cases. Native stream/parser, built registration, transport and accounting are not replaced. Its `passed:true` means diagnostic execution completed, **not** safety passed.

## Confirmed corrections and limits

- Existing focused suite: **26/26 passed**, including its mounted child. Independently reran the mounted file explicitly: **13 controls, 15 synthetic HTTPS dispatches, zero paid calls**. Both runs retained their own TEST outputs.
- Exact original missing-final-usage discriminator now fails the mounted submission, leaves one unknown entry with no actual cost and US$7 held, and blocks the next dispatch. HTTP201 missing usage has the same result. Missing output, null/string/negative/fractional/regressed output and missing stop likewise fail closed.
- Both incoming/outgoing socket errors with throwing retention callbacks now reject without the previous escaping exception. The shared `fail` path catches retention failure, clears the deadline and destroys the owned request (`transport.ts:49–62`). Unit controls and mounted ledger/next-dispatch controls passed. This is synthetic EventEmitter cleanup proof, not OS socket/real TLS fault proof; it does not certify every filesystem failure or process shutdown race.
- Legitimate final input100/output20 settles at US$0.0006, hold0, and allows a second counted request. Multiline CRLF SSE with nullable delta input/cache counters produces the same correct result. Observations were checked in the actual retained ledger, not only the green test count.
- The transport guard covers **every 2xx**, not only200. The driver's metadata callback still marks non200 responses stopped; it does not weaken the transport's all-2xx attestation. No live status behavior was tested.
- Source inspection confirms strict JSON and fatal UTF-8 parsing for recognized native events; event name must match payload type. Unknown/ping events cannot supply terminal evidence. One message start, terminal output delta and message stop must occur in order; duplicate start, recognized events after terminal/stop, missing lifecycle evidence and explicit error events refuse. Output usage is a nonnegative safe integer and cannot regress. This is message/billing lifecycle validation, not a comprehensive content-block protocol validator. The existing focused controls exercise ping spoofing and model identity; I did not claim every inspected malformed-frame branch was separately mounted-tested.
- Framing matches the installed parser's CR/LF/CRLF, multiline data, comments and EOF behavior by source comparison. CRLF/multiline behavior was additionally exercised at the mounted boundary. No successful response bytes are rewritten. Dry mode now calls the same attester; its synthetic response generator is unchanged. I did not rerun Chrome or real mode in this review.

## Identity and freeze status

`deny-network.sb` working-file and HEAD Git object identities both matched `ed8fca7b2aecc3c96b013e15094156be40018130`. Node was `/Users/lunelson/.local/share/mise/installs/node/22.21.1/bin/node`, version `v22.21.1`.

Compared all **3,312 pins** in `manifest-terminal-v3.json`, SHA-256 `6aeb50b2935a6cb7fdfb659ab1d0acad511c431ddcdefb3564bfaeafe245f068`, against current files. **Only `apps/brunch-agent/test/architecture/boundaries.integration.ts` differed**, as expected. This verifies the current source/build/dependency identities against that candidate except the known inventory insertion; it does **not** make v3 final. A worker-generated `real-provider-a5-final-freeze/` appeared untracked during the review and was preserved without inspection. I did not verify or accept any new final manifest. HEAD remained the requested revision; no reviewer-owned tracked changes were made.

## Exact execution commands and artifacts

Repository cwd: `/Users/lunelson/.herdr/worktrees/hash/m7-real-provider`. Commands record completed execution; do not rerun into existing outputs. All existing artifacts, including the failed import attempt, are retained.

```bash
git rev-parse HEAD
git status --short
git diff --stat f93d62a5404dcd3379971dc5940b59e610f18586 HEAD
git hash-object libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
command -v node
node --version

OUT=$(mktemp -d /tmp/a5-focused-review.XXXXXX)
echo "$OUT"
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
python3 - <<'PY'
import json,hashlib,pathlib
p=pathlib.Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/real-provider-a5-terminal-correction/manifest-terminal-v3.json')
b=p.read_bytes(); m=json.loads(b)
print('candidate sha256',hashlib.sha256(b).hexdigest(),'pins',len(m['files']))
for name,digest in m['files'].items():
 if hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()!=digest:print('DIFF',name)
PY
(cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5.test.ts) > "$OUT/focused-tests.log" 2>&1
echo tests=$?
TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node --experimental-strip-types apps/brunch-agent/test/real-provider-a5-terminal.integration.ts > "$OUT/mounted.log" 2>&1
echo mounted=$?
```

`OUT` was `/tmp/a5-focused-review.nVLNoh`; both tests/mounted exit codes were0. Mounted results are in `TEST-a5-terminal-7FPqf2/` and `TEST-a5-terminal-syv3Jk/`.

The complete probe-generation script is preserved as `make-probe.py`, and the final executed probe as `bypass.integration.ts`. Generation initially used nonexistent SDK `dist/index.js`; the resulting launch failed module loading, made no synthetic dispatch and is retained as `bypass.log`. The temporary probe's single import was corrected to the inspected actual export `dist/index.mjs`; neither repository source nor installed files changed. The generator remains unchanged as a record of the initial attempt, so the final probe is the authoritative executed artifact.

```bash
python3 /tmp/a5-focused-review.nVLNoh/make-probe.py
ls node_modules/@flue/sdk/dist/index.js
TMPDIR=/tmp/a5-focused-review.nVLNoh /usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-strip-types /tmp/a5-focused-review.nVLNoh/bypass.integration.ts > /tmp/a5-focused-review.nVLNoh/bypass.log 2>&1
echo bypass=$?
# Read node_modules/@flue/sdk/package.json; edit ONLY the temporary probe import:
# %40flue/sdk/dist/index.js -> %40flue/sdk/dist/index.mjs
TMPDIR=/tmp/a5-focused-review.nVLNoh /usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-strip-types /tmp/a5-focused-review.nVLNoh/bypass.integration.ts > /tmp/a5-focused-review.nVLNoh/bypass-fixed-import.log 2>&1
echo bypass=$?

git diff f93d62a5404dcd3379971dc5940b59e610f18586 HEAD -- AGENTS.md apps/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/MISSION.md
git status --short
git rev-parse HEAD
```

The corrected diagnostic exited0. `observed-summary.json` consolidates the retained mounted and bypass observations without replacing them.

## Authority and acceptance limits

No allocation, provider egress or paid activation is granted. Final policy, manifest and reservation decisions remain parent-owned. The original generic normalized-only RequestLedger weakness is unchanged and is not an accepted claim. This review establishes the exact original correction and cleanup controls, but the new raw-attestation counterexamples prevent an accounting-readiness conclusion for the proposed bounded paid instrument until locally addressed. No statement here establishes real TLS, provider acceptance, invoice accuracy, browser utility or mission acceptance.
