# Independent sibling-browser adapter review

## Result: one concrete cleanup blocker

**Normal sibling dry execution and the existing five failure/lifetime controls pass, but rejection of public `BrowserServer.close()` bypasses the advertised kill fallback and leaves the owned browser alive.** This is a bounded lifecycle defect, not a raw-accounting reopening.

At `apps/brunch-agent/src/evaluations/real-provider-a5/browser-owner.ts:118–128`, `Promise.race([server.close(), delayed server.kill()])` rejects immediately if `close()` rejects. Its `finally` then cancels the fallback timer. Execution skips cleanup verification/reporting and reaches the top-level failure handler, which sets exitCode but does not close the remaining library listener. The owner poll and lease timer have already been cleared. The launcher's later SIGTERM is not a reliable rescue: the owner handler only signals the already-resolved stop promise, and the launcher ultimately reports incomplete cleanup rather than closing Chrome (`launch.ts:204–215,272–280`).

### Independent discriminator

I launched the **actual owner and actual Chrome under its independent loopback root**, with a temporary fault hook that changes only the returned public server's `close()` to reject. The real public `kill()` was instrumented to record whether the production fallback invoked it. After requesting normal owner stop and waiting **6.5 seconds**, beyond the five-second fallback deadline:

```json
{
  "closeCalled": true,
  "killCalled": false,
  "ownerAlive": true,
  "chromeAlive": true,
  "profileExists": true,
  "cleanupExists": false,
  "readyExists": false,
  "ownerFailure": true
}
```

This is not a synthetic assertion about what the code might do: actual owner PID8358 and Chrome PID8362 remained alive with the isolated profile present. No application/provider/controller was started for this discriminator. It does not assert that normal Playwright shutdown commonly rejects, only that the promised bounded fallback fails on that error path.

After recording the failure, a **fault-hook-only** SIGUSR2 handler invoked the saved unmodified public close to clean up this test's known resources. The owner exited0 and both owner/Chrome were independently checked gone; the profile was gone. No residual test browser was intentionally left running. Original failure evidence remains in the owned run directory.

**Necessary local correction:** ensure both a rejected graceful close and a timed-out graceful close enter the bounded public kill path, then retain/report cleanup success or failure. Do not cancel the only fallback merely because close rejects. Add a rejection fault control distinct from a hung-close timeout. No generic daemon/process framework or accounting change is needed. Timeout-driven kill itself and kill-failure handling remain unproved by the current retained tests.

Evidence: `close-rejection-result.json`, `close-rejection-hook.mjs`, `close-rejection-probe.mjs`, `close-rejection.stdout`, `close-rejection.stderr`, and private session `/private/tmp/a5-sibling-review.J1ggxQ/brunch-a5-browser-wxLIjQ/`. The hook executes only in the loopback-guarded owner. It does not modify repository or installed files. The production owner source, public launchServer and real browser are unchanged except the explicitly injected close-method fault.

## Scope, authority and identities

Reviewed `/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving`, code `070cb6fb42df2568de04d7c79499ad4d29a0b011`, evidence/HEAD `3d4a5ebab5b083385d0b8a092ad375bd7d0134bd`. Worktree was clean before and after. Read the handoff/commands packet, ALPHA's topology decision and the exact MISSION sibling-adapter authority at `47ebb1ef57`. Standing AGENTS differences against previously read instructions were checked; no changes appeared. No checkout or alpha capacity-code intervention occurred.

Verified all eight source entries (including deleted old launcher), 106 built artifact hashes and 563 browser-library/profile/binary file pins. Separately verified 18 protected non-ledger hashes. **Did not read or verify the two cloned ledger/journal paths** in the protected pin list. These component pins are not a new final manifest. Deny profile working-file/HEAD Git object identity matched `ed8fca7b2aecc3c96b013e15094156be40018130`; the loopback profile is among verified component/protected pins. No profile rules were changed or paid profile opened.

No source edits, installation, rebuild, credential availability/validity check, external provider/DNS request, live-ledger access or paid invocation occurred. The old-activation unit test supplies the rejecting `real` argument parser under deny-network, as explicitly permitted; it never reaches a paid-profile or browser spawn. No valid real-mode run occurred. Ordinary orchestration was intentionally **not** wrapped in a parent deny-only/P443 root. All SDK/application/browser execution occurred inside independently applied loopback roots in these unpaid browser tests; filesystem-only unit checks used deny-network.

## Topology and readiness findings

- `launch.ts` and its session helper import only process/filesystem/identity facilities, not SDK/application/provider/network code. Actual SDK work begins in guarded children. The owner receives fixed PATH plus fresh private HOME/TMPDIR only; Chrome gets a newly constructed equivalent environment. The owner drops the known macOS runtime variable without reading its value, then rejects unexpected environment keys before importing Playwright.
- Owner uses public `chromium.launchServer` with explicit `127.0.0.1`, port0 and the installed library's random path. Driver uses public `chromium.connect(endpoint,{timeout:10000})`. No exposeNetwork/proxy/custom headers/arbitrary option forwarding or nested fallback appears. Dry and real share this connection path; only the proposed driver profile differs.
- Private canonical files enforce owner UID, file0600/directory0700 and no links. Run/execution, launcher/owner/Chrome PIDs, current library/profile/binary/source hashes, lease bounds, private browser profile and exact loopback/random-path endpoint are checked. Readiness is published by rename and sealed against the actual owner's child PID; driver and owner separately check actual parent PID. A private exclusive controller claim prevents consuming one binding twice.
- This is trusted same-user local coordination, **not authentication against a malicious process with the same UID or proof of arbitrary PID provenance from `kill(pid,0)` alone**. Its stronger provenance comes from the actual launcher-child wiring and trusted owner publication. No global execution-ID registry or generic security infrastructure is required by the present scope.
- Driver claims/checks the binding before application/native invocation, connects before loading the built application, and owns context close/disconnect. Real-mode credential availability resolution precedes claim but no underlying provider invocation is introduced there; I did not execute that branch. Endpoint capabilities do not enter model/page inputs through the reviewed wiring; private failure stacks can contain them and must remain private.
- Manifest delta adds browser libraries and current topology identity verification, not a freeze. UI/scenario/canonical result flow, raw transport/attestation/accounting and repair semantics are preserved in the inspected delta and protected hashes. The obsolete nested launcher is removed. I found no concrete unnecessary mechanism that could simply be removed while retaining these current identity/lifetime obligations; line count is not a finding.

## Existing tests versus fresh observations

### Existing tests freshly rerun

- Focused filesystem/identity/old-activation suite: **22/22 passed** under deny-network.
- Existing integrated dry through the actual new launcher: **five synthetic native dispatches**, TEST estimateUS$0.003, no rejected operation, blocked origin or browser/listener error. This is actual browser/read-result continuation, not real provider acceptance or A5 construction/explanation success.
- Existing five failure/lifetime controls: **foreign execution, attach failure, lease expiry, owner interrupt, real launcher early interrupt** all passed. Foreign/attach controls checked empty TEST ledgers and no native artifacts; lifetime controls involved no provider-capable controller work. These establish their concrete zero-dispatch cases, not a universal failure claim.

### Independently inspected results

Read fresh `dry/browser-lifecycle.json`, `dry/driver-result.json`, and `lifecycle/result.json`. Normal cleanup reports owner/driver/Chrome gone, isolated profile and readiness/binding removed, endpoint ECONNREFUSED. Independently called `kill(pid,0)` for the normal run's three recorded PIDs after completion: all were gone. Existing lifecycle tests additionally perform their own fresh loopback-guarded endpoint refusal audits on the four direct-owner controls; the launcher-interrupt case checks its orchestration report.

The added close-rejection test exposed the missing failure path despite these green controls. Endpoint liveness was not separately probed during that added fault; actual surviving owner/Chrome and profile suffice for the concrete cleanup failure. No screenshot/semantic utility adjudication, exhaustive descendant enumeration, orchestrator-SIGKILL/power-loss guarantee, or paid-controller-to-loopback-owner attachment was performed. Normal close was exercised; timeout-triggered forced kill was not.

## Fresh artifacts and exact commands

All reviewer outputs: `/tmp/a5-sibling-review.J1ggxQ/`. Only session directories created beneath that owned TMPDIR were inspected. Unrelated capsules/private ephemeral files were not accessed. `observations.json` consolidates the freshly read normal/lifecycle outputs without replacing originals.

Commands below record completed execution, not instructions to overwrite those artifacts. Repository cwd for every command was `/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving`.

```bash
cd /Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
pwd
git rev-parse HEAD
git status --short
git show --stat --oneline 070cb6fb42df2568de04d7c79499ad4d29a0b011

OUT=$(mktemp -d /tmp/a5-sibling-review.XXXXXX)
echo "$OUT"
python3 - <<'PY'
import pathlib,json,hashlib
r=pathlib.Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/real-provider-a5-sibling-browser')
for name in ['source-review-pins.json','built-review-pins.json','browser-library-review-pins.json','protected-unchanged-pins.json']:
 d=json.loads((r/name).read_text()); print(name,'keys',list(d))
 for p,h in d.get('files',{}).items():
  if 'ledger' in p: print('SKIP ledger/journal',p);continue
  q=pathlib.Path(p)
  if h is None: assert not q.exists(),p
  else: assert hashlib.sha256(q.read_bytes()).hexdigest()==h,p
 print('file pins checked',len(d.get('files',{})))
PY
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
git hash-object "$PROFILE"
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
(cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5-browser.test.ts) > "$OUT/unit.log" 2>&1
echo unit=$?
TMPDIR="$OUT" node --experimental-strip-types apps/brunch-agent/src/evaluations/real-provider-a5/launch.ts dry "$OUT/dry" > "$OUT/dry.stdout" 2> "$OUT/dry.stderr"
echo dry=$?
TMPDIR="$OUT" node --experimental-strip-types apps/brunch-agent/test/real-provider-a5-browser.integration.ts "$OUT/lifecycle" > "$OUT/lifecycle.stdout" 2> "$OUT/lifecycle.stderr"
echo lifecycle=$?
```

All three returned0. The first pin loop correctly handled the three wrapped pin maps; the protected map uses a different shape and was separately checked below, excluding both ledger/journal entries:

```bash
cd /Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
python3 - <<'PY'
import pathlib,json,hashlib
r=pathlib.Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/real-provider-a5-sibling-browser')
d=json.loads((r/'protected-unchanged-pins.json').read_text());checked=[]
for p,h in d.items():
 if 'ledger' in p:continue
 assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h,p
 checked.append(p)
print('protected nonledger pins checked',len(checked))
PY

git diff 070cb6fb42^ 070cb6fb42 -- apps/brunch-agent/src/evaluations/real-provider-a5.ts apps/brunch-agent/src/evaluations/real-provider-a5/manifest.ts
git show 47ebb1ef57:libs/@hashintel/brunch-agent/MISSION.md | grep -A5 -B2 'Sibling-browser adapter'
git diff 923394c119 070cb6fb42 -- AGENTS.md apps/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/AGENTS.md
```

The complete independent fault source is preserved as `close-rejection-hook.mjs` and `close-rejection-probe.mjs`. Its orchestration imports only Node/session helpers outside guards; it spawns the production owner under loopback with a test-only preload. Its cleanup escape hatch invokes the saved original public close only after recording the production failure.

```bash
cd /Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
TMPDIR=/tmp/a5-sibling-review.J1ggxQ node --experimental-strip-types /tmp/a5-sibling-review.J1ggxQ/close-rejection-probe.mjs > /tmp/a5-sibling-review.J1ggxQ/close-rejection.stdout 2> /tmp/a5-sibling-review.J1ggxQ/close-rejection.stderr
echo probe=$?
git status --short
```

The diagnostic returned0 after preserving the failed production cleanup and completing its own rescue cleanup. That exit is **not** a safety pass; `close-rejection-result.json` is the discriminator.

## Parent-held gates

Correct/review the bounded close-rejection fallback before relying on lifecycle closure. Then the parent owns any final merged build/freeze, policy decision, named reservation/sole writer and invocation. Actual paid-controller → independent loopback owner attachment and native pinned TLS remain subsequent explicitly allocated checks, not inferred from dry operation. No final freeze, provider acceptance, utility, budget activation or mission verdict is supplied here.
