import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {existsSync,writeFileSync,readFileSync,openSync,closeSync} from 'node:fs';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {createBrowserSession,loopbackProfile,repositoryRoot} from 'file:///Users/lunelson/.herdr/worktrees/hash/m7-provider-proving/apps/brunch-agent/src/evaluations/real-provider-a5/browser-session.ts';
const session=createBrowserSession('TEST-close-rejection');
const stdout=openSync(join(session.directory,'TEST-owner.stdout'),'wx',0o600);
const stderr=openSync(join(session.directory,'TEST-owner.stderr'),'wx',0o600);
const child=spawn('/usr/bin/sandbox-exec',['-f',loopbackProfile,process.execPath,'--experimental-strip-types','--import','/tmp/m7-close-rejection-owner.WgsOCX/close-rejection-hook.mjs',join(repositoryRoot,'apps/brunch-agent/src/evaluations/real-provider-a5/browser-owner.ts'),join(session.directory,'session.json')],{cwd:repositoryRoot,env:{PATH:'/usr/bin:/bin',HOME:join(session.directory,'home'),TMPDIR:join(session.directory,'tmp')},stdio:['ignore',stdout,stderr]});
closeSync(stdout);closeSync(stderr);
let exit; const exited=new Promise(resolve=>child.once('exit',(code,signal)=>{exit={code,signal};resolve(exit);}));
const alive=pid=>{try{process.kill(pid,0);return true;}catch{return false;}};
let readiness;let observation;
try{
 const deadline=Date.now()+15000;
 while(!existsSync(join(session.directory,'ready.json'))){assert(!exit&&Date.now()<deadline,'Owner did not become ready');await delay(50);}
 readiness=JSON.parse(readFileSync(join(session.directory,'ready.json')));
 writeFileSync(join(session.directory,'stop'),'TEST stop',{mode:0o600});
 await delay(6500);
 observation={sessionDirectory:session.directory,ownerPid:child.pid,chromePid:readiness.chromePid,closeCalled:existsSync(join(session.directory,'TEST-close-called')),killCalled:existsSync(join(session.directory,'TEST-kill-called')),ownerAlive:alive(child.pid),chromeAlive:alive(readiness.chromePid),profileExists:existsSync(readiness.profilePath),cleanupExists:existsSync(join(session.directory,'cleanup.json')),readyExists:existsSync(join(session.directory,'ready.json')),ownerFailure:existsSync(join(session.directory,'owner-failure.json'))};
}finally{
 // Fault-hook-only escape hatch invokes the unmodified public close to clean up
 // our known test owner/browser after retaining the failed production behavior.
 if(!exit)child.kill('SIGUSR2');
 const final=await Promise.race([exited,delay(10000).then(()=>null)]);
 assert(final,'TEST cleanup did not finish');
 if(readiness){assert(!alive(readiness.chromePid));assert(!existsSync(readiness.profilePath));}
 writeFileSync('/tmp/m7-close-rejection-owner.WgsOCX/close-rejection-result.json',JSON.stringify({...observation,testCleanupExit:final,testOwnerGone:!alive(child.pid),testChromeGone:readiness?!alive(readiness.chromePid):null},null,2),{flag:'wx',mode:0o600});
}
