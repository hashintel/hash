import { chromium } from 'file:///Users/lunelson/.herdr/worktrees/hash/m7-provider-proving/node_modules/@playwright/test/index.mjs';
import {writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
const originalLaunch=chromium.launchServer.bind(chromium);
chromium.launchServer=async(...args)=>{
 const server=await originalLaunch(...args);
 const originalClose=server.close.bind(server);
 const originalKill=server.kill.bind(server);
 const directory=dirname(process.argv[2]);
 server.close=async()=>{writeFileSync(join(directory,'TEST-close-called'),'yes');throw new Error('TEST injected public close rejection');};
 server.kill=async()=>{writeFileSync(join(directory,'TEST-kill-called'),'yes');return originalKill();};
 process.once('SIGUSR2',()=>{void originalClose().then(()=>process.exit(0),()=>originalKill().then(()=>process.exit(0)));});
 return server;
};
// This fault hook runs only in the credential-free LP child. Undo library-local
// environment flags before the production owner's minimal-env check.
for(const key of Object.keys(process.env)) if(!['PATH','HOME','TMPDIR','__CF_USER_TEXT_ENCODING'].includes(key)) delete process.env[key];
