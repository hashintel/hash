# Focused independent public-browser shutdown correction review

## Result

**No remaining blocker found in this bounded shutdown correction.** The exact previous close-rejection failure now invokes the real public kill and achieves production cleanup without TEST rescue. A never-resolving close also reaches that fallback after its separate five-second deadline. Rejected/never-resolving public kill are correctly retained as **incomplete production cleanup**, not converted into successful closure by the later TEST rescue.

This conclusion does not promise resource termination when both public shutdown avenues fail, accept merged source/runtime alignment, freeze an instrument, or authorize paid execution.

## Scope and identities

Reviewed `/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving`, code `c9f8ced5eca31bc177539d185c2b4addd97f99eb`, evidence/HEAD `20bc9501c73db52efc342aadd7af0add7dc8977c`. The worktree was clean before/after. Compared the exact production delta and read both new focused fault files plus the correction handoff. Applicable AGENTS/MISSION in this worktree are unchanged since the previous review; the user-directed scope remains the bounded shutdown correction, not ALPHA capacity integration.

Verified three correction source pins, 24 protected non-ledger pins, 106 inherited build pins and 563 inherited browser-library/profile/binary pins. Loopback profile working-file/HEAD Git object identity matched `0d1293fdabe4966df213bb8844a81508eea77b83`. The already-reviewed deny profile is covered by protected component pins. No final manifest was generated or accepted.

No repository/installed source edits, build, install, real-mode launch, paid-profile opening, credential/auth probe, external DNS/provider request or live-ledger access occurred. Ordinary orchestration remained process/filesystem-only; all Playwright/Chrome/socket audits ran under independently applied loopback roots. Binding unit tests ran under deny-network. The permitted old-activation negative test refuses before spawning guarded children; no valid real-mode invocation occurred. All new outputs are beneath `/tmp/a5-shutdown-review.VO4MrM/`.

## Correction inspection

`browser-owner.ts:113–161` now turns each public shutdown operation into an observed `complete`, `rejected` or `timeout` outcome. Rejection is handled inside the operation promise; it no longer escapes the race and cancels the sole fallback. Both rejected and timed-out graceful close trigger a new, separately bounded invocation of public kill. Each stage owns and clears its own five-second timer. A synchronous method throw is also handled by the promise chain by source inspection; the fresh fault tests injected promise rejection/hang, not a separate synchronous-throw case.

`browser-owner.ts:194–223` writes both actual method outcomes, errors and physical resource observations before asserting cleanup success. `cleanupComplete` requires Chrome gone, profile removed, readiness removed, endpoint refusal, and a successful public close or kill outcome. Rejection/timeout cannot be mistaken for a successful method result. Error names/messages/stacks remain in private cleanup evidence, followed by the existing private owner-failure record when cleanup is incomplete.

The unchanged launcher requires owner exit0 plus resource cleanup observations; it does not clear accounting or retry model work. This correction changes no driver/native/accounting path. Unknown accounting is neither reconciled nor released by browser shutdown. No accounting regression claim beyond unchanged protected source and the existing dry path is made.

## Fresh actual observations

### Exact previous discriminator

Reused the original reviewer hook and probe logic, changing only the result-output filename to avoid overwriting the original failure. Actual owner PID65172 / Chrome PID65180: close called, **kill called**, owner and Chrome gone, profile/readiness absent, cleanup report present, no owner failure. The production owner exited0 before the probe's rescue check, so its TEST SIGUSR2 rescue branch was not used. This directly reverses the old observation of surviving owner/Chrome/profile and no kill invocation.

Artifact: `prior-close-rejection-result.json`. The original red at `/tmp/a5-sibling-review.J1ggxQ/` remains untouched.

### Four new fault controls

All use actual owner/Chrome and public launchServer. Positive fallback cases delegate to the saved real public kill; negative cases deliberately reject/hang that public method. Independent endpoint audits run in their own loopback child. Read each production observation **before** considering test-cleanup results:

| Control | Close → kill invocation | Production observation | TEST rescue |
| --- | --- | --- | --- |
| Close rejects | 0.313ms | Close rejection/error retained; kill complete; cleanupComplete true; production exit0; owner/Chrome/profile gone; endpoint ECONNREFUSED | Not used |
| Close never resolves | 5001.766ms | Close timeout retained; kill complete; cleanupComplete true; production exit0; owner/Chrome/profile gone; endpoint ECONNREFUSED | Not used |
| Public kill rejects | 0.288ms | Both rejection errors retained; cleanupComplete false; owner failure; **no production exit**, owner/Chrome/profile alive, endpoint connected | Used afterward |
| Public kill never resolves | 0.274ms | Close rejection plus kill timeout retained; cleanupComplete false; owner failure; **no production exit**, owner/Chrome/profile alive, endpoint connected | Used afterward |

These invocation timings come from each owner's monotonic clock; they demonstrate the tested branch/deadline, not a performance guarantee. Kill timeout is separately bounded by code and its observed timeout report; it is not conflated with the close deadline.

The two negative rescue exits0 appear only in `test-cleanup.json`, after immutable production observations. Production cleanup remains false. I independently checked all four recorded owner/Chrome PIDs gone and profile paths absent after test completion, and read the guarded endpoint-after-rescue audits (all ECONNREFUSED). No test-owned browser was left running. The negative cases **do not establish successful production cleanup**.

### Existing regressions freshly rerun

- **22/22** binding/identity/old-activation unit tests pass.
- Actual integrated **dry5** passes: five synthetic native dispatches, TEST US$0.003, no browser/listener errors; graceful close complete, kill not needed, cleanupComplete true.
- All five existing lifecycle controls pass: foreign execution, attach failure, lease expiry, owner interrupt and launcher early interrupt.

I did not independently rerun the reported entire 337-test app suite, typecheck, lint or a build. Aggregate `passed:true` in the four-fault report means expected positive **and negative** assertions held, not that all production shutdown cases succeeded.

## Precise fallback limits

The correction closes the demonstrated rejected-close hole and the separately tested never-resolving-close path. It bounds waiting on close and kill, then checks actual resources. If public kill rejects or hangs, reporting is bounded but resource termination is **not guaranteed**: the actual owner/library listener and Chrome can remain alive. Existing failure evidence/launcher refusal makes this an explicit incomplete-cleanup stop requiring owner recovery, not a success or a safe automatic retry. The test-only saved-method rescue is not a production recovery mechanism.

No combined close-hang plus kill-hang timing test, arbitrary OS failure, blocked event loop, exhaustive descendant enumeration, orchestrator-SIGKILL/power-loss durability or universal orphan recovery is claimed. No broader mechanism is needed to discharge the specific reviewed correction, and no policy acceptance of those residual conditions is supplied here.

## Exact execution commands

Repository cwd: `/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving`. These record completed execution; preserve existing outputs rather than rerunning into their names.

```bash
cd /Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
git rev-parse HEAD
git status --short
git diff 070cb6fb42 c9f8ced5 -- apps/brunch-agent/src/evaluations/real-provider-a5/browser-owner.ts
git show --stat --oneline c9f8ced5
git hash-object libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/loopback-only.sb
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/loopback-only.sb

OUT=$(mktemp -d /tmp/a5-shutdown-review.XXXXXX)
echo "$OUT"
python3 - <<'PY'
from pathlib import Path
import hashlib,json
root=Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a')
for packet,name in [('real-provider-a5-shutdown-correction','source-review-pins.json'),('real-provider-a5-shutdown-correction','protected-nonledger-pins.json'),('real-provider-a5-sibling-browser','built-review-pins.json'),('real-provider-a5-sibling-browser','browser-library-review-pins.json')]:
 data=json.loads((root/packet/name).read_text()); files=data.get('files',data)
 print(name,'keys',len(files))
 for path,digest in files.items():
  assert 'usage-ledger' not in path and 'attempt-ledger' not in path
  if digest is None: assert not Path(path).exists(),path
  else: assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
 print('verified',name,len(files))
PY
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
(cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5-browser.test.ts) > "$OUT/unit.log" 2>&1
echo unit=$?
TMPDIR="$OUT" node --experimental-strip-types apps/brunch-agent/test/real-provider-a5-shutdown.integration.ts "$OUT/faults" > "$OUT/faults.stdout" 2> "$OUT/faults.stderr"
echo faults=$?
TMPDIR="$OUT" node --experimental-strip-types apps/brunch-agent/src/evaluations/real-provider-a5/launch.ts dry "$OUT/dry" > "$OUT/dry.stdout" 2> "$OUT/dry.stderr"
echo dry=$?
TMPDIR="$OUT" node --experimental-strip-types apps/brunch-agent/test/real-provider-a5-browser.integration.ts "$OUT/lifecycle" > "$OUT/lifecycle.stdout" 2> "$OUT/lifecycle.stderr"
echo lifecycle=$?
```

`OUT` was `/tmp/a5-shutdown-review.VO4MrM`; all four commands returned0.

```bash
cd /Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
python3 - <<'PY'
from pathlib import Path
old=Path('/tmp/a5-sibling-review.J1ggxQ/close-rejection-probe.mjs').read_text()
needle='/tmp/a5-sibling-review.J1ggxQ/close-rejection-result.json'
assert old.count(needle)==1
new=old.replace(needle,'/tmp/a5-shutdown-review.VO4MrM/prior-close-rejection-result.json')
with Path('/tmp/a5-shutdown-review.VO4MrM/prior-close-rejection-probe.mjs').open('x') as f:f.write(new)
PY
TMPDIR=/tmp/a5-shutdown-review.VO4MrM node --experimental-strip-types /tmp/a5-shutdown-review.VO4MrM/prior-close-rejection-probe.mjs > /tmp/a5-shutdown-review.VO4MrM/prior-probe.stdout 2> /tmp/a5-shutdown-review.VO4MrM/prior-probe.stderr
echo prior=$?
git diff 3d4a5ebab5 HEAD -- AGENTS.md apps/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/MISSION.md
git status --short
git rev-parse HEAD
```

Prior discriminator returned0; worktree remained clean at the requested HEAD. Its output name alone changed; original fault behavior and guarded-child placement were retained. `independent-summary.json` consolidates inspected fresh production/test-cleanup observations, exact error evidence, timings, normal dry results and prior-probe results. Original per-control records remain authoritative and unmodified.

## Parent-held next gates

Bounded shutdown correction is no longer blocked by this review. Merged capacity/source/runtime alignment, rebuilding and final freeze remain separate parent gates. Actual paid-root attachment/TLS, named reservation, egress acceptance, sole-writer invocation and any mission/utility acceptance remain parent-owned. No paid activation is granted.
