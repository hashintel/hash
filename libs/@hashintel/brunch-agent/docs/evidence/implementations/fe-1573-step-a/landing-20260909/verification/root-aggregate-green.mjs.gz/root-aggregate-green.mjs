import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {explainRootArc} from '/Users/lunelson/.herdr/worktrees/hash/alpha/apps/brunch-agent/src/conversation/why.ts';
import {parseConstructionWhyInput} from '/Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/brunch-agent/packages/plugin-sdcpn/dist/index.js';
const root='/Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/root-creation-post-capacity/browser-final';
const load=(name)=>JSON.parse(gunzipSync(readFileSync(`${root}/${name}.json.gz`)));
const snapshot=load('history'); const prior=load('why')[0];
const results=[];
for(const field of ['inputArcs','outputArcs','lambdaCode']) {
 const query=parseConstructionWhyInput({kind:'transition',name:'Test operation',field});
 const result=await explainRootArc({snapshot,current:prior.currentWorkpiece,browser:{binding:prior.binding,construction:true},query});
 results.push({query,result});
 console.log(JSON.stringify({field,value:result.target?.value,disposition:result.disposition,change:result.recordedChange?.toolCallId,reason:result.reason}));
}
writeFileSync('/tmp/m7-landing-20260909T055346Z/root-aggregate-green.json',JSON.stringify(results,null,2));
assert.equal(results[0].result.disposition,'refused','Current inputArcs with later independently recorded additions must not inherit empty transition creation basis');
assert.equal(results[1].result.disposition,'refused');
assert.equal(results[2].result.recordedChange?.toolCallId,'creation-pause');
