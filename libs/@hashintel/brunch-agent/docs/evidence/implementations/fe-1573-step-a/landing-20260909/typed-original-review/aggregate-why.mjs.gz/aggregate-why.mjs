import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {explainRootArc} from '/Users/lunelson/.herdr/worktrees/hash/m7-typed-state/apps/brunch-agent/src/conversation/why.ts';
import {parseConstructionWhyInput} from '/Users/lunelson/.herdr/worktrees/hash/m7-typed-state/libs/@hashintel/brunch-agent/packages/plugin-sdcpn/dist/index.js';
const root='/tmp/m7-typed-review.WjrqZt/primary';
const snapshot=JSON.parse(readFileSync(`${root}/history.json`));
const existing=JSON.parse(readFileSync(`${root}/why.json`))[0];
const results=[];
for(const query of [{kind:'scenario',name:'TestInitial',field:'initialState'},{kind:'scenario',name:'TestInitial',field:'/initialState/content/test-queue/1'},{kind:'scenario',name:'TestInitial',field:'/initialState/content/test-queue/1/0'},{kind:'scenario',name:'TestInitial',field:'/initialState/content/test-queue/1/1'},{kind:'type',name:'TestCorrectedAttributes',field:'elements'}]){
 const parsed=parseConstructionWhyInput(query);
 const result=await explainRootArc({snapshot,current:existing.currentWorkpiece,browser:{binding:existing.binding,construction:true},query:parsed});
 results.push({query,result});
}
writeFileSync('/tmp/m7-typed-review.WjrqZt/aggregate-why.json',JSON.stringify(results,null,2));
for(const x of results)console.log(JSON.stringify({query:x.query,disposition:x.result.disposition,change:x.result.recordedChange?.toolCallId,revision:x.result.governing?.revisionId,value:x.result.target?.value,reason:x.result.reason}));
// Required safety: a parent containing a still-derived false cell cannot inherit all creation basis.
assert.equal(results[0].result.disposition,'refused','Aggregate initialState includes derived cell(s); original creation basis must not explain current aggregate');
