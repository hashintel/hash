# Separate guarded Playwright browser topology — feasible locally

## Observation

Public installed Playwright1.58.2 `chromium.launchServer({host:'127.0.0.1', port:0, ...})` and `chromium.connect(endpoint, {timeout:10000})` successfully crossed two separately launched loopback-only OS roots. No app, model, accounting, provider or paid-profile code ran. No source or frozen evidence changed; original manifest remains unlaunchable.

Ordinary shell PID75476 launched sibling owner75482 and controller75514 via separate `env -i ... sandbox-exec -f loopback-only.sb node ...` commands. Chrome75498 was the owner's child, not the controller's. Both processes received only PATH/HOME/TMPDIR; HOME/TMPDIR were fresh isolated directories. Chrome received that same minimal environment and a Playwright-generated temporary profile. No nested sandbox application was attempted. Actual process tree and generated profile path are retained in `processes-during.txt` and `ready.json`.

Controller attached through the library-owned ephemeral127.0.0.1 WebSocket, created an isolated context, set a local HTML document, clicked its button, read **Clicked in sibling Chrome**, and captured `dom.png`. No custom HTTP/WebSocket service or provider proxy was introduced. `exposeNetwork` was omitted: browser traffic was not forwarded through the controller. No route interception was installed.

## Network and cleanup proof

Both Node roots' numeric192.0.2.1:80 socket controls returned EPERM. Chrome's numeric navigation failed `net::ERR_ACCESS_DENIED`. More decisively, raw Chrome NetLog records two `TCP_CONNECT_ATTEMPT` sources269/275 to192.0.2.1:80 ending with **os_error1 (EPERM)**, followed by TCP_CONNECT net_error-10. This is socket-level OS denial, not an intercepted route. `numeric-socket-events.json` extracts the exact source-correlated events; full NetLog is retained. Chrome also attempted background network/DNS operations, which the retained NetLog shows denied; this is not a claim of zero attempted background networking. No hostname/provider/auth probe was authored.

Controller closed its context and disconnected. The shell wrote a stop file; owner awaited public `BrowserServer.close()`. Chrome exited0, the temporary profile disappeared, and both owner/controller exited0. A separately loopback-guarded audit confirmed owner/controller/Chrome PIDs gone, profile absent and the old control endpoint returning ECONNREFUSED. A60-second owner lease was installed as bounded fallback; it was not exercised. Abrupt-kill/controller-crash cleanup is not yet proved.

## Actual API and proposed minimum delta — not implemented

Inspected installed `playwright-core/types/types.d.ts`: `launchServer` host/port/env/executablePath and signal options; `BrowserServer.wsEndpoint/process/close/kill`; `BrowserType.connect`; `ConnectOptions.exposeNetwork`. `lib/browserServerImpl.js` confirms public launchServer owns the browser and library endpoint. Client/server major/minor must match. Explicit host is required: omission may bind wildcard even when the returned URL says localhost. Keep the default random endpoint path, restricted readiness-file permissions, and never expose it to page/model input. CDP offers lower documented fidelity and adds no demonstrated simplification here.

Proposed owning change: a bounded evaluation-side browser-owner launcher, started as a separate credential-free loopback-only sibling by ordinary process orchestration. Existing driver replaces only its nested `chromium.launch()` with public `chromium.connect()` to the explicitly supplied endpoint, without `exposeNetwork` or custom headers/proxy. Retain its contexts, actual UI/result path, production registration and all accounting/raw-response/scenario contracts. Driver disconnects; orchestration owns server shutdown and verifies process/profile/endpoint cleanup.

Activation contract must pin launcher/library/profile identity and bind the ephemeral endpoint/owner identity to this one run; explicitly distinguish driver versus browser-owner lifecycle. No implicit fallback, reusable daemon, broader browser egress or second production/model server. Endpoint possession grants automation capability; keep it local/private and expire it after the run.

Owner approval is still required before adapter implementation. Then prove integrated dry5 via this sibling route, failure/early-exit cleanup, and at named activation the differently guarded paid-controller→separate-loopback-owner connection and unchanged native TLS gate. This unpaid test used only loopback profiles and does not establish the future paid root. New freeze and named allocation remain mandatory.

## Complete proof path

All fresh scripts, commands, stdout/stderr/exit statuses, process observations, screenshot, NetLog and extracted audit: `/tmp/m7-sibling-browser.rnXVLO/`. Exact two-root command is `bash /tmp/m7-sibling-browser.rnXVLO/run.sh`; guard/environment commands are explicit inside that script. `audit.mjs` separately checks cleanup and retains raw socket events. No worktree commit or manifest regeneration occurred.
