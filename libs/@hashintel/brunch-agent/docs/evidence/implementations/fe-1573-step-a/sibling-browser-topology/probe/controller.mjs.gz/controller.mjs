import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import net from 'node:net';
import { chromium } from '/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving/node_modules/playwright-core/index.mjs';
const root='/tmp/m7-sibling-browser.rnXVLO';
const ready=JSON.parse(readFileSync(`${root}/ready.json`));
assert.notEqual(process.pid,ready.ownerPid);
const denied=await new Promise(resolve=>{const socket=net.connect({host:'192.0.2.1',port:80});socket.once('error',error=>resolve(error.code));socket.setTimeout(2000,()=>{socket.destroy();resolve('timeout')})});
assert.equal(denied,'EPERM');
const browser=await chromium.connect(ready.endpoint,{timeout:10000});
const report={controllerPid:process.pid,parentPid:process.ppid,ownerPid:ready.ownerPid,chromePid:ready.chromePid,nodeExternal:denied,connected:browser.isConnected(),browserVersion:browser.version(),routeInterceptionInstalled:false,exposeNetworkConfigured:false};
try {
 const context=await browser.newContext({serviceWorkers:'block'});
 const page=await context.newPage();
 await page.setContent('<button id="button" onclick="document.querySelector(\'output\').textContent=\'Clicked in sibling Chrome\'">Act</button><output>Initial</output>');
 await page.getByRole('button',{name:'Act'}).click();
 report.dom=await page.locator('output').textContent();
 assert.equal(report.dom,'Clicked in sibling Chrome');
 await page.screenshot({path:`${root}/dom.png`});
 try {await page.goto('http://192.0.2.1:80/',{timeout:5000});report.externalNavigation='UNEXPECTED success';}catch(error){report.externalNavigation=error.message;}
 assert.notEqual(report.externalNavigation,'UNEXPECTED success');
 await context.close();
} finally {await browser.close(); report.disconnected=!browser.isConnected();writeFileSync(`${root}/controller-result.json`,JSON.stringify(report,null,2),{mode:0o600,flag:'wx'});}
