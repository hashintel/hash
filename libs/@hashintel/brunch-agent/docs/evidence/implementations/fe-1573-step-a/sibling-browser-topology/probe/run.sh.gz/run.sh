#!/bin/bash
set -u
ROOT=/tmp/m7-sibling-browser.rnXVLO
REPO=/Users/lunelson/.herdr/worktrees/hash/m7-provider-proving
PROFILE="$REPO/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/loopback-only.sb"
NODE=$(command -v node)
printf '%s\n' "$NODE" > "$ROOT/node-path.txt"
mkdir "$ROOT/home" "$ROOT/tmp"
# Shell only orchestrates processes/files; it opens no sockets.
/usr/bin/env -i PATH=/usr/bin:/bin HOME="$ROOT/home" TMPDIR="$ROOT/tmp" /usr/bin/sandbox-exec -f "$PROFILE" "$NODE" "$ROOT/owner.mjs" > "$ROOT/owner.stdout" 2> "$ROOT/owner.stderr" &
OWNER=$!
trap 'touch "$ROOT/stop"; wait "$OWNER"' EXIT
printf '%s\n' "$OWNER" > "$ROOT/shell-owner-pid.txt"
for ((i=0;i<200;i++)); do test -f "$ROOT/ready.json" && break; kill -0 "$OWNER" 2>/dev/null || break; sleep 0.05; done
if ! test -f "$ROOT/ready.json"; then printf 'Owner did not become ready\n'; exit 1; fi
/usr/bin/env -i PATH=/usr/bin:/bin HOME="$ROOT/home" TMPDIR="$ROOT/tmp" /usr/bin/sandbox-exec -f "$PROFILE" "$NODE" "$ROOT/controller.mjs" > "$ROOT/controller.stdout" 2> "$ROOT/controller.stderr" &
CONTROLLER=$!
printf '%s\n' "$CONTROLLER" > "$ROOT/shell-controller-pid.txt"
ps -axo pid,ppid,command | grep -F "$ROOT" > "$ROOT/processes-during.txt"
wait "$CONTROLLER"; RESULT=$?
printf '%s\n' "$RESULT" > "$ROOT/controller.exit"
touch "$ROOT/stop"
wait "$OWNER"; OWNER_RESULT=$?
printf '%s\n' "$OWNER_RESULT" > "$ROOT/owner.exit"
trap - EXIT
printf 'controller=%s owner=%s\n' "$RESULT" "$OWNER_RESULT"
test "$RESULT" -eq 0 && test "$OWNER_RESULT" -eq 0
