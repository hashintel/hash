import { registerHooks } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
registerHooks({load(url, context, nextLoad) {
  if (!url.endsWith('/@flue/runtime/dist/conversation-stream-store-CXwRWonS.mjs')) return nextLoad(url, context);
  const original = readFileSync(new URL(url), 'utf8');
  assert.equal(createHash('sha256').update(original).digest('hex'), '7d7c413cef14f401b5977a7c64ff1d9365cc78932ec624ca87b05ec9f0a7e1c4');
  const anchor = '\t\t\t\t\tif (!call.startEmitted) this.emit({';
  assert.equal(original.split(anchor).length, 2);
  const source = original.replace(anchor, '\t\t\t\t\tif (event.toolCallId === "a4-crash-revision") process.kill(process.pid, "SIGKILL");\n' + anchor);
  writeFileSync(process.env.A4_DIAGNOSTIC_DIRECTORY + '/direct-instrumentation.json', JSON.stringify({url, originalSha256: createHash('sha256').update(original).digest('hex'), policy: 'One synchronous kill after existing awaited outcome append; no append wrapper, extra await, logging, state or recovery alteration.'}));
  return {format: 'module', source, shortCircuit: true};
}});
