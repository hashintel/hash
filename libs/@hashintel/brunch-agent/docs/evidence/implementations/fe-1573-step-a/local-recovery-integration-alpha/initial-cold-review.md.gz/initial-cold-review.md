## Advisory conclusion

**No concrete runtime blocker found within the bounded forward-recovery repair. One demonstrated safety-oracle blind spot remains:** the overflow tests can pass while their public-history observations omit the already-completed response whose preservation is required. Green results alone therefore do not establish the entire accepted contract.

### Finding: completed-response preservation is not asserted

At `apps/brunch-agent/test/history-retention.integration.ts:433–573`, the test checks provider-call counts, subsequent folded-context use, old public records, user counts and completed tools. However, its preservation baseline predates the overflow-triggering **“A4 filler acknowledged.”** response. It never asserts that response survives. `history-retention-audit.py:71–99` inherits the same omission.

**Narrow falsifier:** a temporary load hook filtered only that response from `client.history()` observations, without modifying the installed runtime or canonical store. Both create and reopen tests still exited **0**. Separately, removing that response from copied `after.json`, `after-threshold.json` and `reopened.json` artifacts still produced **10 passed, 0 failed** from the audit.

Evidence:
- `/tmp/m7-cold-review-WUypHTI7/omit-response-hook.mjs`
- `…/omit-response-dgSlWX5R/{create,reopen}.log`
- `…/audit-omission-q80u_zk3/audit.json`

This demonstrates an **oracle deficiency, not observed product data loss**. The unmodified replay retained exactly one matching completed response in silent, explicit-error and cancelled-compaction histories. The narrow missing assertion is exact response identity/content and completed settlement, followed through compaction and reopen.

### 1. Revision outcome/state consistency

The installed `conversation-stream-store-CXwRWonS.mjs:2415` drains buffered state into the same append as the live outcome. Repair at `:2809` combines buffered writes, newly resolved outcomes and ordered result commitment.

I traced the relevant consumers:
- Core’s existing render-captured setter still creates the revision; recovery executes that setter rather than reconstructing state from historical JSON.
- Pi Agent Core awaits event listeners.
- `ConversationRecordWriter.appendBatch()` serializes writes and retries the same producer sequence.
- SQLite appends the records transactionally as one canonical batch.
- Reduction applies `state_write`; recovery skips already-recorded outcomes and preserves ordered result references.

The fresh seven-case crash replay passed normal, observed, before-outcome, after-outcome, independent direct kill and both interrupted-repair controls. Raw preboot stores at the post-outcome boundaries already contained state and outcome together. Final recovery was uninstrumented; every case retained exact Markdown/hash/pointer and advanced a distinct revision to ordinal **2**.

The additional prose-only observation submission is legitimate: it exposes render-captured state without invoking the revision setter. The audit also checks storage **before** that observation, so it cannot mask missing settlement through a later tool write.

### 2. Overflow and protected behavior

The new branch at installed runtime `:3983` returns only after successful compaction of a `stop` response without tool calls. It does not manufacture input or retry the completed assistant tail.

Fresh observations confirmed:
- Silent overflow folded **20 → 3**, with no `continueRebuilt`.
- Explicit overflow retried once from a valid retained tail.
- The next actual user input consumed the summary.
- Cancelling post-response compaction aborted the summarizer, retained the completed response and published no successful compaction.
- An additional explicit-overflow response containing partial prose passed the existing retry control.

A separate `length` probe reached threshold rather than overflow compaction and failed the test’s required-overflow assertion; it establishes no partial-overflow guarantee.

Native validation remains ahead of hooks/execution without generic coercion; ordinary generic/Valibot handling and recovery parsing remain unchanged by these three runtime edits. Core marker, nontermination, admission and causal result wiring were preserved.

### Verification and limits

Before execution, installed runtime Git blob identity matched the patch postimage, `fea7316803b80dccf5df6cfe25f0c568b4c7cc26`. Candidate files matched commit `46aa1908f6`; recorded hashes matched 10 installed files, 21 application artifacts and 1,108 protected sources.

Java and Node descendant refusal controls passed. All probes then ran under `deny-network.sb`, without installation or rebuilding.

Fresh production-mount results:
- Recovery diagnostics: **10/10**, independently inspected beyond exit status.
- Native SDK carriage: **20 synthetic requests**, zero network attempts.
- Accounting: **13 cases**, passed.

Primary evidence: `/tmp/m7-cold-review-WUypHTI7/`.

No worktree changes were observed. Legacy inconsistent stores, arbitrary parallel-writer isolation, power-loss durability, universal provider-error recovery and a new browser Voice/Stop witness remain outside this verification. This is advisory review, not mission acceptance or shipping authorization.
