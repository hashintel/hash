**The specific completed-response blind spot is closed. No remaining concrete blocker found in this oracle correction.** This is advisory only, not mission acceptance.

### What changed materially

In `history-retention.integration.ts:84–279`, the expected response is now sourced independently of `client.history()`:

- A successful agent `turn` event triggers a read-only canonical-store read after the completion append.
- The pin verifies message/submission/turn identity, completed text-block deltas and successful stop.
- A separate canonical `submission_settled` record is correlated with the actual send receipt.
- Exact public identity, content, uniqueness and completed settlement are checked after compaction/Stop, subsequent input, reopen and continued input.

The audit’s `completed_response()` independently derives the expected public message from those records; it does not rebaseline against potentially damaged history observations.

**Explicit-error identity is preserved correctly:** the successful retry’s canonical message/turn IDs differ from the public aggregate’s first, failed step IDs. My fresh explicit-error control passed with that distinction intact. Silent and cancelled pins preceded compaction.

### Independent probes

Output root: `/tmp/m7-oracle-rereview-bQfLYB0a/`

Before execution, Java/Node descendant network-refusal controls passed. Installed dependencies, application artifacts and protected-source hashes still matched the prior verified identities; patch/lock/product commit differences were empty.

Using:
```bash
sandbox-exec -f "$GUARD" env \
  A4_OUTPUT_DIRECTORY="$D" A4_PHASE="$phase" A4_OVERFLOW_PROBE=1 \
  "${extra[@]}" node --experimental-strip-types \
  apps/brunch-agent/test/history-retention.integration.ts
```

Here `$GUARD` was the existing `native-local-delivery/deny-network.sb`; extras selected cancelled or explicit-error mode.

| Probe | Result |
|---|---|
| Silent create + reopen | Both exit 0 |
| Cancelled create + reopen | Both exit 0 |
| Explicit-error create + reopen | Both exit 0 |
| Original untouched omission hook, silent | Exit 1 at the intended response assertion |
| Original untouched omission hook, cancelled | Exit 1 at the intended response assertion |

The omission runs added:
```bash
--import /tmp/m7-cold-review-WUypHTI7/omit-response-hook.mjs
```

Both failed at `assertCompletedResponse`, line 232: **“The pinned completed response must survive exactly once, with exact identity/content.”** They did not fail because the hook stopped matching.

I also ran:
```bash
sandbox-exec -f "$GUARD" python3 \
  /tmp/m7-oracle-rereview-bQfLYB0a/check-coordinated-omissions.py
```

This exercised the unchanged audit helper against fresh observations, then copied artifacts with coordinated omissions across **all four checked snapshots**. Silent and cancelled response omissions failed the pinned-response assertion; coordinated settlement omissions failed the completed-settlement assertion. All three unmodified controls passed.

No repository edits, installation, rebuilding or existing-store changes occurred. The worktree remained clean, and I did not read `review-correction.md`.
