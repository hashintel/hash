import { c as encodeBase64, f as createCallHandle, l as abandonToolOnAbort, r as createCwdSandbox, s as decodeBase64, u as abortErrorFor } from "./sandbox-DAJ0daML.mjs";
import { A as createEditTool, D as READ_SKILL_RESOURCE_TOOL_NAME, E as redactObservationDetailImages, F as createTaskTool, I as createWriteTool, L as formatBashResult, M as createGrepTool, N as createPackagedSkillReadTool, O as createActivateSkillTool, P as createReadTool, R as overlayPackagedSkills, S as renderWithFrame, T as redactEventImages, _ as packageSkillDefinition, a as buildPromptText, b as getSkillReferenceDirectory, c as buildWorkspaceSkillPrompt, d as parseSkillMarkdown, f as getPreparedToolAdapter, g as isSkillDefinition, i as buildPackagedSkillPrompt, j as createGlobTool, k as createBashTool, l as createResultTools, n as GIVE_UP_TOOL_NAME, o as buildResultFollowUpPrompt, r as ResultUnavailableError, s as buildSkillByPathlessNamePrompt, t as FINISH_TOOL_NAME, u as prepareResultTool, w as IMAGE_DATA_OMITTED } from "./result-DfjetCf9.mjs";
import { $ as generateIncarnationId, A as SubmissionConflictError, F as ToolNameConflictError, J as createConversationIdentity, K as serializeEventError, M as SubmissionRetryExhaustedError, N as SubmissionTimeoutError, O as SubagentNotDeclaredError, S as SessionBusyError, T as SkillNotRegisteredError, W as normalizeLogAttributes, X as generateAttemptId, Y as deriveKeyedSubmissionId, Z as generateBlockId, a as AttachmentNotAvailableError, c as ConversationRecordInvariantError, ct as generateToolCallId, d as FlueError, ft as interceptExecution, h as OperationFailedError, j as SubmissionInterruptedError, k as SubmissionAbortedError, l as ConversationStreamStoreError, lt as generateTurnId, n as AgentInstanceNotFoundError, nt as generateInvocationId, ot as generateSubmissionId, p as InvalidRequestError, rt as generateOperationId, st as generateTaskId, t as AgentInstanceExistsError, tt as generateInstanceUid, u as DelegationDepthExceededError, z as classifyError } from "./errors-CsDcT_C4.mjs";
import { $ as shouldCompact, B as aggregateConversationUsageSince, C as DeliveredMessageSchema, Ct as generateConversationEntryId, E as assertDurability, G as findTrailingPartialToolBatch, H as getActiveConversationPathSince, I as MAX_READ_LIMIT, J as calculateContextTokens, K as isRetryableModelError, L as agentStreamPath, Q as prepareCompaction, R as formatOffset, St as encodeCanonicalId, Tt as toolStepRecordId, U as getLatestConversationCompaction, V as classifyConversationSubmission, W as countConsecutiveRetryableModelErrors, X as deriveCompactionDefaults, Y as compact, Z as isAssistantContextOverflow, _t as assertAppendMessage, bt as fnv1a64, ct as toolOutcomeKey, d as resolveAgentInitialDataSchema, et as addUsage, ft as createSessionStorageKey, gt as renderSignalMessage, ht as createUserContextMessage, it as buildConversationContextEntries, lt as toolResultEntryId, mt as parseSessionStorageKey, nt as fromProviderUsage, ot as getActiveConversationPath, q as DEFAULT_COMPACTION_SETTINGS, rt as buildConversationContext, tt as emptyUsage, w as MAX_IMAGE_DATA_LENGTH, wt as generateConversationRecordId, xt as RESERVED_SIGNAL_TYPES, yt as runResponseMetadataHooks, z as parseOffset } from "./dispatch-nU3cIlT-.mjs";
import { i as providerTelemetryName, n as getRuntimeModels } from "./providers-B1VyW-aH.mjs";
import { toolInputToJsonSchema, isNativeToolInput, n as isValibotSchema } from "./schema-DIDpvZZa.mjs";
import { toolContextBase, a as parseToolInput, n as claimStepName, o as resolveToolRun, r as cloneStepValue, t as assertToolDefinition } from "./tool-DZ5dxCl_.mjs";
import { n as readProviderResponseDiagnostics } from "./provider-diagnostics-C8itP2qI.mjs";
import { r as migrateFlueSqlSchema, s as createAttachmentRef } from "./format-version-Bmc1L_3t.mjs";
import * as v from "valibot";
import { Agent } from "@earendil-works/pi-agent-core";
//#region src/agent-execution-store.ts
/** Default maximum total attempts before terminalization. */
const DURABILITY_DEFAULT_MAX_ATTEMPTS = 10;
/** Default submission timeout in milliseconds (one hour). */
const DURABILITY_DEFAULT_TIMEOUT_MS = 36e5;
/** Default lease duration for submission ownership in milliseconds (30 seconds). */
const LEASE_DURATION_MS = 3e4;
//#endregion
//#region src/persisted-images.ts
const IMAGE_DATA_CHUNK_LENGTH = 262144;
const markerPrefix = "__flue_submission_chunks__:";
/**
* Operation entry points (prompt/skill/task) call this before any history
* mutation so oversized images are rejected identically across session store
* adapters, instead of failing later inside SQL persistence and leaving an
* unsaveable entry in in-memory history. The check inside
* `extractImageBlocks` remains as a persistence-layer invariant.
*/
function assertImagesWithinLimit(images) {
	for (const image of images ?? []) if (image.data.length > 14680064) throw new Error(`[flue] Image data exceeds the ${MAX_IMAGE_DATA_LENGTH} character limit.`);
}
/**
* Attachments are a property of the delivered message, not the transport:
* this extracts and chunks a `kind: 'user'` message's attachments for
* oversized-row-safe persistence, regardless of whether the submission
* arrived as a direct HTTP prompt or a `dispatch()` call. A `kind: 'signal'`
* message never carries attachments (deferred — see the phase 2 plan), so
* this is a no-op passthrough for it.
*/
function extractSubmissionAttachments(input) {
	if (input.message.kind !== "user") return {
		value: input,
		chunks: []
	};
	const extracted = extractImageArray(input.message.attachments);
	return {
		value: {
			...input,
			message: {
				...input.message,
				...extracted.value === void 0 ? {} : { attachments: extracted.value }
			}
		},
		chunks: extracted.chunks
	};
}
function hydrateSubmissionAttachments(input, itemData) {
	if (input.message.kind !== "user" || input.message.attachments === void 0) {
		assertExactImageGroups([], itemData);
		return input;
	}
	assertExactImageGroups(markerIds(input.message.attachments), itemData);
	return {
		...input,
		message: {
			...input.message,
			attachments: hydrateImageArray(input.message.attachments, itemData)
		}
	};
}
function extractImageArray(images) {
	if (images === void 0) return {
		value: void 0,
		chunks: []
	};
	return extractImageBlocks(images);
}
function extractImageBlocks(blocks) {
	const chunks = [];
	let imageIndex = 0;
	return {
		value: blocks.map((block) => {
			if (!isImageBlock(block)) return block;
			if (block.data.length > 14680064) throw new Error(`[flue] Image data exceeds the ${MAX_IMAGE_DATA_LENGTH} character limit.`);
			const itemId = String(imageIndex++);
			const count = Math.max(1, Math.ceil(block.data.length / IMAGE_DATA_CHUNK_LENGTH));
			for (let index = 0; index < count; index++) chunks.push({
				itemId,
				index,
				count,
				data: block.data.slice(index * IMAGE_DATA_CHUNK_LENGTH, (index + 1) * IMAGE_DATA_CHUNK_LENGTH)
			});
			return {
				...block,
				data: `${markerPrefix}${itemId}`
			};
		}),
		chunks
	};
}
function markerIds(content) {
	if (!Array.isArray(content)) return [];
	return content.flatMap((block) => {
		if (!isImageBlock(block) || !block.data.startsWith(markerPrefix)) return [];
		return [block.data.slice(27)];
	});
}
function assertExactImageGroups(markerItemIds, itemData) {
	const markers = new Set(markerItemIds);
	if (markers.size !== markerItemIds.length || markers.size !== itemData.size) throw new Error("[flue] Persisted image chunks do not match persisted image markers.");
	for (const itemId of itemData.keys()) if (!markers.has(itemId)) throw new Error("[flue] Persisted image chunks do not match persisted image markers.");
}
function hydrateImageArray(blocks, itemData) {
	return blocks.map((block) => {
		if (!isImageBlock(block) || !block.data.startsWith(markerPrefix)) return block;
		const data = itemData.get(block.data.slice(27));
		if (data === void 0) throw new Error("[flue] Persisted image chunks are missing.");
		return {
			...block,
			data
		};
	});
}
function isImageBlock(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const block = value;
	return block.type === "image" && typeof block.data === "string";
}
//#endregion
//#region src/persisted-image-placement.ts
/**
* Extract and chunk a submission's attachments (present only on a `kind:
* 'user'` message) for oversized-row-safe storage. Applies to both direct
* and dispatch submissions — attachments are a property of the message, not
* the transport.
*/
function prepareSubmissionAttachments(input) {
	return extractSubmissionAttachments(input);
}
function hydratePersistedSubmissionAttachments(input, rows) {
	return hydrateSubmissionAttachments(input, reassemblePersistedChunks(rows));
}
function matchesPersistedSubmissionAttachments(input, persistedInput, rows) {
	try {
		return JSON.stringify(hydratePersistedSubmissionAttachments(persistedInput, rows)) === JSON.stringify(input);
	} catch {
		return false;
	}
}
function reassemblePersistedChunks(rows) {
	const grouped = /* @__PURE__ */ new Map();
	for (const row of rows) {
		const itemRows = grouped.get(row.itemId) ?? [];
		itemRows.push(row);
		grouped.set(row.itemId, itemRows);
	}
	const data = /* @__PURE__ */ new Map();
	for (const [itemId, itemRows] of grouped) {
		const ordered = itemRows.toSorted((left, right) => left.index - right.index);
		const expectedCount = ordered[0]?.count;
		if (expectedCount === void 0 || expectedCount < 1 || ordered.length !== expectedCount || ordered.some((row, index) => row.count !== expectedCount || row.index !== index)) throw new Error("[flue] Persisted image chunks are missing or malformed.");
		data.set(itemId, ordered.map((row) => row.data).join(""));
	}
	return data;
}
function sameSubmissionChunks(left, right) {
	if (left.length !== right.length) return false;
	const rightByKey = new Map(right.map((chunk) => [chunkKey(chunk), chunk]));
	return left.every((chunk) => {
		const other = rightByKey.get(chunkKey(chunk));
		return other !== void 0 && chunk.count === other.count && chunk.data === other.data;
	});
}
function chunkKey(chunk) {
	return `${chunk.itemId}\u0000${chunk.index}`;
}
//#endregion
//#region src/adapter-helpers.ts
/**
* Shared helpers for persistence adapter implementations.
*
* These pure functions are consumed by the built-in SQLite adapter, the
* Postgres adapter (`@flue/postgres`), and any future community adapters
* via `@flue/runtime/adapter`.
*
* All functions operate on plain values — no database driver types.
*/
/**
* Agent-mode submissions (HTTP and dispatch) always target the
* default harness. Named harnesses exist for multi-harness workflows
* (for example, named internal scopes), but external submissions do
* not select a harness — they implicitly use `'default'`.
*
* Exported for adapter implementations that construct session storage keys.
*/
const SUBMISSION_HARNESS_NAME = "default";
/**
* Agent-mode submissions always target the default session of the
* default harness; external submissions cannot select a session.
*
* Exported for adapter implementations that construct session storage keys.
*/
const SUBMISSION_SESSION_NAME = "default";
/**
* Validate that a parsed JSON payload matches the expected submission shape.
*
* Used after `JSON.parse(payload)` to verify the deserialized object is a
* well-formed `AgentSubmissionInput` that is consistent with the stored
* submission metadata. Both dispatch and direct payloads carry the same
* `message: DeliveredMessage` field — validated identically here regardless
* of transport `kind`.
*
* The `kind`/`submissionId`/`sessionKey`/`acceptedAt` cross-checks against
* the row's own columns are load-bearing, not redundant: the payload is the
* byte-exact admitted input and is the identity the session layer runs under
* (it never sees the row). In backends that store the payload physically
* apart from the row — MongoDB's chunked value generations, Redis's
* per-generation hashes — the store's completeness checks cannot catch a
* *complete but wrong* payload (a stale generation pointer, a backup mixing
* two databases). This mismatch is the only thing that stops the runtime
* executing one submission's message under another's identity: a failing
* check terminalizes the row instead of running it.
*/
function isSubmissionPayload(input, ctx) {
	if (!input || typeof input !== "object") return false;
	const value = input;
	if (value.kind !== ctx.kind || value.submissionId !== ctx.submissionId) return false;
	if (!v.safeParse(DeliveredMessageSchema, value.message).success) return false;
	return typeof value.agent === "string" && typeof value.id === "string" && createSessionStorageKey(value.agent, value.id, "default", "default") === ctx.sessionKey && typeof value.acceptedAt === "string" && Date.parse(value.acceptedAt) === ctx.acceptedAt;
}
/**
* Run a maybe-async continuation without forcing a promise: when `value` is a
* plain value the continuation runs synchronously, so a fully synchronous
* backend (e.g. Durable Object SQLite inside `transactionSync`) completes the
* whole admission without ever yielding to the microtask queue.
*/
function chain(value, next) {
	return value instanceof Promise ? value.then(next) : next(value);
}
/**
* Shared submission admission algorithm for row-oriented backends:
* prepare attachments → insert-or-ignore → read-back → payload compare
* (idempotent replay vs. conflict) → attachment-chunk adoption or comparison.
*
* The caller owns transaction scoping — invoke this inside one transaction
* and pass callbacks bound to it. When every callback is synchronous the
* result is returned synchronously, so the algorithm also fits synchronous
* transaction wrappers such as Durable Object `transactionSync`.
*/
function admitSubmissionWithBackend(input, backend) {
	const { kind, submissionId } = input;
	const prepared = prepareSubmissionAttachments(input);
	const payload = JSON.stringify(prepared.value);
	const acceptedAt = parseAcceptedAt(input.acceptedAt, `${kind} admission`);
	const sessionKey = createSessionStorageKey(input.agent, input.id, SUBMISSION_HARNESS_NAME, SUBMISSION_SESSION_NAME);
	const adopt = (row) => {
		if (row.kind !== kind) return { kind: "conflict" };
		if (row.payload !== payload) return chain(backend.readChunks(submissionId), (persistedChunks) => {
			if (typeof row.payload !== "string" || !matchesPersistedSubmissionAttachments(input, JSON.parse(row.payload), persistedChunks)) return { kind: "conflict" };
			return {
				kind: "submission",
				submission: backend.parseSubmission(row, persistedChunks)
			};
		});
		return chain(backend.readChunks(submissionId), (persistedChunks) => {
			if (persistedChunks.length === 0 && prepared.chunks.length > 0) return chain(backend.replaceChunks(submissionId, prepared.chunks), () => ({
				kind: "submission",
				submission: backend.parseSubmission(row, prepared.chunks)
			}));
			if (!sameSubmissionChunks(persistedChunks, prepared.chunks)) return { kind: "conflict" };
			return {
				kind: "submission",
				submission: backend.parseSubmission(row, prepared.chunks)
			};
		});
	};
	return chain(backend.insertIfAbsent({
		submissionId,
		sessionKey,
		kind,
		payload,
		acceptedAt
	}), () => chain(backend.getExisting(submissionId), (row) => {
		if (!row) throw new Error(`[flue] Durable ${kind} admission did not create a submission row.`);
		return adopt(row);
	}));
}
/**
* Parse an ISO timestamp string into epoch milliseconds.
* Throws with a `[flue]` error if the value is not a finite number.
*/
function parseAcceptedAt(value, label) {
	const acceptedAt = Date.parse(value);
	if (!Number.isFinite(acceptedAt)) throw new Error(`[flue] Internal ${label} received an invalid acceptedAt timestamp.`);
	return acceptedAt;
}
/**
* Clamp a caller-supplied page/chunk limit to a safe range.
*
* Invalid, non-finite, and non-positive values fall back to `defaultLimit`;
* valid values are capped at `maxLimit`. Used by run listings
* (`DEFAULT_LIST_LIMIT`/`MAX_LIST_LIMIT`) and event stream reads
* (`DEFAULT_READ_LIMIT`/`MAX_READ_LIMIT`).
*/
function clampLimit(limit, defaultLimit, maxLimit) {
	if (!limit || !Number.isFinite(limit) || limit <= 0) return defaultLimit;
	return Math.min(limit, maxLimit);
}
//#endregion
//#region src/context.ts
/**
* Context discovery: reads AGENTS.md and .agents/skills/ from a session's
* working directory. Used at runtime by the session initialisation path.
*/
function isWorkspaceSkill(skill) {
	const candidate = skill;
	return candidate.__flueWorkspaceSkill === true && typeof candidate.directory === "string" && typeof candidate.skillMdPath === "string";
}
/** Read AGENTS.md (and CLAUDE.md if present) from a directory. Returns concatenated contents. */
async function readAgentsMd(env, basePath) {
	const parts = [];
	for (const filename of ["AGENTS.md", "CLAUDE.md"]) {
		const filePath = basePath.endsWith("/") ? basePath + filename : `${basePath}/${filename}`;
		if (await env.exists(filePath)) {
			const content = await env.readFile(filePath);
			parts.push(content.trim());
		}
	}
	return parts.join("\n\n");
}
/** Path to the skills directory under a given base path. */
function skillsDirIn(basePath) {
	return basePath.endsWith("/") ? `${basePath}.agents/skills` : `${basePath}/.agents/skills`;
}
/**
* Discover skills from `.agents/skills/<name>/SKILL.md` under basePath.
*
* Skill bodies are intentionally not retained. Autonomous activation
* rereads SKILL.md before injecting its instructions, while direct name
* invocation lets the model read workspace files itself. This keeps
* relative references resolvable and picks up mid-session edits without
* re-initialising the agent. We parse the frontmatter here only to
* populate the system-prompt's "Available Skills" registry.
*
* Discovered skills the user didn't opt into must not be able to brick
* the session: a malformed SKILL.md is skipped with a warning instead of
* failing init(). Explicitly imported/packaged skills stay strict — they
* are validated at build time where a hard error is actionable.
*/
async function discoverLocalSkills(env, basePath) {
	const skillsDir = skillsDirIn(basePath);
	if (!await env.exists(skillsDir)) return {};
	const skills = Object.create(null);
	const entries = await env.readdir(skillsDir);
	for (const entry of entries) {
		const skillDir = `${skillsDir}/${entry}`;
		try {
			if (!(await env.stat(skillDir)).isDirectory) continue;
		} catch {
			continue;
		}
		const skillMdPath = `${skillDir}/SKILL.md`;
		if (!await env.exists(skillMdPath)) continue;
		let parsed;
		try {
			const content = await env.readFile(skillMdPath);
			parsed = parseSkillMarkdown(content, {
				directoryName: entry,
				path: skillMdPath
			});
		} catch (error) {
			const detail = error instanceof Error ? error.message : String(error);
			console.warn(`[flue] Skipping invalid workspace skill "${entry}": ${detail}`);
			continue;
		}
		const workspaceSkill = {
			__flueWorkspaceSkill: true,
			name: parsed.name,
			description: parsed.description,
			directory: skillDir,
			skillMdPath
		};
		skills[parsed.name] = workspaceSkill;
	}
	return skills;
}
function mergeSkillCatalog(definitionSkills, discoveredSkills) {
	const merged = Object.create(null);
	for (const skill of definitionSkills) merged[skill.name] = skill;
	for (const [name, skill] of Object.entries(discoveredSkills)) {
		if (Object.hasOwn(merged, name)) throw new Error(`[flue] Skill name "${name}" appears in both agent definition and workspace discovery.`);
		merged[name] = skill;
	}
	return merged;
}
/**
* The composed system prompt is load-bearing machinery only: the agent's
* instructions, discovered workspace context, the skill catalog, the task
* roster, and environment facts. Flue adds no behavioral stance of its own
* (an autonomy preamble used to live here) — how an agent should behave is
* the agent function's instructions to give.
*/
function composeSystemPrompt(agentsMd, catalog, agentCatalog, env, instructions) {
	const parts = [];
	const pushSection = (...lines) => {
		if (parts.length > 0) parts.push("");
		parts.push(...lines);
	};
	if (instructions) pushSection(instructions);
	if (agentsMd) pushSection(agentsMd);
	if (catalog.length > 0) {
		pushSection("## Available Skills", "", "The following skills provide specialized instructions for specific tasks. When a task matches a skill description, call the `activate_skill` tool with that skill name before proceeding so its full instructions are loaded. Skill instructions and supporting resources stay lazy until activation or explicit file reads.", "");
		for (const skill of catalog) {
			const desc = skill.description ? ` — ${skill.description}` : "";
			parts.push(`- **${skill.name}**${desc}`);
		}
	}
	if (agentCatalog.length > 0) {
		pushSection("## Available Agents", "", "You can delegate focused work to one of these agents with the `task` tool, naming the agent to use. The list can change over the conversation — additions and removals are announced.", "");
		for (const agent of agentCatalog) {
			const desc = agent.description ? ` — ${agent.description}` : "";
			parts.push(`- **${agent.name}**${desc}`);
		}
	} else pushSection("## Available Agents", "", "None. No subagents are currently declared, so the `task` tool has no valid `agent` value — do not call it unless an agent is introduced later in the conversation.");
	pushSection(`Date: ${(/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
		weekday: "short",
		year: "numeric",
		month: "short",
		day: "numeric"
	})}`);
	if (env) {
		parts.push(`Working directory: ${env.cwd}`);
		if (env.directoryListing && env.directoryListing.length > 0) parts.push("", "Directory structure:", env.directoryListing.join("\n"));
	}
	return parts.join("\n");
}
/**
* Discover AGENTS.md, local skills, and directory listing from the session's
* cwd. Composition is the caller's move: seed the catalogs first, then
* `recompose(instructions)` — an initial composition here would necessarily
* predate the catalog baseline.
*/
async function discoverSessionContext(env, definitionSkills = []) {
	const agentsMd = env ? await readAgentsMd(env, env.cwd) : "";
	const discoveredSkills = env ? await discoverLocalSkills(env, env.cwd) : {};
	const skills = mergeSkillCatalog(definitionSkills, discoveredSkills);
	let directoryListing;
	if (env) try {
		directoryListing = await env.readdir(env.cwd);
	} catch {}
	let catalog = skillCatalogEntries(skills);
	const setCatalog = (entries) => {
		catalog = entries;
	};
	let agentCatalog = [];
	const setAgentCatalog = (entries) => {
		agentCatalog = entries;
	};
	const recompose = (nextInstructions) => composeSystemPrompt(agentsMd, catalog, agentCatalog, env ? {
		cwd: env.cwd,
		directoryListing
	} : void 0, nextInstructions);
	const mergeSkills = (nextDefinitionSkills) => mergeSkillCatalog(nextDefinitionSkills, discoveredSkills);
	return {
		skills,
		recompose,
		setCatalog,
		setAgentCatalog,
		mergeSkills
	};
}
/** The model-facing catalog lines of a skill map (name + description only). */
function skillCatalogEntries(skills) {
	return Object.values(skills).map((skill) => ({
		name: skill.name,
		...skill.description ? { description: skill.description } : {}
	}));
}
//#endregion
//#region src/hooks/render.ts
/**
* The props the runtime passes to the root agent function. On a bare render
* with no backing instance (tests/tooling), reading `id` throws — the same
* contract as `useDelivery()` on an unbacked render. A subagent's agent
* function never receives props: a delegate runs in isolation from the
* parent.
*/
function agentPropsFor(state) {
	if (state?.instanceId !== void 0) return { id: state.instanceId };
	const props = {};
	Object.defineProperty(props, "id", { get() {
		throw new Error("[flue] This render has no agent instance behind it, so `props.id` is unavailable. Pass `instanceId` in the render state to back it in tests and tooling.");
	} });
	return props;
}
/** `renderAgentFunction` plus the render's structural fingerprint. */
function renderAgentFunctionWithStructure(agent, state) {
	const props = agentPropsFor(state);
	const { result, frame } = renderWithFrame(() => agent(props), state);
	assertAgentInstruction(result);
	assertUniqueToolNames(frame);
	if (state?.output) {
		state.output.responseStarts = [...frame.responseStarts];
		state.output.responseFinishes = [...frame.responseFinishes];
		state.output.agentStarts = [...frame.agentStarts];
		state.output.agentFinishes = [...frame.agentFinishes];
	}
	const instructions = composeAgentDocument(result, frame);
	const tools = frame.tools;
	return {
		config: {
			...frame.model !== void 0 ? { model: frame.model } : {},
			...instructions !== void 0 ? { instructions } : {},
			...tools.length > 0 ? { tools } : {},
			...frame.thinkingLevel !== void 0 ? { thinkingLevel: frame.thinkingLevel } : {},
			...frame.compaction !== void 0 ? { compaction: frame.compaction } : {},
			...frame.cwd !== void 0 ? { cwd: frame.cwd } : {},
			...frame.sandbox !== void 0 ? { sandbox: frame.sandbox } : {},
			...frame.skills.length > 0 ? { skills: frame.skills } : {},
			...frame.subagents.length > 0 ? { subagents: frame.subagents } : {},
			...frame.mcpConnections.length > 0 ? { mcpConnections: frame.mcpConnections } : {}
		},
		structure: {
			messageDataNames: [...frame.messageDataNames],
			resources: {
				skills: frame.skills.map((skill) => ({
					name: skill.name,
					...skill.description ? { description: skill.description } : {}
				})),
				tools: tools.map((tool) => toolResourceEntry(tool)),
				subagents: frame.subagents.map((subagent) => ({
					name: subagent.name,
					description: subagent.description
				}))
			}
		}
	};
}
function toolResourceEntry(tool) {
	return {
		name: tool.name,
		description: tool.description,
		...tool.input ? { schema: JSON.stringify(toolInputToJsonSchema(tool.input)) } : {}
	};
}
/**
* Render a delegate's agent function into the self-contained profile shape
* the task machinery consumes. Runs at delegation time, in its own frame,
* fresh per task — closures read current values, and two delegations to the
* same subagent render independently. Subagent frames reject root-scoped
* hooks (`usePersistentState`, `useSandbox`); nested `useSubagent` declarations pass
* through for the delegate's own task tool, governed by the delegation
* depth cap.
*
* `delivery` is the parent's task prompt as a `DeliveredMessage` — the
* delegate's triggering input, readable via `useDelivery()` exactly like a
* root agent reads its dispatch.
*/
function resolveSubagentDefinition(subagent, delivery) {
	const { result, frame } = renderWithFrame(subagent.agent, delivery ? {
		snapshot: /* @__PURE__ */ new Map(),
		store: void 0,
		delivery
	} : void 0, "subagent");
	assertAgentInstruction(result);
	assertUniqueToolNames(frame);
	const instructions = composeAgentDocument(result, frame);
	const tools = frame.tools;
	return {
		name: subagent.name,
		description: subagent.description,
		...subagent.model !== void 0 ? { model: subagent.model } : {},
		...subagent.thinkingLevel !== void 0 ? { thinkingLevel: subagent.thinkingLevel } : {},
		...instructions !== void 0 ? { instructions } : {},
		...tools.length > 0 ? { tools } : {},
		...frame.skills.length > 0 ? { skills: frame.skills } : {},
		...frame.subagents.length > 0 ? { subagents: frame.subagents } : {}
	};
}
/**
* Message data names are the response's client-facing identity and must be
* declared identically on every render. Everything else may vary: resources
* (tools, skills, subagents) may be declared conditionally — the session
* narrates their changes to the model; `usePersistentState` may be declared
* conditionally too — its record-log storage is keyed by name, so a name's
* absence on a given render is just a render that didn't touch it; event
* hooks may be declared conditionally — each seam runs whatever the current
* render declares, at-least-once per delivery; and the sandbox is exempt —
* presence may change between renders, and the session swaps the environment
* at the next turn boundary and narrates it. Throws with the precise delta
* when consecutive renders disagree on an identity kind.
*/
function assertRenderStructureInvariance(previous, next) {
	const messageDataDelta = setDelta(previous.messageDataNames, next.messageDataNames);
	if (messageDataDelta) throw new Error(`[flue] The agent's render changed identity between turns: message data ${messageDataDelta}. Message data must be declared unconditionally on every render — the named parts are the response's client-facing identity. Resources (tools, skills, subagents), persisted state, event hooks, and the sandbox may all be conditional.`);
}
function setDelta(previous, next) {
	const before = new Set(previous);
	const after = new Set(next);
	const added = [...after].filter((name) => !before.has(name));
	const removed = [...before].filter((name) => !after.has(name));
	if (added.length === 0 && removed.length === 0) return void 0;
	return [...added.length > 0 ? [`added ${added.join(", ")}`] : [], ...removed.length > 0 ? [`removed ${removed.join(", ")}`] : []].join("; ");
}
/**
* The agent's instruction document, concatenated in composition order: the
* agent's returned instruction first, then `useInstruction` contributions in
* call order. Authors own all formatting — the runtime only joins with blank
* lines.
*/
function composeAgentDocument(base, frame) {
	const parts = [...base !== void 0 && base.length > 0 ? [base] : [], ...frame.instructions];
	if (parts.length === 0) return void 0;
	return parts.join("\n\n");
}
function assertUniqueToolNames(frame) {
	const seen = /* @__PURE__ */ new Set();
	const all = frame.tools;
	for (const tool of all) {
		if (seen.has(tool.name)) throw new ToolNameConflictError({
			name: tool.name,
			conflict: "duplicate",
			source: "custom"
		});
		seen.add(tool.name);
	}
}
function assertAgentInstruction(value) {
	if (isPromiseLike(value)) throw new Error("[flue] Agent functions must be synchronous. Move async work into tools, actions, or resource factories.");
	if (value !== void 0 && typeof value !== "string") throw new Error("[flue] An agent returns its instruction string (or nothing). Everything else — model, sandbox, tools — is composed with hooks in the body.");
}
function isPromiseLike(value) {
	return typeof value === "object" && value !== null && "then" in value && typeof value.then === "function";
}
//#endregion
//#region src/resources.ts
/**
* Dynamic resources: tools, skills, and subagents may be declared
* conditionally (`if (cond) useSkill(s)`), so the set the model can use
* changes across renders. The runtime never rewrites the presentation
* surfaces the model already read (the system prompt's skill catalog, the
* task tool's roster) — those stay frozen on a durable BASELINE snapshot.
* Instead, every render's declared set is diffed against the durable
* LAST-NARRATED snapshot and the delta is appended as a `resources` signal,
* so the transcript records exactly when each resource appeared,
* disappeared, or changed. Compaction rebaselines: the post-compaction
* prompt snapshots the then-current sets and the delta bookkeeping before
* it stops mattering.
*
* This module is the pure core: snapshot types (shared with the durable
* `resource_snapshot` record), the diff, and the signal-body rendering.
*/
/**
* Digest one render's composed instruction document (FNV-1a 64-bit — change
* detection, not cryptography). `undefined` (an agent with no instruction
* document) digests as the empty string, so gaining or losing the document
* counts as a change like any edit.
*/
function digestInstructions(instructions) {
	return fnv1a64(instructions ?? "");
}
/**
* Whether the instruction document changed between two snapshots. A previous
* snapshot without a digest (recorded before the field existed) never counts
* as changed — the next recorded snapshot carries the digest and detection
* starts from there.
*/
function instructionsChanged(previous, next) {
	return previous.instructionsDigest !== void 0 && next.instructionsDigest !== void 0 && previous.instructionsDigest !== next.instructionsDigest;
}
/**
* The `instructions` signal body: a marker, not a message. The model's live
* system prompt already IS the new version, so the signal only pins WHEN the
* ground shifted — which is all a model needs to explain its own earlier
* behavior to itself. Deliberately tiny: an agent whose instruction document
* churns emits this every turn, and that visibility is a feature (churn is
* a smell worth surfacing), so the marker must cost almost nothing.
*/
const INSTRUCTIONS_UPDATED_SIGNAL_BODY = "System instructions updated.";
/**
* Diff two snapshots by resource name. Returns one delta per kind that
* actually changed — an empty array means the model's view is current.
* An entry counts as updated when its description (or, for tools, its
* schema digest) changed.
*/
function diffResourceSnapshots(previous, next) {
	const deltas = [];
	const kinds = [
		{
			kind: "skill",
			previous: previous.skills,
			next: next.skills
		},
		{
			kind: "tool",
			previous: previous.tools,
			next: next.tools
		},
		{
			kind: "subagent",
			previous: previous.subagents,
			next: next.subagents
		}
	];
	for (const { kind, previous: before, next: after } of kinds) {
		const beforeByName = new Map(before.map((entry) => [entry.name, entry]));
		const afterNames = new Set(after.map((entry) => entry.name));
		const added = after.filter((entry) => !beforeByName.has(entry.name));
		const removed = before.filter((entry) => !afterNames.has(entry.name)).map((e) => e.name);
		const updated = after.filter((entry) => {
			const existing = beforeByName.get(entry.name);
			return existing !== void 0 && !resourceEntryEquals(existing, entry);
		});
		if (added.length > 0 || removed.length > 0 || updated.length > 0) deltas.push({
			kind,
			added,
			removed,
			updated
		});
	}
	return deltas;
}
function resourceEntryEquals(a, b) {
	return a.description === b.description && a.schema === b.schema;
}
const KIND_LABELS = {
	skill: {
		singular: "skill",
		plural: "skills",
		roster: "All available skills"
	},
	tool: {
		singular: "tool",
		plural: "tools",
		roster: "All available tools"
	},
	subagent: {
		singular: "agent",
		plural: "agents",
		roster: "All available agents"
	}
};
/**
* Render one kind's delta as the signal body the model reads: added entries
* as catalog-shape lines, removals and updates as factual one-liners, and
* the current roster (names only) last so a chain of deltas always ends in
* an unambiguous snapshot. Tool updates are name-only by design — the new
* description/schema reaches the model natively in the tools array.
*/
function renderResourceSignalBody(delta, roster) {
	const { singular, plural, roster: rosterLabel } = KIND_LABELS[delta.kind];
	const lines = [];
	if (delta.added.length > 0) {
		lines.push(delta.added.length === 1 ? `New ${singular} available:` : `New ${plural} available:`);
		for (const entry of delta.added) lines.push(catalogLine(entry));
	}
	for (const name of delta.removed) lines.push(`The ${singular} "${name}" is no longer available.`);
	for (const entry of delta.updated) if (delta.kind === "tool") lines.push(`The tool "${entry.name}" was updated.`);
	else lines.push(`The ${singular} "${entry.name}" was updated:`, catalogLine(entry));
	lines.push(`${rosterLabel}: ${roster.join(", ")}`);
	return lines.join("\n");
}
function catalogLine(entry) {
	return entry.description ? `- **${entry.name}** — ${entry.description}` : `- **${entry.name}**`;
}
/**
* The `environment` signal body: a deliberate FULL snapshot, not a delta.
* An environment swap can be tool-invisible (a virtual `bash` replaced by a
* container `bash`) while changing everything the model believed about its
* filesystem, so this signal is emitted unconditionally on every swap and
* restates the complete current state — verbose over ambiguous, on purpose.
* Tools are names-only (descriptions and schemas reach the model natively in
* the tools array); skills and agents keep catalog-shape lines because their
* frozen presentation surfaces (prompt catalog, task roster) may be stale.
*/
/**
* Body of the `resources` signal announcing optional MCP connections that
* failed to resolve for this submission. Factual, one line per server; the
* reason is the resolve error's message, truncated.
*/
function renderMcpUnavailableSignalBody(unavailable) {
	const reason = (text) => text.length > 300 ? `${text.slice(0, 300)}…` : text;
	if (unavailable.length === 1) {
		const entry = unavailable[0];
		return `MCP server "${entry.name}" is unavailable for this response: ${reason(entry.reason)}. Its tools are not mounted.`;
	}
	return ["MCP servers unavailable for this response (their tools are not mounted):", ...unavailable.map((entry) => `- "${entry.name}" — ${reason(entry.reason)}`)].join("\n");
}
function renderEnvironmentSignalBody(snapshot) {
	const lines = [
		"The agent's execution environment (sandbox) was replaced.",
		snapshot.cwd !== void 0 ? `The current working directory is now \`${snapshot.cwd}\`.` : "There is no sandbox anymore: shell and filesystem tools are unavailable.",
		"Files, directories, and command results from the previous environment may no longer be accessible — do not rely on anything learned about the previous environment without re-verifying it here, unless instructed otherwise.",
		"",
		`All available tools: ${snapshot.tools.length > 0 ? snapshot.tools.join(", ") : "(none)"}`
	];
	if (snapshot.skills.length > 0) {
		lines.push("All available skills:");
		for (const entry of snapshot.skills) lines.push(catalogLine(entry));
	} else lines.push("All available skills: (none)");
	if (snapshot.subagents.length > 0) {
		lines.push("All available agents:");
		for (const entry of snapshot.subagents) lines.push(catalogLine(entry));
	} else lines.push("All available agents: (none)");
	return lines.join("\n");
}
//#endregion
//#region src/shell.ts
/**
* Run `command` through `env.exec` wrapped in the bash tool-event envelope:
* a `tool_start` emit up front, then a terminal `tool` emit carrying either
* the formatted bash result or the `details: { command, exitCode: -1 }`
* error-result shape. The optional `record` hook runs before each terminal
* emit so `session.shell()` can append its transcript triple at the same
* point in the sequence on both branches.
*/
async function execShellWithEvents(env, emit, command, options, signal, executionContext, record) {
	const toolCallId = generateToolCallId();
	const startedAt = Date.now();
	const args = { command };
	if (options?.cwd !== void 0) args.cwd = options.cwd;
	if (options?.env !== void 0) args.env = redactEnvValues(options.env);
	emit({
		type: "tool_start",
		toolName: "bash",
		toolCallId
	}, {
		origin: "caller",
		args
	});
	try {
		const result = await interceptExecution({
			type: "tool",
			toolCallId,
			toolName: "bash"
		}, executionContext, () => env.exec(command, {
			env: options?.env,
			cwd: options?.cwd,
			timeoutMs: options?.timeoutMs,
			signal
		}));
		const shellResult = {
			stdout: result.stdout,
			stderr: result.stderr,
			exitCode: result.exitCode
		};
		const toolResult = formatBashResult(shellResult, command);
		await record?.(toolCallId, args, toolResult, false);
		emit({
			type: "tool",
			toolName: "bash",
			toolCallId,
			isError: false,
			result: toolResult,
			durationMs: Date.now() - startedAt
		}, { origin: "caller" });
		return shellResult;
	} catch (error) {
		const errResult = {
			content: [{
				type: "text",
				text: getErrorMessage(error)
			}],
			details: {
				command,
				exitCode: -1
			}
		};
		await record?.(toolCallId, args, errResult, true);
		emit({
			type: "tool",
			toolName: "bash",
			toolCallId,
			isError: true,
			result: errResult,
			durationMs: Date.now() - startedAt
		}, {
			origin: "caller",
			errorInfo: classifyShellError(error)
		});
		throw error;
	}
}
function classifyShellError(error) {
	if (error instanceof DOMException && error.name === "AbortError") return {
		type: "AbortError",
		name: error.name,
		message: error.message
	};
	if (error instanceof Error) return {
		type: error.name || "_OTHER",
		name: error.name,
		message: error.message
	};
	return {
		type: "_OTHER",
		...typeof error === "string" ? { message: error } : {}
	};
}
function getErrorMessage(error) {
	return error instanceof Error ? error.message : String(error);
}
function redactEnvValues(env) {
	return Object.fromEntries(Object.keys(env).map((key) => [key, "<redacted>"]));
}
//#endregion
//#region src/session.ts
const MAX_DELEGATION_DEPTH = 4;
const MAX_TRANSIENT_MODEL_RETRIES = 3;
/**
* Defense-in-depth ceiling on `useAgentFinish` continuations per response —
* far above sane usage (each continuation costs a model turn), matching the
* result-tools follow-up ceiling. Not configurable: the submission's
* durability timeout is the real budget; this only guards a hook that appends
* unconditionally.
*/
const MAX_AGENT_FINISH_CYCLES = 32;
const TRANSIENT_MODEL_RETRY_BASE_DELAY_MS = 2e3;
function toolResultText(value) {
	const content = value.content;
	if (content.length === 1 && content[0]?.type === "text") return content[0].text;
	return content;
}
function toTurnMessage(message) {
	if (message.role === "signal") return {
		role: "user",
		content: renderSignalMessage(message)
	};
	if (message.role === "user") return {
		role: "user",
		content: typeof message.content === "string" ? message.content : message.content.map(toTurnContent)
	};
	if (message.role === "assistant") return {
		role: "assistant",
		content: message.content.map(toTurnContent)
	};
	if (message.role === "toolResult") return {
		role: "toolResult",
		toolCallId: message.toolCallId,
		toolName: message.toolName,
		content: message.content.map(toTurnContent),
		isError: message.isError
	};
	throw new Error(`[flue] Unsupported message role in turn context: ${message.role}`);
}
function toTurnContent(block) {
	if (block.type === "text") return {
		type: "text",
		text: block.text,
		textSignature: block.textSignature
	};
	if (block.type === "image") return {
		type: "image",
		data: IMAGE_DATA_OMITTED,
		mimeType: block.mimeType
	};
	if (block.type === "thinking") return {
		type: "thinking",
		thinking: block.thinking,
		thinkingSignature: block.thinkingSignature,
		redacted: block.redacted
	};
	return {
		type: "toolCall",
		id: block.id,
		name: block.name,
		arguments: block.arguments,
		thoughtSignature: block.thoughtSignature
	};
}
function getRegisteredPackagedSkills(skills) {
	const registered = {};
	for (const skill of Object.values(skills)) if ("__flueSkillReference" in skill) {
		const packaged = getSkillReferenceDirectory(skill);
		if (packaged) registered[skill.id] = packaged;
	} else if (isSkillDefinition(skill)) {
		const packaged = packageSkillDefinition(skill);
		registered[packaged.id] = packaged;
	}
	return registered;
}
function wrapProviderStream(stream, operation, executionContext) {
	return {
		[Symbol.asyncIterator]() {
			const iterator = stream[Symbol.asyncIterator]();
			const returnIterator = iterator.return?.bind(iterator);
			const throwIterator = iterator.throw?.bind(iterator);
			return {
				next: () => interceptExecution(operation, executionContext, () => iterator.next()),
				return: returnIterator ? () => interceptExecution(operation, executionContext, returnIterator) : void 0,
				throw: throwIterator ? (error) => interceptExecution(operation, executionContext, () => throwIterator(error)) : void 0
			};
		},
		result() {
			return interceptExecution(operation, executionContext, () => stream.result());
		}
	};
}
function parseProviderEndpoint(value) {
	if (!value) return void 0;
	try {
		const url = new URL(value);
		return {
			address: url.hostname,
			...url.port ? { port: Number(url.port) } : {}
		};
	} catch {
		return;
	}
}
function modelRetryDelayMs(attempt) {
	const baseDelay = TRANSIENT_MODEL_RETRY_BASE_DELAY_MS * 2 ** (attempt - 1);
	return Math.round(baseDelay * (.75 + Math.random() * .25));
}
function sleepUntilRetry(delayMs, signal) {
	if (signal.aborted) return Promise.reject(abortErrorFor(signal));
	return new Promise((resolve, reject) => {
		const timer = setTimeout(() => {
			signal.removeEventListener("abort", onAbort);
			resolve();
		}, delayMs);
		const onAbort = () => {
			clearTimeout(timer);
			signal.removeEventListener("abort", onAbort);
			reject(abortErrorFor(signal));
		};
		signal.addEventListener("abort", onAbort, { once: true });
	});
}
var Session = class {
	name;
	conversationId;
	fs;
	agentLoop;
	affinityKey;
	config;
	/**
	* The session's environment, read through the (possibly shared) slot so
	* a turn-boundary swap is visible to every consumer at its next call —
	* tool-group rebuilds, `session.shell()`, task creation, the fs facade.
	*/
	envSlot;
	/**
	* The live environment when a sandbox is attached, else `undefined`.
	* Consumers that degrade gracefully (tool assembly, narration, discovery)
	* read this one.
	*/
	get attachedEnv() {
		return this.envSlot.env;
	}
	/**
	* The live environment, required. Sandbox-backed operations (`shell()`,
	* `fs`, workspace-skill reads) throw here when the agent declared no
	* sandbox — there is no default environment.
	*/
	get env() {
		const env = this.envSlot.env;
		if (!env) throw new Error("[flue] This agent has no sandbox. Declare one with useSandbox() to use shell and filesystem operations.");
		return env;
	}
	get toolFactory() {
		return this.envSlot.toolFactory;
	}
	envRuntime;
	compactionAbortController;
	modelRetryAbortController;
	eventCallback;
	agentTools;
	/**
	* Optional MCP connections that failed to resolve when this submission
	* initialized, announced once per session before the model's first turn.
	*/
	mcpUnavailable;
	mcpUnavailableNarrated = false;
	closed = false;
	activeOperation;
	activeOperationId;
	activeAgentInput;
	activeOperationSettlement = Promise.resolve();
	resolveActiveOperationSettlement;
	closePromise;
	activeToolCalls = /* @__PURE__ */ new Map();
	modelToolTelemetry = /* @__PURE__ */ new WeakMap();
	activeTurnId;
	/** Per-turn request telemetry, set at `turn_request` and cleared at the turn's end. */
	modelRequests = /* @__PURE__ */ new Map();
	activeTasks = /* @__PURE__ */ new Set();
	activeActionHarnesses = /* @__PURE__ */ new Set();
	delegationDepth;
	createTaskSession;
	createActionHarness;
	scopeSignal;
	activeCallOverrides;
	onClose;
	activeTimeoutAt;
	activeSubmissionId;
	activeSubmissionAttemptId;
	conversationWriter;
	attachmentStore;
	canonicalAssistant;
	canonicalToolRequestMessageId;
	/**
	* The just-committed tool batch, stashed by the `turn_end` handler for the
	* `prepareNextTurn` rerender that runs immediately after it — tool
	* additions that rerender unlocks anchor to this batch's final result.
	*/
	lastCommittedToolBatch;
	pendingCanonicalWrites = /* @__PURE__ */ new Set();
	pendingToolPublications = /* @__PURE__ */ new Map();
	executionIdentity;
	hookState;
	rerender;
	outputChannel;
	advanceDelivery;
	/**
	* Dynamic resources. The live maps track the CURRENT render (skill
	* activation and task resolution always see what the agent declares now);
	* the baseline roster freezes the task tool's description so a resource
	* flip never rewrites the tool spec; `lastNarratedResources` is the
	* in-memory copy of the durable diff base, advanced only after its
	* snapshot record commits.
	*/
	resourceRuntime;
	liveSkills;
	liveSubagents;
	lastNarratedResources;
	lastRenderedResources;
	/** First assistant messageId of the active submission (the response message). */
	responseMessageId;
	/** Whether the active submission has a durably completed assistant step (the data-write anchor). */
	responseHasCompletedStep = false;
	/** Aggregate usage across the active submission's completed assistant steps. */
	responseUsage;
	/** Merged `useResponseStart` metadata, stamped onto the response's first started record. */
	responseStartMetadata;
	/** Ordered append chain for `useDataWriter` writes; awaited before the response settles. */
	outputWriteQueue = Promise.resolve();
	/**
	* `useDataWriter` writes made before the response's first durable
	* assistant step exists (`useAgentStart` and other pre-turn-1 callbacks):
	* canonical data-write records need a completed step to anchor to, so
	* these buffer until the first one commits and flush with it, in order.
	*/
	pendingPreAnchorDataWrites = [];
	/**
	* Lifecycle-callback appends (`ctx.append` in `useAgentStart`/
	* `useAgentFinish`) buffered since the last flush point, in call order.
	* Appends are steered into the live loop immediately (the model sees
	* them at the next turn start) and their canonical records flush
	* batch-atomically with their callback's outcome — a start hook's
	* adoption batch, or a finish cycle's record batch. Appends can only
	* happen inside those callback windows, so those two batches are the
	* only durability points.
	*/
	pendingSignalAppends = [];
	/**
	* Turn-boundary join seam for the active submission (dispatch-while-busy),
	* bound to the host attempt by the coordinator. Set for the duration of
	* `runPersistedContextInput`; absent everywhere else (subagent sessions,
	* prompt() operations, degenerate/test setups), where the queue serializes
	* exactly as before.
	*/
	activeJoinSource;
	/** The active submission's abort signal, for join work at turn boundaries. */
	activeJoinSignal;
	/** The active submission's canonical input entry id (delivery-cursor floor). */
	activeInputEntryId;
	emitTurnRequestAndStream = async (model, context, options) => {
		if (this.activeTurnId === void 0) this.activeTurnId = generateTurnId();
		const turnId = this.activeTurnId;
		const operationId = this.activeOperationId ?? generateOperationId();
		this.emitTurnRequest(turnId, "agent", model, context, options);
		const operation = {
			type: "model",
			turnId
		};
		const executionContext = this.executionContext({
			operationId,
			turnId
		});
		return interceptExecution(operation, executionContext, async () => wrapProviderStream(getRuntimeModels().streamSimple(model, context, options), operation, executionContext));
	};
	canonicalEnvelope(type, id = generateConversationRecordId()) {
		return {
			v: 1,
			id,
			type,
			conversationId: this.conversationId,
			harness: this.executionIdentity.harness ?? "default",
			session: this.name,
			timestamp: (/* @__PURE__ */ new Date()).toISOString(),
			...this.activeSubmissionId ? { submissionId: this.activeSubmissionId } : {},
			...this.activeSubmissionAttemptId ? { attemptId: this.activeSubmissionAttemptId } : {},
			...this.activeOperationId ? { operationId: this.activeOperationId } : {},
			...this.activeTurnId ? { turnId: this.activeTurnId } : {}
		};
	}
	canonicalAppendOptions() {
		const submission = this.activeSubmissionId && this.activeSubmissionAttemptId ? {
			submissionId: this.activeSubmissionId,
			attemptId: this.activeSubmissionAttemptId
		} : void 0;
		return submission ? { submission } : {};
	}
	appendCanonical(records) {
		return this.conversationWriter.append(records, this.canonicalAppendOptions());
	}
	enqueueCanonical(records, publish) {
		const pending = this.conversationWriter.enqueue(records, this.canonicalAppendOptions()).then(() => publish());
		let tracked;
		tracked = pending.finally(() => this.pendingCanonicalWrites.delete(tracked));
		this.pendingCanonicalWrites.add(tracked);
		tracked.catch(() => {});
	}
	async flushCanonical() {
		const results = await Promise.allSettled([this.conversationWriter.flush(), ...this.pendingCanonicalWrites]);
		for (const result of results) if (result.status === "rejected") throw result.reason;
	}
	/**
	* Render-per-turn: re-render the agent function and hand the
	* loop a replacement context for its next provider request. The wrapper's
	* `state.messages` tracks the run (every assistant/tool-result message got
	* a `message_end`), so the rebuilt context loses nothing. Also syncs the
	* wrapper state so later runs snapshot the fresh values. An invariance
	* violation (conditional use()/hook) throws here and fails the run.
	*/
	async prepareRerenderTurn(turn) {
		if (!this.rerender) return void 0;
		let next = this.rerender();
		const swapped = await this.maybeSwapEnvironment(next);
		if (swapped) next = this.rerender();
		this.agentTools = next.tools;
		this.liveSkills = next.resources.skills;
		this.liveSubagents = next.resources.subagents;
		this.lastRenderedResources = next.resources;
		const overrides = this.activeCallOverrides;
		const tools = this.assembleModelTools(this.createBuiltinToolGroups(this.attachedEnv, overrides?.model, overrides?.thinkingLevel, overrides?.activePackagedSkills), overrides ? [...this.agentTools, ...overrides.tools] : this.agentTools, overrides?.extraTools ?? []);
		this.agentLoop.state.tools = tools;
		this.agentLoop.state.systemPrompt = next.systemPrompt;
		const anchorResult = turn?.toolResults.at(-1);
		const anchor = anchorResult && this.lastCommittedToolBatch?.toolCallId === anchorResult.toolCallId ? {
			assistantMessageId: this.lastCommittedToolBatch.assistantMessageId,
			toolResult: anchorResult
		} : void 0;
		if (swapped) await this.narrateEnvironmentSnapshot(next.resources.snapshot);
		else await this.narrateResourceDelta(anchor);
		return { context: {
			systemPrompt: next.systemPrompt,
			messages: this.agentLoop.state.messages.slice(),
			tools: this.agentLoop.state.tools
		} };
	}
	/**
	* Swap the environment when the render's `useSandbox()` presence flipped
	* since the environment was last resolved. Presence is the only reliable
	* observation (factories are fresh objects every render), so an A→B swap
	* that keeps the hook present takes effect at the next submission's
	* initialization instead. Attach and detach both land here: detach
	* removes the environment entirely — the built-in shell/fs tools drop
	* with it. The declared `cwd` re-applies exactly as initialization
	* applies it.
	*/
	async maybeSwapEnvironment(next) {
		if (!this.envRuntime || !this.resourceRuntime) return false;
		if (next.sandbox !== void 0 === (this.envSlot.env !== void 0)) return false;
		const { env: baseEnv, toolFactory } = await this.envRuntime.resolve(next.sandbox);
		const env = baseEnv && next.cwd !== void 0 ? createCwdSandbox(baseEnv, baseEnv.resolvePath(next.cwd)) : baseEnv;
		this.envSlot.env = env;
		this.envSlot.toolFactory = toolFactory;
		this.envSlot.rediscoverNeeded = true;
		await this.envRuntime.swapDiscovery(env);
		return true;
	}
	/**
	* The environment swap's narration: ONE `environment` signal restating
	* the complete current state (cwd + full tool/skill/agent rosters),
	* emitted unconditionally — a swap can be tool-invisible while changing
	* everything the model believed about its filesystem, so there is no
	* delta to trust. Supersedes that boundary's delta narration: the
	* narrated snapshot syncs to the current render batch-atomically with
	* the signal, so the reconciler never restates the same change as
	* deltas one turn later. The snapshot record is NON-baseline — baseline
	* stays reserved for states the system prompt was actually composed
	* from (first contact, compaction).
	*/
	async narrateEnvironmentSnapshot(current) {
		if (!this.resourceRuntime || !this.activeSubmissionId) return;
		const previous = this.lastNarratedResources;
		const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
		const records = [];
		if (!previous) records.push(this.resourceSnapshotRecord(this.resourceRuntime.initial.snapshot, true));
		else if (instructionsChanged(previous, current)) this.enqueueSignalAppend({
			type: "instructions",
			body: INSTRUCTIONS_UPDATED_SIGNAL_BODY
		}, { advance: false });
		this.enqueueSignalAppend({
			type: "environment",
			body: renderEnvironmentSignalBody({
				cwd: this.attachedEnv?.cwd,
				tools: this.agentLoop.state.tools.map((tool) => tool.name),
				skills: Object.values(this.liveSkills).map((skill) => ({
					name: skill.name,
					...skill.description ? { description: skill.description } : {}
				})),
				subagents: Object.values(this.liveSubagents).map((subagent) => ({
					name: subagent.name,
					description: subagent.description
				}))
			})
		}, { advance: false });
		const { records: signalRecords } = this.drainSignalAppendRecords(parentId);
		await this.appendCanonical([
			...records,
			...signalRecords,
			this.resourceSnapshotRecord(current, false)
		]);
		this.lastNarratedResources = current;
	}
	/**
	* The dynamic-resources reconciler: diff the latest render's declared
	* sets against the durable last-narrated snapshot and announce the delta
	* — one `resources` signal per changed kind (delta lines + the kind's
	* current roster), plus an `instructions` signal (announcement only, no
	* diff — the live prompt already IS the new version) when the composed
	* instruction document's digest moved. All batch-atomic with the updated
	* `resource_snapshot` record. Crash between steer and commit re-diffs on
	* the re-attempt and emits again; a committed batch never re-narrates.
	* First contact (no durable snapshot) records the current render as the
	* silent baseline — it IS what the frozen presentation surfaces were
	* composed from.
	*/
	async narrateResourceDelta(anchor) {
		const rendered = this.lastRenderedResources;
		if (!this.resourceRuntime || !rendered || !this.activeSubmissionId) return;
		const current = rendered.snapshot;
		const previous = this.lastNarratedResources;
		if (!previous) {
			await this.appendCanonical([this.resourceSnapshotRecord(current, true)]);
			this.lastNarratedResources = current;
			return;
		}
		const deltas = diffResourceSnapshots(previous, current);
		const instructionsUpdated = instructionsChanged(previous, current);
		if (deltas.length === 0 && !instructionsUpdated) return;
		const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
		if (instructionsUpdated) this.enqueueSignalAppend({
			type: "instructions",
			body: INSTRUCTIONS_UPDATED_SIGNAL_BODY
		}, { advance: false });
		for (const delta of deltas) this.enqueueSignalAppend({
			type: "resources",
			body: renderResourceSignalBody(delta, this.resourceRoster(delta.kind)),
			attributes: { resource: delta.kind }
		}, { advance: false });
		const addedToolNames = anchor ? deltas.find((delta) => delta.kind === "tool")?.added.map((entry) => entry.name) ?? [] : [];
		const toolAddition = anchor && addedToolNames.length > 0 ? {
			assistantMessageId: anchor.assistantMessageId,
			toolCallId: anchor.toolResult.toolCallId,
			names: addedToolNames
		} : void 0;
		if (toolAddition && anchor) anchor.toolResult.addedToolNames = toolAddition.names;
		const { records } = this.drainSignalAppendRecords(parentId);
		await this.appendCanonical([...records, this.resourceSnapshotRecord(current, false, toolAddition)]);
		this.lastNarratedResources = current;
	}
	/**
	* Announce optional MCP connections that failed to resolve for this
	* submission: one `resources` signal naming the servers and reasons,
	* before the model's first turn. Once per session — a crashed attempt
	* re-initializes (and re-resolves the connections), so a re-attempt
	* re-narrates only when the servers are still down.
	*/
	async narrateMcpUnavailable() {
		if (this.mcpUnavailableNarrated || this.mcpUnavailable.length === 0) return;
		if (!this.activeSubmissionId) return;
		const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
		this.enqueueSignalAppend({
			type: "resources",
			body: renderMcpUnavailableSignalBody(this.mcpUnavailable),
			attributes: { resource: "mcp" }
		}, { advance: false });
		const { records } = this.drainSignalAppendRecords(parentId);
		await this.appendCanonical(records);
		this.mcpUnavailableNarrated = true;
	}
	/** The names-only roster line of one resource kind, as the model sees it. */
	resourceRoster(kind) {
		switch (kind) {
			case "skill": return Object.keys(this.liveSkills);
			case "tool": return this.agentLoop.state.tools.map((tool) => tool.name);
			case "subagent": return Object.keys(this.liveSubagents);
		}
	}
	resourceSnapshotRecord(snapshot, baseline, toolAddition) {
		return {
			...this.canonicalEnvelope("resource_snapshot"),
			type: "resource_snapshot",
			baseline,
			snapshot,
			...toolAddition ? { toolAddition } : {}
		};
	}
	/**
	* Compaction rebaseline: the post-compaction system prompt snapshots the
	* CURRENT resource state — skill catalog and task roster included — just
	* as the agent's first message did, so the pre-compaction add/remove
	* bookkeeping stops mattering. Narrated advances with the baseline (the
	* new prompt already tells the model everything; no signal needed).
	*
	* Owns the compaction record's append so the baseline snapshot rides the
	* SAME batch: separate appends left a crash window where the context was
	* durably compacted but the frozen baseline (and the env-swap rediscovery
	* truth point) never advanced — a restart then recomposed pre-compaction
	* catalogs/workspace over a post-compaction transcript until the next
	* compaction. In-memory swaps land only after the single durable point.
	*/
	async rebaselineResources(compactionRecord) {
		if (!this.resourceRuntime || !this.rerender || !this.lastRenderedResources) {
			await this.appendCanonical([compactionRecord]);
			return;
		}
		if (this.envRuntime && this.envSlot.rediscoverNeeded) {
			await this.envRuntime.rediscover(this.attachedEnv);
			this.envSlot.rediscoverNeeded = false;
		}
		const refreshed = this.rerender();
		const current = refreshed.resources.snapshot;
		await this.appendCanonical([compactionRecord, this.resourceSnapshotRecord(current, true)]);
		this.lastNarratedResources = current;
		this.agentTools = refreshed.tools;
		this.liveSkills = refreshed.resources.skills;
		this.liveSubagents = refreshed.resources.subagents;
		this.lastRenderedResources = refreshed.resources;
		this.resourceRuntime.rebaseline(current);
		this.agentLoop.state.systemPrompt = this.rerender().systemPrompt;
		const overrides = this.activeCallOverrides;
		this.agentLoop.state.tools = this.assembleModelTools(this.createBuiltinToolGroups(this.attachedEnv, overrides?.model, overrides?.thinkingLevel, overrides?.activePackagedSkills), overrides ? [...this.agentTools, ...overrides.tools] : this.agentTools, overrides?.extraTools ?? []);
	}
	/**
	* Sink for `useDataWriter` writers. Unlike `usePersistentState` writes (buffered,
	* batch-atomic), data writes append immediately — live client progress is
	* their whole point. The writer API is synchronous, so appends chain on an
	* ordered queue; the queue is awaited before the response settles, and an
	* append failure there fails the submission (fail fast, never silent).
	* The one exception: writes made before the response's first assistant
	* step completes buffer until that anchor commits (the record projection
	* anchors data parts to a completed step).
	*/
	enqueueMessageDataWrite(name, data) {
		if (!this.activeSubmissionId) throw new Error(`[flue] Message data "${name}" can only be written while the agent is responding — write from tool run functions (and other callbacks that run during a submission).`);
		if (!this.responseHasCompletedStep) {
			this.pendingPreAnchorDataWrites.push({
				name,
				data
			});
			return;
		}
		const record = {
			...this.canonicalEnvelope("message_data_write"),
			type: "message_data_write",
			name,
			data
		};
		const attemptId = this.activeSubmissionAttemptId;
		const pending = this.outputWriteQueue.then(() => this.activeSubmissionAttemptId === attemptId ? this.appendCanonical([record]) : void 0);
		this.outputWriteQueue = pending;
		pending.catch(() => {});
	}
	/**
	* Flush data writes buffered before the response's first completed
	* assistant step, in write order. Runs at the moment the anchor commits;
	* writes buffered by an attempt that never completes a step die with it,
	* like every other live write of a failed attempt.
	*/
	flushPreAnchorDataWrites() {
		const writes = this.pendingPreAnchorDataWrites;
		this.pendingPreAnchorDataWrites = [];
		for (const write of writes) this.enqueueMessageDataWrite(write.name, write.data);
	}
	/**
	* Sink for `ctx.append` writes from lifecycle callbacks and for framework
	* narration. The signal is steered into the live agent loop immediately —
	* the model reads it at the next turn start — and buffered for canonical
	* append with the owning callback's batch (`drainSignalAppendRecords`).
	* Steering and the durable flush happen in the same order at the same
	* boundary, so the live context and a rehydrated one can never disagree.
	* `advance: false` (framework narration only) keeps the signal out of the
	* `useDelivery()` cursor: narration is bookkeeping about the agent's own
	* declared surface, not an input the response is answering.
	*/
	enqueueSignalAppend(signal, options) {
		if (!this.activeSubmissionId) throw new Error("[flue] append() is only legal while the agent is responding to a submission. An appended signal steers the running response; to send input at any other time, use the dispatcher from useDispatchMessage().");
		const timestamp = (/* @__PURE__ */ new Date()).toISOString();
		this.pendingSignalAppends.push({
			messageId: generateConversationEntryId(),
			timestamp,
			signalType: signal.type,
			...signal.tagName ? { tagName: signal.tagName } : {},
			content: signal.body,
			...signal.attributes ? { attributes: signal.attributes } : {}
		});
		this.agentLoop.steer(createUserContextMessage(renderSignalMessage({
			role: "signal",
			type: signal.type,
			tagName: signal.tagName,
			content: signal.body,
			attributes: signal.attributes,
			timestamp: new Date(timestamp).getTime()
		}), timestamp));
		if (options?.advance === false) return;
		this.advanceDelivery?.({
			kind: "signal",
			type: signal.type,
			body: signal.body,
			...signal.attributes ? { attributes: signal.attributes } : {},
			...signal.tagName ? { tagName: signal.tagName } : {}
		});
	}
	/**
	* Turn buffered finish-continuation appends into canonical `signal`
	* records chained linearly after `parentId`, returning the new leaf.
	* Callers must append the records in the same batch (or immediately
	* after) whatever made `parentId` the conversation tail.
	*/
	drainSignalAppendRecords(parentId) {
		if (this.pendingSignalAppends.length === 0) return {
			records: [],
			leafId: parentId
		};
		const drained = this.pendingSignalAppends;
		this.pendingSignalAppends = [];
		let leafId = parentId;
		return {
			records: drained.map((pending) => {
				const record = {
					...this.canonicalEnvelope("signal"),
					timestamp: pending.timestamp,
					type: "signal",
					messageId: pending.messageId,
					parentId: leafId,
					signalType: pending.signalType,
					...pending.tagName ? { tagName: pending.tagName } : {},
					content: pending.content,
					...pending.attributes ? { attributes: pending.attributes } : {}
				};
				leafId = pending.messageId;
				return record;
			}),
			leafId
		};
	}
	/**
	* Run one delivery's start seam: evaluate the render's `useAgentStart`
	* declarations after the input record, before the model's next turn. The
	* callbacks run CONCURRENTLY, in no guaranteed order — event hooks are
	* independent units with no durable identity; work that needs ordering
	* composes into one hook. The seam commits atomically once every callback
	* settles: appended signals (steered in declaration order, so concurrency
	* never makes the conversation racy), buffered state writes, and one
	* per-delivery `agent_start_run` marker in a single append batch — the
	* marker is written for every delivery, hooks or not. Adoption is the
	* marker: a re-entry for a delivery that has one skips the seam wholesale;
	* a crash before it left nothing durable and re-runs every callback
	* (at-least-once). A resume re-entry whose response already has durable
	* assistant steps also skips: start hooks had their chance before turn one
	* of the original attempt. A throw fails the submission (fail-fast, like
	* the `useResponseStart` hooks).
	*/
	async runAgentStartHooks(signal, submissionId = this.activeSubmissionId, options) {
		if (!this.outputChannel || !submissionId) return;
		if (!options?.joined && this.responseHasCompletedStep) return;
		if (await this.hasAgentStartRun(submissionId)) return;
		if (options?.joined) await this.prepareRerenderTurn();
		const declarations = this.outputChannel.agentStarts;
		const outcomes = await Promise.allSettled(declarations.map((hook, index) => this.executeAgentStartHook(index, hook, signal)));
		const failures = outcomes.flatMap((outcome) => outcome.status === "rejected" ? [outcome.reason] : []);
		if (failures.length === 1) throw failures[0];
		if (failures.length > 1) throw new AggregateError(failures, "[flue] Multiple useAgentStart callbacks threw.");
		for (const outcome of outcomes) {
			if (outcome.status !== "fulfilled") continue;
			for (const message of outcome.value) this.enqueueSignalAppend(message);
		}
		const parentId = this.pendingSignalAppends.length > 0 ? await this.conversationWriter.getConversationLeaf(this.conversationId) : null;
		const { records: signalRecords } = this.drainSignalAppendRecords(parentId);
		await this.appendCanonical([
			...signalRecords,
			...this.drainHookStateRecords(),
			{
				...this.canonicalEnvelope("agent_start_run"),
				submissionId,
				type: "agent_start_run"
			}
		]);
	}
	/**
	* All durable records of one type for this conversation and submission, in
	* stream order. Records are submission-keyed, so this spans every turn of
	* every prior attempt. Root conversation only: a delegate's records belong
	* to its own detached task. Yields the reducer's index values — the full
	* record for retained types, the typed stub for slimmed ones.
	*/
	async submissionRecords(type, submissionId) {
		const records = [];
		for (const record of (await this.conversationWriter.loadReducedState()).recordsById.values()) {
			if (record.type !== type) continue;
			const scope = record;
			if (scope.conversationId === this.conversationId && scope.submissionId === submissionId) records.push(record);
		}
		return records;
	}
	/** Whether the delivery's start seam already committed its marker. */
	async hasAgentStartRun(submissionId) {
		return (await this.submissionRecords("agent_start_run", submissionId)).length > 0;
	}
	/**
	* Run one `useAgentStart` callback and collect its appends. Callbacks run
	* concurrently, so nothing commits here: appends are validated at call
	* time and buffered per callback (the seam steers and flushes them in
	* declaration order once every callback settles), state writes ride the
	* shared attempt buffer, and the seam owns the single durable batch. The
	* harness materializes on first access (a callback that never touches it
	* pays nothing) and closes when the run settles; the invocation id is per
	* execution attempt, like harness-connected tools. Same window rule as
	* the finish-context writer: append is legal only while the callback
	* runs.
	*/
	async executeAgentStartHook(index, hook, signal) {
		let harness;
		let appendWindowOpen = true;
		const appends = [];
		const session = this;
		const ctx = {
			append: (message) => {
				if (!appendWindowOpen) throw new Error("[flue] append() was called after its useAgentStart callback settled. The append window is the callback itself — to send input at any other time, use the dispatcher from useDispatchMessage().");
				appends.push(assertAppendMessage(message));
			},
			log: this.createHookLogger("useAgentStart", index),
			signal,
			get harness() {
				harness ??= session.createInvocationHarness(generateInvocationId(), signal);
				return harness;
			}
		};
		try {
			await hook.run(ctx);
		} catch (error) {
			throw new Error(`[flue] A useAgentStart callback (hook #${index} in declaration order) threw: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
		} finally {
			appendWindowOpen = false;
			if (harness) {
				this.activeActionHarnesses.delete(harness);
				await harness.close();
			}
		}
		return appends;
	}
	/**
	* The would-stop seam: the model has no more tool calls and the response
	* is about to settle. Two kinds of work interleave here, in a strict
	* order per iteration:
	*
	* 1. **Late-arrival joins** — queued dispatch deliveries claim-joined and
	*    driven as continuation turns. The agent is not "finally done" while
	*    delivered input awaits, so joins always drain BEFORE any finish
	*    evaluation. (Deliveries arriving mid-run join at turn boundaries
	*    inside the loop; this drain covers only the race where one lands
	*    after the loop's final steering poll.)
	* 2. **`useAgentFinish` cycles** — each cycle runs every declaration
	*    sequentially; if any appended a signal, the cycle is recorded
	*    batch-atomically with its signal records and the loop continues with
	*    another turn (the appends were steered live; `continue()` runs
	*    them). A dispatch made during a finish callback is a real delivery:
	*    it joins on the next iteration and re-fires the hooks at the new
	*    true end. Joined continuations never count against the append-cycle
	*    ceiling.
	*
	* The response settles only when the queue is empty AND a finish cycle
	* completes with no appends.
	*
	* Resume-safe by records: a continued cycle or an applied join whose
	* continuation turn never ran (crash between the durable batch and the
	* turn) classifies `completed` upstream with trailing unanswered entries
	* — detected here and driven before the next evaluation, so a resumed
	* response neither re-runs a completed cycle nor appends twice. The cycle
	* count derives from durable records, so the runaway ceiling survives
	* restarts. The submission's durability timeout remains the total
	* wall-clock backstop — neither continuations nor joins extend it.
	*/
	async runWouldStopPhase(options) {
		const submissionId = this.activeSubmissionId;
		if (!submissionId) return;
		const driveContinuation = async () => {
			await this.runModelTurnWithRecovery({
				start: () => this.agentLoop.continue(),
				signal: options.signal
			});
			this.throwIfError(options.errorLabel);
		};
		if (await this.hasPendingSteeredContinuation(submissionId)) await driveContinuation();
		for (;;) {
			if (await this.applyQueuedJoins() > 0) {
				await driveContinuation();
				continue;
			}
			const hooks = this.outputChannel?.agentFinishes ?? [];
			if (hooks.length === 0) return;
			const cycle = await this.countAgentFinishCycles(submissionId);
			const toolCalls = await this.collectResponseToolCalls(submissionId);
			const before = this.pendingSignalAppends.length;
			for (const [index, hook] of hooks.entries()) await this.executeAgentFinishHook(index, hook, toolCalls, options.signal);
			const stateRecords = this.drainHookStateRecords();
			if (this.pendingSignalAppends.length === before) {
				if (stateRecords.length > 0) await this.appendCanonical(stateRecords);
				if (await this.applyQueuedJoins() === 0) return;
				await driveContinuation();
				continue;
			}
			if (cycle >= MAX_AGENT_FINISH_CYCLES) throw new Error(`[flue] useAgentFinish appended a continuation signal after ${MAX_AGENT_FINISH_CYCLES} continued cycles in one response — a runaway loop. The response is failing loudly instead of settling as a success; if the model cannot satisfy the check, make the hook give up explicitly (log and return) after a bounded number of attempts.`);
			const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
			const { records } = this.drainSignalAppendRecords(parentId);
			await this.appendCanonical([
				...records,
				...stateRecords,
				{
					...this.canonicalEnvelope("agent_finish_cycle"),
					type: "agent_finish_cycle"
				}
			]);
			await driveContinuation();
		}
	}
	/**
	* Whether the response has durably steered content whose continuation
	* turn never ran — the crash window between a durable batch (a continued
	* `useAgentFinish` cycle, or an applied turn-boundary join) and the model
	* turn that answers it. The rebuilt context already ends with the steered
	* entries, so the caller drives `continue()` from them. Trailing
	* straggler signals (flushed after the last boundary, never steered) do
	* NOT count: absent cycle records they settle un-continued, exactly as
	* before.
	*/
	async hasPendingSteeredContinuation(submissionId) {
		const hasCycles = await this.countAgentFinishCycles(submissionId) > 0;
		const joined = this.activeJoinSource ? await this.activeJoinSource.listUnresolved() : [];
		const joinedEntryIds = new Set(joined.map((submission) => submissionEntryId(submission.input.kind, submission.submissionId)));
		if (!hasCycles && joinedEntryIds.size === 0) return false;
		const conversation = await this.requireConversation();
		const path = getActiveConversationPath(conversation);
		for (let i = path.length - 1; i >= 0; i--) {
			const entry = path[i];
			if (entry?.type !== "message") continue;
			if (entry.message.role === "assistant") return false;
			if (joinedEntryIds.has(entry.id)) return true;
			if (entry.message.role === "signal" && hasCycles) return true;
		}
		return false;
	}
	/**
	* Turn-boundary join (dispatch-while-busy): claim the joinable queued
	* prefix and absorb each delivery into the live response — canonical
	* input record, the exact projected message steered into the loop, the
	* delivery's own `useAgentStart` hooks, then the durable `joined`
	* confirmation. Applied strictly in admission order. Claims once per
	* boundary: a delivery dispatched DURING this application (e.g. from a
	* start hook) waits for the next boundary, so every claim sits between
	* model turns and the submission timeout stays the backstop.
	*
	* Returns the number of deliveries applied. No-op outside a submission
	* with a join seam.
	*/
	async applyQueuedJoins() {
		const source = this.activeJoinSource;
		const signal = this.activeJoinSignal;
		if (!source || !signal || !this.activeSubmissionId) return 0;
		const claimed = await source.claim();
		for (const submission of claimed) {
			if (signal.aborted) throw abortErrorFor(signal);
			await this.applyJoinedDelivery(submission, source, signal);
		}
		return claimed.length;
	}
	/**
	* Absorb one claimed delivery. Two-phase against the store: the row is
	* already `joining` (durable intent); the canonical input record makes
	* the join real; `finalize` confirms it `joined`. A crash anywhere in
	* between resolves on the re-attempt by record existence
	* (`resolveInterruptedJoins`) — record present adopts the join, record
	* absent hands the row back to the queue. Errors propagate and fail the
	* host attempt (recovery owns the row either way).
	*/
	async applyJoinedDelivery(submission, source, signal) {
		const input = submission.input;
		const entryId = submissionEntryId(input.kind, input.submissionId);
		if (!await this.conversationWriter.hasConversationEntry(this.conversationId, entryId)) {
			const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
			await this.appendCanonical([await this.buildSubmissionInputRecord(input, parentId, { asJoinedDelivery: true })]);
			await this.steerJoinedEntry(entryId);
		}
		this.advanceDelivery?.(input.message);
		await this.runAgentStartHooks(signal, input.submissionId, { joined: true });
		await source.finalize(input.submissionId);
	}
	/**
	* Steer the joined delivery's message into the live loop as the EXACT
	* message the canonical projection rebuilds from its record — same code
	* path (`buildConversationContextEntries`), so the live context
	* and a rehydrated one can never disagree about what the model saw.
	*/
	async steerJoinedEntry(entryId) {
		const conversation = await this.requireConversation();
		const resolved = await this.resolveCanonicalContextAttachments(conversation);
		const entry = buildConversationContextEntries(conversation, { resolveAttachment: (attachment) => {
			const image = resolved.get(attachment.id);
			if (!image) throw new AttachmentNotAvailableError({ attachmentId: attachment.id });
			return image;
		} }).findLast((candidate) => candidate.sourceEntry.id === entryId);
		if (!entry) throw new Error("[flue] A joined delivery input entry is missing from the projected context.");
		this.agentLoop.steer(entry.message);
	}
	/**
	* Resolve joins a crash interrupted, on the host's re-attempt: a
	* `joining` row whose canonical input record exists becomes `joined`
	* (the rebuilt context already carries it); one whose record never
	* landed reverts to `queued` and runs as its own submission (or re-joins
	* fresh). `joined` rows re-adopt their start hooks — the per-delivery
	* `agent_start_run` marker gates re-runs, so a completed seam is a no-op.
	*/
	async resolveInterruptedJoins(signal) {
		const source = this.activeJoinSource;
		if (!source || !this.activeSubmissionId) return;
		for (const submission of await source.listUnresolved()) {
			const input = submission.input;
			const entryId = submissionEntryId(input.kind, input.submissionId);
			if (submission.status === "joining") {
				if (await this.conversationWriter.hasConversationEntry(this.conversationId, entryId)) {
					this.advanceDelivery?.(input.message);
					await this.runAgentStartHooks(signal, input.submissionId, { joined: true });
					await source.finalize(input.submissionId);
				} else await source.revert(input.submissionId);
				continue;
			}
			this.advanceDelivery?.(input.message);
			await this.runAgentStartHooks(signal, input.submissionId, { joined: true });
		}
		await this.restoreDeliveryCursor();
	}
	/**
	* Point the delivery cursor at the latest input message of the ACTIVE
	* submission on the rebuilt path — a resumed attempt's renders must see
	* the same cursor the crashed attempt's renders saw. Entries at or before
	* the submission's own input entry leave the threaded waking delivery in
	* place; a later signal entry (joined or appended) reconstructs from its
	* record, and a later user entry (a joined `kind: 'user'` delivery)
	* reconstructs its attachments from the attachment store.
	*/
	async restoreDeliveryCursor() {
		const inputEntryId = this.activeInputEntryId;
		if (!this.advanceDelivery || !inputEntryId) return;
		const conversation = await this.requireConversation();
		const path = getActiveConversationPath(conversation);
		const inputIndex = path.findIndex((entry) => entry.id === inputEntryId);
		if (inputIndex === -1) return;
		for (let i = path.length - 1; i > inputIndex; i--) {
			const entry = path[i];
			if (entry?.type !== "message") continue;
			const message = entry.message;
			if (message.role === "signal") {
				if (RESERVED_SIGNAL_TYPES.has(message.type)) continue;
				this.advanceDelivery({
					kind: "signal",
					type: message.type,
					body: message.content,
					...message.attributes ? { attributes: message.attributes } : {},
					...message.tagName ? { tagName: message.tagName } : {}
				});
				return;
			}
			if (message.role !== "user") continue;
			const body = Array.isArray(message.content) ? message.content.filter((block) => block.type === "text").map((block) => "text" in block ? block.text : "").join("\n") : String(message.content);
			const refs = [...entry.attachmentRefs?.values() ?? []];
			const attachments = refs.length > 0 ? await this.resolveCanonicalImages(refs.map((ref) => ref.id)) : void 0;
			this.advanceDelivery({
				kind: "user",
				body,
				...attachments?.length ? { attachments } : {}
			});
			return;
		}
	}
	/** Count durably continued `useAgentFinish` cycles for one submission. */
	async countAgentFinishCycles(submissionId) {
		return (await this.submissionRecords("agent_finish_cycle", submissionId)).length;
	}
	/**
	* Every tool call the response has made so far, from durable
	* `tool_outcome` records in stream order.
	*/
	async collectResponseToolCalls(submissionId) {
		return (await this.submissionRecords("tool_outcome", submissionId)).map((record) => ({
			tool: record.toolName,
			isError: record.isError
		}));
	}
	/**
	* Aggregate usage across the response's durably completed assistant
	* steps — the resume counterpart of the live `message_end` accumulation.
	*/
	async collectResponseUsage(submissionId) {
		let usage;
		for (const record of await this.submissionRecords("assistant_message_completed", submissionId)) {
			const stepUsage = fromProviderUsage(record.usage);
			if (stepUsage) usage = usage ? addUsage(usage, stepUsage) : stepUsage;
		}
		return usage;
	}
	/**
	* Run one `useAgentFinish` callback for the current cycle. Same lazy
	* harness and fail-fast wrapping as the start hooks; appends it makes are
	* steered live and buffered — the cycle driver owns their durable flush.
	*/
	async executeAgentFinishHook(index, hook, toolCalls, signal) {
		let harness;
		let appendWindowOpen = true;
		const session = this;
		const ctx = {
			response: {
				toolCalls,
				usage: this.responseUsage ?? emptyUsage()
			},
			append: (message) => {
				if (!appendWindowOpen) throw new Error("[flue] append() was called after its useAgentFinish callback settled. The continuation window is the callback itself — to send input at any other time, use the dispatcher from useDispatchMessage().");
				this.enqueueSignalAppend(assertAppendMessage(message));
			},
			log: this.createHookLogger("useAgentFinish", index),
			signal,
			get harness() {
				harness ??= session.createInvocationHarness(generateInvocationId(), signal);
				return harness;
			}
		};
		try {
			await hook.run(ctx);
		} catch (error) {
			throw new Error(`[flue] A useAgentFinish callback (hook #${index} in declaration order) threw: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
		} finally {
			appendWindowOpen = false;
			if (harness) {
				this.activeActionHarnesses.delete(harness);
				await harness.close();
			}
		}
	}
	/** `ctx.log` for one lifecycle hook run, attributed by declaration index. */
	createHookLogger(hook, hookIndex) {
		return this.createAttributedLogger({
			hook,
			hookIndex
		});
	}
	/** Shared `{ info, warn, error }` factory behind ctx.log: every call emits
	*  a `log` event with `base` merged onto the caller's own attributes. */
	createAttributedLogger(base) {
		const emit = (level, message, attributes) => this.emit({
			type: "log",
			level,
			message,
			attributes: {
				...attributes,
				...base
			}
		});
		return {
			info: (message, attributes) => emit("info", message, attributes),
			warn: (message, attributes) => emit("warn", message, attributes),
			error: (message, attributes) => emit("error", message, attributes)
		};
	}
	/**
	* Begin the response's client-facing output: reset per-submission tracking
	* and run the `useResponseStart` hooks — the response's wake, once per
	* response, before the first model call and before any `useAgentStart`
	* hook (fail-fast — a throw fails the submission before the model runs). A
	* resume re-entry whose response already has durable assistant steps
	* adopts them instead: the wake hooks ran on the original attempt.
	*/
	async beginResponseOutput() {
		this.responseMessageId = void 0;
		this.responseHasCompletedStep = false;
		this.responseUsage = void 0;
		this.responseStartMetadata = void 0;
		this.outputWriteQueue = Promise.resolve();
		this.pendingPreAnchorDataWrites = [];
		if (!this.activeSubmissionId || !this.outputChannel) return;
		const durableAnchor = (await this.conversationWriter.getConversation(this.conversationId))?.lastAssistantEntryBySubmission.get(this.activeSubmissionId);
		if (durableAnchor) {
			this.responseMessageId = durableAnchor;
			this.responseHasCompletedStep = true;
			this.responseUsage = await this.collectResponseUsage(this.activeSubmissionId);
			return;
		}
		const declarations = this.outputChannel.responseStarts;
		if (declarations.length === 0) return;
		this.responseStartMetadata = runResponseMetadataHooks("useResponseStart", declarations, (metadata, index) => ({
			metadata,
			log: this.createHookLogger("useResponseStart", index)
		}), {});
	}
	/**
	* Settle the response's client-facing output: wait for queued data writes
	* (surfacing any append failure) and run the `useResponseFinish` hooks —
	* the response's true end, once per response, after the last
	* `useAgentFinish` cycle — appending their merged result. Each hook sees
	* the response's accumulated metadata (what the wake hooks attached, read
	* from the durable log so it survives re-attempts) and the final
	* aggregates. Runs inside the submission's normal execution path, so a
	* throw here settles the submission `failed` — no retry, no recovery.
	*/
	async flushResponseOutput() {
		await this.outputWriteQueue;
		if (!this.activeSubmissionId || !this.outputChannel || !this.responseMessageId) return;
		const submissionId = this.activeSubmissionId;
		const declarations = this.outputChannel.responseFinishes;
		if (declarations.length === 0) return;
		const durableMetadata = { ...(await this.conversationWriter.loadReducedState()).conversations.get(this.conversationId)?.responseMetadata.get(submissionId) };
		const response = {
			usage: this.responseUsage ?? emptyUsage(),
			toolCalls: await this.collectResponseToolCalls(submissionId)
		};
		const metadata = runResponseMetadataHooks("useResponseFinish", declarations, (current, index) => ({
			metadata: current,
			response,
			log: this.createHookLogger("useResponseFinish", index)
		}), durableMetadata);
		const records = [...this.drainHookStateRecords(), ...metadata ? [{
			...this.canonicalEnvelope("message_metadata"),
			type: "message_metadata",
			metadata
		}] : []];
		if (records.length > 0) await this.appendCanonical(records);
	}
	/** Turn buffered `usePersistentState` writes into canonical records, in write order. */
	drainHookStateRecords() {
		if (!this.hookState) return [];
		return this.hookState.drain().map((write) => ({
			...this.canonicalEnvelope("state_write"),
			type: "state_write",
			name: write.name,
			value: write.value
		}));
	}
	modelRequestInfo(model, options) {
		if (!model) throw new Error("[flue] Missing configured model for turn telemetry.");
		const parsedEndpoint = parseProviderEndpoint(model.baseUrl);
		return {
			providerId: model.provider,
			providerName: providerTelemetryName(model.provider),
			requestedModel: model.id,
			api: model.api,
			serverAddress: parsedEndpoint?.address,
			serverPort: parsedEndpoint?.port,
			reasoningLevel: options?.reasoning,
			maxTokens: options?.maxTokens,
			temperature: options?.temperature
		};
	}
	emitTurnRequest(turnId, purpose, model, context, options) {
		const tools = context.tools?.map((tool) => ({
			name: tool.name,
			description: tool.description,
			parameters: tool.parameters
		}));
		const request = this.modelRequestInfo(model, options);
		this.modelRequests.set(turnId, {
			info: request,
			startedAt: Date.now()
		});
		this.emit({
			type: "turn_request",
			turnId,
			purpose,
			request: {
				...request,
				input: {
					systemPrompt: context.systemPrompt,
					messages: context.messages.map(toTurnMessage),
					tools
				}
			}
		});
	}
	emitTurn(turnId, purpose, response, request, error) {
		const output = response ? toTurnMessage(response) : void 0;
		const providerDiagnostics = response ? readProviderResponseDiagnostics(response) : void 0;
		this.emit({
			type: "turn",
			turnId,
			purpose,
			durationMs: durationSince(this.modelRequests.get(turnId)?.startedAt),
			request,
			response: {
				responseId: response?.responseId,
				responseModel: response?.responseModel,
				output,
				usage: fromProviderUsage(response?.usage),
				finishReason: response?.stopReason,
				...providerDiagnostics,
				...error !== void 0 || response?.errorMessage ? { error: classifyError(error ?? response?.errorMessage) } : {}
			},
			isError: error !== void 0 || response?.stopReason === "error" || response?.stopReason === "aborted"
		});
	}
	constructor(options) {
		this.name = options.name;
		this.conversationId = options.conversation.conversationId;
		this.affinityKey = options.conversation.affinityKey;
		this.config = options.config;
		this.envSlot = options.envSlot;
		this.envRuntime = options.envRuntime;
		this.fs = {
			readFile: (path) => this.env.readFile(path),
			readFileBuffer: (path) => this.env.readFileBuffer(path),
			writeFile: (path, content) => this.env.writeFile(path, content),
			stat: (path) => this.env.stat(path),
			readdir: (path) => this.env.readdir(path),
			exists: (path) => this.env.exists(path),
			mkdir: (path, mkdirOptions) => this.env.mkdir(path, mkdirOptions),
			rm: (path, rmOptions) => this.env.rm(path, rmOptions)
		};
		this.agentTools = options.agentTools ?? [];
		this.mcpUnavailable = options.mcpUnavailable ?? [];
		this.delegationDepth = options.delegationDepth ?? 0;
		this.createTaskSession = options.createTaskSession;
		this.createActionHarness = options.createActionHarness;
		this.scopeSignal = options.scopeSignal;
		this.onClose = options.onClose;
		this.conversationWriter = options.conversationWriter;
		this.attachmentStore = options.attachmentStore;
		this.executionIdentity = options.executionContext ?? {};
		this.hookState = options.hookState;
		this.rerender = options.rerender;
		this.outputChannel = options.output;
		this.advanceDelivery = options.advanceDelivery;
		this.outputChannel?.connect((name, data) => this.enqueueMessageDataWrite(name, data));
		this.resourceRuntime = options.resources;
		this.liveSkills = options.resources?.initial.skills ?? this.config.skills;
		this.liveSubagents = options.resources?.initial.subagents ?? this.config.subagents ?? {};
		this.lastNarratedResources = options.resources?.narrated;
		this.lastRenderedResources = options.resources?.initial;
		const systemPrompt = this.config.systemPrompt;
		const tools = this.assembleModelTools(this.createBuiltinToolGroups(this.attachedEnv), this.agentTools, []);
		const previousMessages = [];
		this.agentLoop = new Agent({
			initialState: {
				systemPrompt,
				model: this.config.model,
				tools,
				messages: previousMessages,
				thinkingLevel: this.config.thinkingLevel ?? "medium"
			},
			streamFn: this.emitTurnRequestAndStream,
			toolExecution: "parallel",
			steeringMode: "all",
			followUpMode: "all",
			sessionId: this.affinityKey,
			...options.rerender ? { prepareNextTurnWithContext: (turn) => this.prepareRerenderTurn(turn) } : {}
		});
		this.eventCallback = options.onAgentEvent;
		this.agentLoop.subscribe(async (event) => {
			switch (event.type) {
				case "agent_start":
					this.emit({ type: "agent_start" });
					break;
				case "turn_start":
					this.activeTurnId ??= generateTurnId();
					this.emit({
						type: "turn_start",
						turnId: this.activeTurnId,
						purpose: "agent"
					});
					break;
				case "message_start": {
					const turnId = this.activeTurnId ?? generateTurnId();
					this.activeTurnId = turnId;
					if (event.message.role === "assistant") {
						const messageId = generateConversationEntryId();
						const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId) ?? null;
						this.canonicalAssistant = {
							messageId,
							blocks: /* @__PURE__ */ new Map()
						};
						this.canonicalToolRequestMessageId = void 0;
						const { role: _role, content: _content, stopReason: _stopReason, errorMessage: _errorMessage, timestamp: _timestamp, usage: _usage, ...modelInfo } = event.message;
						const isResponseFirstMessage = this.activeSubmissionId !== void 0 && this.responseMessageId === void 0;
						if (isResponseFirstMessage) this.responseMessageId = messageId;
						await this.appendCanonical([{
							...this.canonicalEnvelope("assistant_message_started"),
							type: "assistant_message_started",
							messageId,
							parentId,
							modelInfo,
							...isResponseFirstMessage && this.responseStartMetadata ? { responseMetadata: this.responseStartMetadata } : {}
						}]);
					}
					this.emit({
						type: "message_start",
						message: event.message,
						turnId
					});
					break;
				}
				case "message_update": {
					const aEvent = event.assistantMessageEvent;
					const assistant = this.canonicalAssistant;
					if (assistant && aEvent.type === "text_start") {
						const blockId = generateBlockId();
						assistant.blocks.set(aEvent.contentIndex, {
							id: blockId,
							type: "text",
							deltaCount: 0,
							completed: false
						});
						await this.appendCanonical([{
							...this.canonicalEnvelope("assistant_text_started"),
							type: "assistant_text_started",
							messageId: assistant.messageId,
							blockId,
							blockIndex: aEvent.contentIndex
						}]);
					} else if (assistant && aEvent.type === "text_delta") {
						const block = assistant.blocks.get(aEvent.contentIndex);
						if (!block || block.type !== "text") throw new Error("[flue] Canonical text delta has no started block.");
						this.enqueueCanonical([{
							...this.canonicalEnvelope("assistant_text_delta"),
							type: "assistant_text_delta",
							messageId: assistant.messageId,
							blockId: block.id,
							sequence: block.deltaCount++,
							delta: aEvent.delta
						}], () => this.emit({
							type: "text_delta",
							text: aEvent.delta
						}));
					} else if (assistant && aEvent.type === "text_end") {
						const block = assistant.blocks.get(aEvent.contentIndex);
						if (!block || block.type !== "text") throw new Error("[flue] Canonical text completion has no started block.");
						const content = aEvent.partial.content[aEvent.contentIndex];
						await this.flushCanonical();
						await this.appendCanonical([{
							...this.canonicalEnvelope("assistant_text_completed"),
							type: "assistant_text_completed",
							messageId: assistant.messageId,
							blockId: block.id,
							deltaCount: block.deltaCount,
							...content?.type === "text" && content.textSignature ? { textSignature: content.textSignature } : {}
						}]);
						block.completed = true;
					} else if (assistant && aEvent.type === "thinking_start") {
						const blockId = generateBlockId();
						assistant.blocks.set(aEvent.contentIndex, {
							id: blockId,
							type: "reasoning",
							deltaCount: 0,
							completed: false
						});
						await this.appendCanonical([{
							...this.canonicalEnvelope("assistant_reasoning_started"),
							type: "assistant_reasoning_started",
							messageId: assistant.messageId,
							blockId,
							blockIndex: aEvent.contentIndex
						}]);
						this.emit({
							type: "thinking_start",
							contentIndex: aEvent.contentIndex
						});
					} else if (assistant && aEvent.type === "thinking_delta") {
						const block = assistant.blocks.get(aEvent.contentIndex);
						if (!block || block.type !== "reasoning") throw new Error("[flue] Canonical reasoning delta has no started block.");
						this.enqueueCanonical([{
							...this.canonicalEnvelope("assistant_reasoning_delta"),
							type: "assistant_reasoning_delta",
							messageId: assistant.messageId,
							blockId: block.id,
							sequence: block.deltaCount++,
							delta: aEvent.delta
						}], () => this.emit({
							type: "thinking_delta",
							contentIndex: aEvent.contentIndex,
							delta: aEvent.delta
						}));
					} else if (assistant && aEvent.type === "thinking_end") {
						const block = assistant.blocks.get(aEvent.contentIndex);
						if (!block || block.type !== "reasoning") throw new Error("[flue] Canonical reasoning completion has no started block.");
						const content = aEvent.partial.content[aEvent.contentIndex];
						await this.flushCanonical();
						await this.appendCanonical([{
							...this.canonicalEnvelope("assistant_reasoning_completed"),
							type: "assistant_reasoning_completed",
							messageId: assistant.messageId,
							blockId: block.id,
							deltaCount: block.deltaCount,
							...content?.type === "thinking" && content.thinkingSignature ? { encrypted: content.thinkingSignature } : {},
							...content?.type === "thinking" && content.redacted ? { redacted: true } : {}
						}]);
						block.completed = true;
						this.emit({
							type: "thinking_end",
							contentIndex: aEvent.contentIndex,
							content: aEvent.content
						});
					} else if (assistant && aEvent.type === "toolcall_end") await this.appendCanonical([{
						...this.canonicalEnvelope("assistant_tool_call"),
						type: "assistant_tool_call",
						messageId: assistant.messageId,
						blockId: generateBlockId(),
						blockIndex: aEvent.contentIndex,
						toolCallId: aEvent.toolCall.id,
						name: aEvent.toolCall.name,
						arguments: aEvent.toolCall.arguments,
						...aEvent.toolCall.thoughtSignature ? { thoughtSignature: aEvent.toolCall.thoughtSignature } : {}
					}]);
					else if (aEvent.type === "toolcall_delta") {
						const content = aEvent.partial.content[aEvent.contentIndex];
						if (content?.type === "toolCall" && content.id && content.name) this.emit({
							type: "toolcall_delta",
							toolCallId: content.id,
							toolName: content.name,
							argumentTextDelta: aEvent.delta
						});
					}
					break;
				}
				case "message_end": {
					const turnId = this.activeTurnId ?? generateTurnId();
					this.activeTurnId = turnId;
					if (event.message.role === "assistant") {
						const canonical = this.canonicalAssistant;
						if (canonical) {
							await this.flushCanonical();
							for (const block of canonical.blocks.values()) {
								if (block.completed) continue;
								await this.appendCanonical([block.type === "text" ? {
									...this.canonicalEnvelope("assistant_text_completed"),
									type: "assistant_text_completed",
									messageId: canonical.messageId,
									blockId: block.id,
									deltaCount: block.deltaCount
								} : {
									...this.canonicalEnvelope("assistant_reasoning_completed"),
									type: "assistant_reasoning_completed",
									messageId: canonical.messageId,
									blockId: block.id,
									deltaCount: block.deltaCount
								}]);
								block.completed = true;
							}
							await this.appendCanonical([{
								...this.canonicalEnvelope("assistant_message_completed"),
								type: "assistant_message_completed",
								messageId: canonical.messageId,
								stopReason: event.message.stopReason,
								usage: event.message.usage,
								...event.message.errorMessage ? { error: event.message.errorMessage } : {}
							}]);
							if (this.activeSubmissionId) {
								this.responseHasCompletedStep = true;
								const stepUsage = fromProviderUsage(event.message.usage);
								if (stepUsage) this.responseUsage = this.responseUsage ? addUsage(this.responseUsage, stepUsage) : stepUsage;
								this.flushPreAnchorDataWrites();
							}
							this.canonicalToolRequestMessageId = event.message.content.some((content) => content.type === "toolCall") ? canonical.messageId : void 0;
							this.canonicalAssistant = void 0;
						}
						const request = this.modelRequests.get(turnId)?.info ?? this.modelRequestInfo(this.agentLoop.state.model);
						this.emitTurn(turnId, "agent", event.message, request);
						this.modelRequests.delete(turnId);
					}
					this.emit({
						type: "message_end",
						message: event.message,
						turnId
					});
					break;
				}
				case "tool_execution_start": {
					const tool = this.agentLoop.state.tools.find((candidate) => candidate.name === event.toolName);
					this.activeToolCalls.set(event.toolCallId, {
						startedAt: Date.now(),
						toolName: event.toolName,
						telemetry: tool ? this.modelToolTelemetry.get(tool) ?? { origin: "model" } : { origin: "model" },
						startEmitted: false
					});
					break;
				}
				case "tool_execution_update": break;
				case "tool_execution_end": {
					const call = this.activeToolCalls.get(event.toolCallId) ?? {
						startedAt: Date.now(),
						toolName: event.toolName,
						telemetry: { origin: "model" },
						startEmitted: false
					};
					const assistantMessageId = this.canonicalToolRequestMessageId;
					if (!assistantMessageId) throw new Error("[flue] Canonical tool outcome has no assistant request.");
					const outcomeKey = `${encodeCanonicalId(assistantMessageId)}_${encodeCanonicalId(event.toolCallId)}`;
					const messageId = `entry_tool_outcome_${outcomeKey}`;
					const result = event.result;
					const outcomeContent = await this.persistToolResultContent(result, messageId);
					const details = result.details;
					const hasStructuredOutput = !event.isError && typeof details === "object" && details !== null && "output" in details;
					const toolDurationMs = durationSince(call.startedAt);
					await this.appendCanonical([{
						...this.canonicalEnvelope("tool_outcome", `record_tool_outcome_${outcomeKey}`),
						type: "tool_outcome",
						assistantMessageId,
						toolCallId: event.toolCallId,
						toolName: event.toolName,
						isError: event.isError,
						content: outcomeContent,
						...hasStructuredOutput ? { output: details?.output } : {},
						...result.terminate === true ? { terminate: true } : {},
						durationMs: toolDurationMs
					}]);
					globalThis[Symbol.for("a4.runtime.diagnostic")].directOutcome();
					if (!call.startEmitted) this.emit({
						type: "tool_start",
						toolName: call.toolName,
						toolCallId: event.toolCallId
					}, call.telemetry);
					const publishTool = () => this.emit({
						type: "tool",
						toolName: event.toolName,
						toolCallId: event.toolCallId,
						isError: event.isError,
						result: event.result,
						durationMs: toolDurationMs
					}, {
						...call.telemetry,
						...call.effectiveResultCaptured ? { effectiveResult: call.effectiveResult } : {},
						...event.isError ? { errorInfo: classifyError(call.error ?? event.result) } : {}
					});
					this.pendingToolPublications.set(event.toolCallId, publishTool);
					this.activeToolCalls.delete(event.toolCallId);
					break;
				}
				case "turn_end": {
					const turnId = this.activeTurnId ?? generateTurnId();
					if (event.toolResults.length > 0) {
						const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
						if (!parentId) throw new Error("[flue] Canonical tool results have no assistant parent.");
						const assistantMessageId = this.canonicalToolRequestMessageId;
						if (!assistantMessageId) throw new Error("[flue] Canonical tool results have no assistant request.");
						const conversation = await this.requireConversation();
						const outcomeIds = event.toolResults.map((toolResult) => {
							const outcome = conversation.toolOutcomes.get(toolOutcomeKey(assistantMessageId, toolResult.toolCallId));
							if (!outcome) throw new Error("[flue] Canonical tool result has no durable outcome.");
							return outcome;
						});
						const finalToolResult = event.toolResults.at(-1);
						if (!finalToolResult) throw new ConversationRecordInvariantError({
							recordId: `record_tool_results_committed_${encodeCanonicalId(assistantMessageId)}`,
							recordType: "tool_results_committed",
							reason: "A committed canonical tool-result batch must contain at least one result."
						});
						await this.appendCanonical([...this.drainHookStateRecords(), {
							...this.canonicalEnvelope("tool_results_committed", `record_tool_results_committed_${encodeCanonicalId(assistantMessageId)}`),
							type: "tool_results_committed",
							assistantMessageId,
							parentId,
							outcomeIds
						}]);
						for (const toolResult of event.toolResults) {
							this.pendingToolPublications.get(toolResult.toolCallId)?.();
							this.pendingToolPublications.delete(toolResult.toolCallId);
						}
						this.lastCommittedToolBatch = {
							assistantMessageId,
							toolCallId: finalToolResult.toolCallId
						};
						this.canonicalToolRequestMessageId = void 0;
					} else {
						const stateWrites = this.drainHookStateRecords();
						if (stateWrites.length > 0) await this.appendCanonical(stateWrites);
						this.lastCommittedToolBatch = void 0;
					}
					await this.applyQueuedJoins();
					this.emit({
						type: "turn_messages",
						turnId,
						purpose: "agent",
						message: event.message,
						toolResults: event.toolResults
					});
					this.activeTurnId = void 0;
					break;
				}
				case "agent_end":
					this.emit({
						type: "agent_end",
						messages: event.messages
					});
					this.activeTurnId = void 0;
			}
		});
	}
	resolveCompactionSettings(model) {
		const cc = this.config.compaction;
		const defaults = model ? deriveCompactionDefaults({
			contextWindow: model.contextWindow ?? 0,
			maxTokens: model.maxTokens ?? 0
		}) : DEFAULT_COMPACTION_SETTINGS;
		if (cc === false) return {
			...defaults,
			enabled: false
		};
		if (!cc) return defaults;
		return {
			enabled: true,
			reserveTokens: cc.reserveTokens ?? defaults.reserveTokens,
			keepRecentTokens: cc.keepRecentTokens ?? defaults.keepRecentTokens
		};
	}
	async initializeCanonicalContext() {
		await this.rebuildCanonicalContext();
	}
	prompt(text, options) {
		return createCallHandle(options?.signal, (signal) => this.runOperation("prompt", signal, async () => {
			const schema = options?.result;
			return this.runPromptCall({
				promptText: buildPromptText(text, schema),
				schema,
				tools: options?.tools,
				model: options?.model,
				thinkingLevel: options?.thinkingLevel,
				images: options?.images,
				errorLabel: "prompt",
				signal
			});
		}));
	}
	async inspectSubmissionInput(input) {
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation?.entries.has(this.canonicalInputEntryId(input))) return "absent";
		return this.inspectCanonicalState(classifyConversationSubmission(conversation, this.canonicalInputEntryId(input), { contextWindow: this.agentLoop.state.model?.contextWindow ?? 0 }));
	}
	processSubmissionInput(input, options) {
		return createCallHandle(void 0, (signal) => this.runOperation("prompt", signal, () => this.runPersistedSubmissionInput(input, signal, options)));
	}
	/**
	* Complete the trailing partial tool-result batch left by a turn that was
	* interrupted mid-batch, so resumption continues from the repaired batch
	* instead of replaying — and re-executing — tool calls whose results were
	* already recorded. Conservative by construction: every recorded result is
	* preserved (first-write-wins) and unresolved calls get explicit
	* unknown-outcome error results — never a blind re-execution. Two scoped
	* exceptions resolve real outcomes pre-commit: in-flight `task` children
	* are resumed, and `durable: true` tool calls are re-executed with their
	* completed steps replaying from durable memos. The batch is derived from
	* persisted canonical history.
	*
	* `batchRequired` is the caller's assertion that classification proved a
	* repairable batch exists: a finder miss then means the classifier and the
	* finder disagree about the tail, and resuming anyway would replay the
	* turn and re-execute recorded tool calls — refuse loudly instead. Without
	* it, a missing batch is a legitimate no-op.
	*/
	async repairTrailingPartialToolBatch(inputEntryId, signal, options) {
		const conversation = await this.requireConversation();
		const following = getActiveConversationPathSince(conversation, inputEntryId);
		if (!following) {
			if (options.batchRequired) throw new Error("[flue] Classification found a trailing partial tool batch but repair cannot locate it — refusing to resume (a plain resume would re-execute recorded tool calls).");
			return;
		}
		const messages = following.flatMap((entry) => entry.type === "message" ? [entry] : []);
		const partial = findTrailingPartialToolBatch(messages);
		if (!partial) {
			if (options.batchRequired) throw new Error("[flue] Classification found a trailing partial tool batch but repair cannot locate it — refusing to resume (a plain resume would re-execute recorded tool calls).");
			return;
		}
		const resolvedOutcomes = await this.resumeUnresolvedTaskCalls(conversation, partial, signal);
		await this.resumeDurableToolCalls(conversation, partial, signal, resolvedOutcomes);
		await this.appendRepairedToolResultBatch(partial.entryId, partial.toolCalls, conversation, resolvedOutcomes);
	}
	/**
	* Resume each unresolved model-invoked `task` call in a trailing partial
	* batch from its durable child conversation, returning a real `tool_outcome`
	* record per resolved call (keyed by tool call id). Calls without a
	* `child_session_retained` link (e.g. programmatic `session.task()`) are left
	* for the interrupted-marker path. Failure policy (D-B): a provably-permanent
	* config failure (`SubagentNotDeclaredError`) yields an error outcome so the
	* parent continues degraded; every other failure propagates so the parent's
	* retry budget re-attempts (never silently abandon possibly-recoverable work).
	*/
	async resumeUnresolvedTaskCalls(conversation, partial, signal) {
		const resolved = /* @__PURE__ */ new Map();
		for (const toolCall of partial.toolCalls) {
			if (toolCall.name !== "task") continue;
			if (conversation.toolOutcomes.has(toolOutcomeKey(partial.entryId, toolCall.id))) continue;
			const ref = [...conversation.childConversations.values()].find((child) => child.type === "task" && child.parentToolCallId === toolCall.id);
			if (!ref) continue;
			resolved.set(toolCall.id, await this.resumeChildTaskCall(partial.entryId, partial.assistant, toolCall.id, ref, signal));
		}
		return resolved;
	}
	/**
	* Re-execute each unresolved `durable: true` tool call in a trailing
	* partial batch — the scoped exception to the never-re-execute doctrine.
	* The durable tool's contract is that every side effect goes through
	* `step.do`, so the re-run replays completed steps from their durable
	* memos (same toolCallId → same memo ids) and only executes what never
	* finished. Semantics mirror live execution: a throw becomes an isError
	* outcome the model sees (never a propagated failure burning the
	* submission's retry budget); only an abort propagates. A call whose
	* current render no longer declares the tool — or no longer marks it
	* durable — is left for the interrupted-marker path, so a redeploy
	* degrades to today's behavior instead of guessing.
	*/
	async resumeDurableToolCalls(conversation, partial, signal, resolved) {
		for (const toolCall of partial.toolCalls) {
			if (resolved.has(toolCall.id)) continue;
			if (conversation.toolOutcomes.has(toolOutcomeKey(partial.entryId, toolCall.id))) continue;
			const toolDef = this.agentTools.find((candidate) => candidate.name === toolCall.name);
			if (!toolDef?.durable) continue;
			if (signal.aborted) throw abortErrorFor(signal);
			resolved.set(toolCall.id, await this.reexecuteDurableToolCall(partial, toolCall.id, toolDef, signal));
		}
	}
	/** One durable re-execution, from the durable tool-call block to a real
	*  `tool_outcome` record in the live outcome format. */
	async reexecuteDurableToolCall(partial, toolCallId, toolDef, signal) {
		const params = partial.assistant.content.find((candidate) => candidate.type === "toolCall" && candidate.id === toolCallId)?.arguments ?? {};
		const startedAt = Date.now();
		const outcomeKey = `${encodeCanonicalId(partial.entryId)}_${encodeCanonicalId(toolCallId)}`;
		const buildOutcome = (isError, text, output, terminate) => ({
			...this.canonicalEnvelope("tool_outcome", `record_tool_outcome_${outcomeKey}`),
			type: "tool_outcome",
			assistantMessageId: partial.entryId,
			toolCallId,
			toolName: toolDef.name,
			isError,
			content: [{
				type: "text",
				text
			}],
			...output !== void 0 ? { output } : {},
			...terminate ? { terminate: true } : {},
			durationMs: durationSince(startedAt)
		});
		const log = this.createToolLogger(toolDef.name, toolCallId);
		let harness;
		try {
			const invocationId = toolDef.harness ? generateInvocationId() : void 0;
			harness = invocationId ? this.createInvocationHarness(invocationId, signal) : void 0;
			const preparedParams = toolDef.prepareArguments ? toolDef.prepareArguments(structuredClone(params)) : params;
			const parsed = await abandonToolOnAbort(() => parseToolInput(toolDef, preparedParams, signal, {
				log,
				toolCallId,
				step: this.createToolStep(toolDef.name, toolCallId, log),
				...harness ? { harness } : {}
			}), signal);
			if (signal.aborted) throw abortErrorFor(signal);
			const resolved = resolveToolRun(toolDef, await toolDef.run(parsed.context));
			return buildOutcome(false, resolved.output === void 0 ? "null" : JSON.stringify(resolved.output), resolved.output, resolved.terminate);
		} catch (error) {
			if (signal.aborted) throw error;
			return buildOutcome(true, error instanceof Error ? error.message : String(error));
		} finally {
			if (harness) {
				this.activeActionHarnesses.delete(harness);
				await harness.close();
			}
		}
	}
	/** Reattach to one in-flight child, resume it to completion, and build the
	*  parent's real `tool_outcome` for the originating `task` call. */
	async resumeChildTaskCall(assistantEntryId, assistant, toolCallId, ref, signal) {
		if (!this.createTaskSession) throw new Error("[flue] This session cannot resume task sessions.");
		const args = assistant.content.find((block) => block.type === "toolCall" && block.id === toolCallId)?.arguments ?? {};
		let taskAgent;
		try {
			const delivery = args.agent && typeof args.prompt === "string" ? taskDeliveryMessage(args.prompt, await this.resolveCanonicalImages([...new Set((args.attachments ?? []).map((attachment) => attachment.id))])) : void 0;
			taskAgent = args.agent ? this.resolveSubagent(args.agent, delivery) : void 0;
		} catch (error) {
			if (error instanceof SubagentNotDeclaredError) return this.taskResumeFailureOutcomeRecord(assistantEntryId, toolCallId, error);
			throw error;
		}
		const taskStartMs = Date.now();
		let child;
		try {
			child = await this.createTaskSession({
				parentSession: this.name,
				parentConversationId: this.conversationId,
				taskId: ref.taskId,
				parentEnv: this.attachedEnv,
				cwd: args.cwd,
				agent: taskAgent,
				depth: this.delegationDepth + 1,
				existing: { conversationId: ref.conversationId },
				...ref.parentToolCallId ? { parentToolCallId: ref.parentToolCallId } : {},
				...ref.parentAssistantEntryId ? { parentAssistantEntryId: ref.parentAssistantEntryId } : {}
			});
			this.activeTasks.add(child);
			const text = await child.resumeReattachedChild({
				timeoutAt: this.activeTimeoutAt,
				signal
			});
			this.emit({
				type: "task",
				taskId: ref.taskId,
				agent: taskAgent?.name,
				isError: false,
				result: text,
				durationMs: durationSince(taskStartMs),
				parentSession: this.name,
				session: child.name,
				conversationId: child.conversationId
			});
			return this.taskResumeOutcomeRecord(assistantEntryId, toolCallId, text);
		} finally {
			if (child) {
				await child.close();
				this.activeTasks.delete(child);
			}
		}
	}
	taskResumeOutcomeRecord(assistantEntryId, toolCallId, text) {
		const key = `${encodeCanonicalId(assistantEntryId)}_${encodeCanonicalId(toolCallId)}`;
		return {
			...this.canonicalEnvelope("tool_outcome", `record_tool_outcome_${key}`),
			type: "tool_outcome",
			assistantMessageId: assistantEntryId,
			toolCallId,
			toolName: "task",
			isError: false,
			content: [{
				type: "text",
				text: text || "(task completed with no text)"
			}]
		};
	}
	taskResumeFailureOutcomeRecord(assistantEntryId, toolCallId, error) {
		const key = `${encodeCanonicalId(assistantEntryId)}_${encodeCanonicalId(toolCallId)}`;
		return {
			...this.canonicalEnvelope("tool_outcome", `record_tool_resume_failed_${key}`),
			type: "tool_outcome",
			assistantMessageId: assistantEntryId,
			toolCallId,
			toolName: "task",
			isError: true,
			content: [{
				type: "text",
				text: JSON.stringify({
					type: "subagent_unavailable",
					message: error.message
				})
			}]
		};
	}
	/**
	* Shared repair core: build a complete ordered result batch for
	* `toolCalls`, preserving already-settled results (first-write-wins), using a
	* pre-resolved outcome where one was produced (resumed subagent task), and
	* synthesizing interrupted-marker error results for the remaining unresolved
	* calls — never a fabricated or assumed outcome.
	*/
	async appendRepairedToolResultBatch(assistantEntryId, toolCalls, conversation, resolved) {
		if (conversation.activeLeafId !== assistantEntryId) throw new Error("[flue] Cannot repair the trailing tool batch: its toolUse assistant is no longer the conversation leaf — an entry was appended before repair.");
		if (!toolCalls.at(-1)) throw new ConversationRecordInvariantError({
			recordId: `record_tool_repair_commit_${encodeCanonicalId(assistantEntryId)}`,
			recordType: "tool_results_committed",
			reason: "A repaired canonical tool-result batch must contain at least one tool call."
		});
		const outcomeRecords = [];
		const outcomeIds = [];
		for (const toolCall of toolCalls) {
			const outcome = conversation.toolOutcomes.get(toolOutcomeKey(assistantEntryId, toolCall.id));
			if (outcome) {
				outcomeIds.push(outcome);
				continue;
			}
			const resolvedRecord = resolved.get(toolCall.id);
			if (resolvedRecord) {
				outcomeRecords.push(resolvedRecord);
				outcomeIds.push(resolvedRecord.id);
				continue;
			}
			const recordId = `record_tool_repair_outcome_${`${encodeCanonicalId(assistantEntryId)}_${encodeCanonicalId(toolCall.id)}`}`;
			outcomeRecords.push({
				...this.canonicalEnvelope("tool_outcome", recordId),
				type: "tool_outcome",
				assistantMessageId: assistantEntryId,
				toolCallId: toolCall.id,
				toolName: toolCall.name,
				isError: true,
				content: [{
					type: "text",
					text: JSON.stringify({
						type: "interrupted",
						message: "Tool execution was interrupted before completion. The outcome is unknown."
					})
				}]
			});
			outcomeIds.push(recordId);
		}
		if (outcomeRecords.length > 0) await this.appendCanonical(outcomeRecords);
		await this.appendCanonical([{
			...this.canonicalEnvelope("tool_results_committed", `record_tool_repair_commit_${encodeCanonicalId(assistantEntryId)}`),
			type: "tool_results_committed",
			assistantMessageId: assistantEntryId,
			parentId: assistantEntryId,
			outcomeIds
		}]);
		await this.rebuildCanonicalContext();
	}
	/**
	* Upgrade the trailing aborted partial to a stream continuation: when the
	* committed partial has content worth continuing from (non-empty text or
	* reasoning, no tool calls), append the deterministic
	* `stream_interrupted`/`stream_continued` signal pair so the partial enters
	* model context with the instruction to continue rather than being replayed
	* from scratch. Semantic recovery, classification-driven — the structural
	* half (materializing the in-progress stream as a committed aborted entry)
	* already happened unconditionally at the ownership seam
	* (`materializeGhostStream`).
	*
	* Idempotent: an already-upgraded partial (both signal entries present at
	* the tail) reports success without appending. A partial that is no longer
	* the active leaf is left alone — the signals must chain off the partial,
	* and a moved-on conversation resumes by plain replay instead.
	*/
	async upgradeAbortedPartialToContinuation() {
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation) return false;
		const partial = getActiveConversationPath(conversation).findLast((entry) => entry.type === "message" && entry.submissionId === this.activeSubmissionId && entry.message.role === "assistant" && entry.message.stopReason === "aborted" && !entry.message.content.some((block) => block.type === "toolCall") && entry.message.content.some((block) => block.type === "text" && block.text.length > 0 || block.type === "thinking" && block.thinking.length > 0));
		if (!partial) return false;
		const continuedEntryId = `entry_recovery_${partial.id}_stream_continued`;
		if (conversation.entries.has(`entry_recovery_${partial.id}_stream_interrupted`) && conversation.entries.has(continuedEntryId)) return true;
		if (conversation.activeLeafId !== partial.id) return false;
		let parentId = partial.id;
		const records = [];
		for (const signalType of ["stream_interrupted", "stream_continued"]) {
			const messageId = `entry_recovery_${partial.id}_${signalType}`;
			records.push({
				...this.canonicalEnvelope("signal", `record_recovery_${partial.id}_${signalType}`),
				type: "signal",
				messageId,
				parentId,
				signalType,
				content: signalType === "stream_interrupted" ? "The previous assistant stream was interrupted." : "Continue from the durable partial assistant response."
			});
			parentId = messageId;
		}
		await this.appendCanonical(records);
		await this.rebuildCanonicalContext();
		return true;
	}
	/**
	* Build the canonical records that materialize an interrupted in-progress
	* assistant stream as a completed aborted entry: completion markers for the
	* unfinished text/reasoning blocks plus the aborted
	* `assistant_message_completed`. Record ids are deterministic, so streams
	* converged by earlier runtime versions (which had a second materialization
	* path) reduce identically and a re-converge is a structural no-op.
	*/
	materializeInProgressStreamRecords(inProgress) {
		const records = [];
		for (const block of inProgress.blocks.values()) if ((block.type === "text" || block.type === "reasoning") && !block.completed) records.push(block.type === "text" ? {
			...this.canonicalEnvelope("assistant_text_completed", `record_recovery_${inProgress.messageId}_${block.blockId}_completed`),
			type: "assistant_text_completed",
			messageId: inProgress.messageId,
			blockId: block.blockId,
			deltaCount: block.deltas.length
		} : {
			...this.canonicalEnvelope("assistant_reasoning_completed", `record_recovery_${inProgress.messageId}_${block.blockId}_completed`),
			type: "assistant_reasoning_completed",
			messageId: inProgress.messageId,
			blockId: block.blockId,
			deltaCount: block.deltas.length
		});
		records.push({
			...this.canonicalEnvelope("assistant_message_completed", `record_recovery_${inProgress.messageId}_aborted`),
			type: "assistant_message_completed",
			messageId: inProgress.messageId,
			stopReason: "aborted",
			usage: zeroProviderUsage(),
			error: "Stream interrupted before completion."
		});
		return records;
	}
	/**
	* A convergence scope names whose dangling state a repair may touch.
	* `{ submissionId }` restricts to state stamped with that submission
	* (`undefined` matches unowned state — programmatic prompts, subagent
	* children); `'any'` matches regardless of owner — used at ownership seams,
	* where per-session submission serialization guarantees any dangling state
	* was abandoned by a previous driver.
	*/
	ownsDanglingState(scope) {
		return (submissionId) => scope === "any" || submissionId === scope.submissionId;
	}
	/**
	* Structural convergence: materialize the in-progress assistant stream at
	* the active leaf as a completed aborted entry, so no crash shape can leave
	* the conversation with in-progress bookkeeping that blocks appends or
	* projects as still-streaming. Runs unconditionally at every ownership seam
	* — resume entry, new input, terminalization — and is idempotent: a clean
	* stream is a no-op, and record ids are deterministic. Never wrong by
	* construction: an in-progress message under a scope the caller owns is
	* necessarily dead (its writer is fenced out or was never durable).
	*
	* Single-shot on purpose: materializing the leaf ghost advances the leaf,
	* which strands any sibling ghost off-tail — and off-tail bookkeeping is the
	* reducer's settle barrier's job (dropped at `submission_settled`), not an
	* append-based repair's. No resumption signals are appended here; whether
	* the materialized partial is worth continuing from is semantic recovery
	* (`upgradeAbortedPartialToContinuation`), decided by classification.
	*
	* Returns true when a ghost was materialized.
	*/
	async materializeGhostStream(scope) {
		const owns = this.ownsDanglingState(scope);
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation) return false;
		const inProgress = [...conversation.inProgressMessages.values()].find((message) => message.parentId === conversation.activeLeafId);
		if (!inProgress || !owns(inProgress.submissionId)) return false;
		await this.appendCanonical(this.materializeInProgressStreamRecords(inProgress));
		await this.rebuildCanonicalContext();
		return true;
	}
	/**
	* Marker-settle the trailing uncommitted tool batch so the conversation can
	* come to rest. Recorded outcomes are preserved first-write-wins; every
	* unresolved call gets an explicit unknown-outcome error — never a
	* re-execution, and never a child resume (that is budgeted attempt-path
	* work; see `resumeUnresolvedTaskCalls`). Returns the calls that were
	* settled with interrupted markers.
	*
	* Settleable by construction: `tool_results_committed` is all-or-nothing,
	* so a partial batch is always uncommitted and its toolUse assistant is
	* still the active leaf (nothing can follow it until commit), which
	* satisfies the commit-parent invariant. Deliberately NOT run at resume
	* entry — a resumed attempt's trailing batch is live work that
	* `repairTrailingPartialToolBatch` recovers precisely (task children
	* resumed, durable tools replayed); a marker-settle would pre-empt it.
	*/
	async settleTrailingToolBatch(scope) {
		const owns = this.ownsDanglingState(scope);
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation) return [];
		const messages = getActiveConversationPath(conversation).flatMap((entry) => entry.type === "message" ? [entry] : []);
		const partial = findTrailingPartialToolBatch(messages);
		if (!partial || conversation.activeLeafId !== partial.entryId) return [];
		const batchEntry = conversation.entries.get(partial.entryId);
		if (!owns(batchEntry?.type === "message" ? batchEntry.submissionId : void 0)) return [];
		const settled = [];
		const resolved = /* @__PURE__ */ new Map();
		for (const toolCall of partial.toolCalls) {
			if (conversation.toolOutcomes.has(toolOutcomeKey(partial.entryId, toolCall.id))) continue;
			settled.push({
				name: toolCall.name,
				id: toolCall.id
			});
			if (toolCall.name !== "task") continue;
			const ref = [...conversation.childConversations.values()].find((child) => child.type === "task" && child.parentToolCallId === toolCall.id);
			if (!ref) continue;
			resolved.set(toolCall.id, this.taskInterruptedOutcomeRecord(partial.entryId, toolCall.id, ref.conversationId));
		}
		await this.appendRepairedToolResultBatch(partial.entryId, partial.toolCalls, conversation, resolved);
		return settled;
	}
	/**
	* Settle all dangling conversation state so the conversation comes to rest:
	* the ghost stream materialized as an aborted entry (without resumption
	* signals — the conversation is settling, not resuming), then the trailing
	* uncommitted tool batch marker-settled. The two shapes are mutually
	* exclusive per turn (a next-turn stream can only start after the batch
	* commits), so ordering is a formality. Used by paths that terminate work;
	* resume entry converges only the ghost half (its batch is live work).
	*/
	async settleDanglingConversationState(scope) {
		await this.materializeGhostStream(scope);
		return await this.settleTrailingToolBatch(scope);
	}
	/**
	* Interrupted-marker outcome for a `task` call settled at terminalization:
	* identical semantics (and record id) to the generic interrupted marker,
	* plus the retained child conversation id so apps and future turns can
	* locate the child's durable transcript. The child reference itself
	* (`child_session_retained`) is untouched.
	*/
	taskInterruptedOutcomeRecord(assistantEntryId, toolCallId, childConversationId) {
		const key = `${encodeCanonicalId(assistantEntryId)}_${encodeCanonicalId(toolCallId)}`;
		return {
			...this.canonicalEnvelope("tool_outcome", `record_tool_repair_outcome_${key}`),
			type: "tool_outcome",
			assistantMessageId: assistantEntryId,
			toolCallId,
			toolName: "task",
			isError: true,
			content: [{
				type: "text",
				text: JSON.stringify({
					type: "interrupted",
					message: "Tool execution was interrupted before completion. The outcome is unknown.",
					childConversationId
				})
			}]
		};
	}
	async recordSubmissionTerminal(input) {
		const interruptedTools = await this.settleDanglingConversationState({ submissionId: input.submissionId });
		let body = input.message;
		if (interruptedTools.length > 0) {
			const toolList = interruptedTools.map((t) => `  - ${t.name} (${t.id})`).join("\n");
			body += `\n\nInterrupted tool call(s):\n${toolList}`;
		}
		const aborted = input.reason === "aborted";
		const signalType = aborted ? "submission_aborted" : "submission_interrupted";
		const slug = aborted ? "submission_aborted" : "submission_interrupted";
		const recordId = `record_${slug}_${input.submissionId}`;
		if (await this.conversationWriter.hasRecord(recordId)) return interruptedTools;
		const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
		await this.appendCanonical([{
			...this.canonicalEnvelope("signal", recordId),
			type: "signal",
			messageId: `entry_${slug}_${input.submissionId}`,
			parentId,
			signalType,
			content: body,
			attributes: {
				submissionId: input.submissionId,
				kind: input.kind,
				reason: input.reason,
				...interruptedTools.length > 0 ? { interruptedTools: JSON.stringify(interruptedTools) } : {}
			}
		}]);
		await this.rebuildCanonicalContext();
		return interruptedTools;
	}
	skill(skill, options) {
		return createCallHandle(options?.signal, (signal) => this.runOperation("skill", signal, async () => {
			const schema = options?.result;
			let promptText;
			let skillName;
			let activePackagedSkills;
			if (typeof skill === "string") {
				const registered = this.liveSkills[skill];
				if (!registered) this.throwMissingSkill(skill);
				else if (isWorkspaceSkill(registered)) promptText = buildSkillByPathlessNamePrompt(skill, options?.args, schema);
				else {
					const packaged = this.resolveRegisteredPackage(registered);
					promptText = buildPackagedSkillPrompt(packaged, options?.args, schema);
					activePackagedSkills = { [packaged.id]: packaged };
				}
				skillName = skill;
			} else {
				const packaged = this.resolveRegisteredPackage(skill);
				promptText = buildPackagedSkillPrompt(packaged, options?.args, schema);
				activePackagedSkills = { [packaged.id]: packaged };
				skillName = skill.name;
			}
			return this.runPromptCall({
				promptText,
				schema,
				tools: options?.tools,
				model: options?.model,
				thinkingLevel: options?.thinkingLevel,
				images: options?.images,
				errorLabel: `skill("${skillName}")`,
				activePackagedSkills,
				signal
			});
		}));
	}
	task(text, options) {
		return createCallHandle(options?.signal, (signal) => this.runOperation("task", signal, async () => (await this.executeTask(text, options, signal)).output));
	}
	shell(command, options) {
		return createCallHandle(options?.signal, (signal) => this.runOperation("shell", signal, () => execShellWithEvents(this.env, (event, detail) => this.emit(event, detail), command, options, this.scopeSignal ? AbortSignal.any([signal, this.scopeSignal]) : signal, this.executionContext({ operationId: this.activeOperationId }), (toolCallId, args, result, isError) => this.appendShellTriple(toolCallId, args, result, isError))));
	}
	async compact() {
		await this.runOperation("compact", void 0, async () => {
			await this.runCompaction("manual");
		});
	}
	abort(reason) {
		this.agentLoop.abort();
		this.compactionAbortController?.abort(reason);
		this.modelRetryAbortController?.abort(reason);
		for (const task of this.activeTasks) task.abort();
		for (const harness of this.activeActionHarnesses) harness.close();
	}
	async settle() {
		this.abort();
		await this.activeOperationSettlement;
		await Promise.allSettled([
			this.flushCanonical(),
			...[...this.activeTasks].map((task) => task.settle()),
			...[...this.activeActionHarnesses].map((harness) => harness.close())
		]);
	}
	close() {
		if (this.closePromise) return this.closePromise;
		this.closed = true;
		this.abort();
		this.closePromise = this.settle().finally(() => {
			this.onClose?.();
		});
		return this.closePromise;
	}
	/**
	* Precedence: call-level > agent-level default. A call-level specifier
	* resolves via `resolveModel` (which throws on an invalid specifier and never
	* returns undefined for a defined one); the agent default is always present.
	*/
	resolveModelForCall(modelSpecifier) {
		if (!modelSpecifier) return this.config.model;
		const model = this.config.resolveModel(modelSpecifier);
		if (!model) throw new Error(`[flue] Model "${modelSpecifier}" could not be resolved.`);
		return model;
	}
	/** Precedence: call-level > agent-level default > 'medium'. */
	resolveThinkingLevelForCall(callValue) {
		return callValue ?? this.config.thinkingLevel ?? "medium";
	}
	/** The packaged directory behind a registered skill: import-attached or lazily built from an inline definition. */
	resolveRegisteredPackage(skill) {
		if ("__flueSkillReference" in skill) {
			const packaged = getSkillReferenceDirectory(skill);
			if (!packaged) throw new Error(`[flue] Packaged skill "${skill.name}" is unavailable for this application build.`);
			return packaged;
		}
		return packageSkillDefinition(skill);
	}
	async activateSkillForTool(name) {
		const registered = this.liveSkills[name];
		if (!registered) return `Skill "${name}" is not available. Available skills: ${Object.keys(this.liveSkills).join(", ")}.`;
		if (isWorkspaceSkill(registered)) return buildWorkspaceSkillPrompt(registered.name, registered.directory, registered.skillMdPath, await this.env.readFile(registered.skillMdPath));
		return buildPackagedSkillPrompt(this.resolveRegisteredPackage(registered));
	}
	throwMissingSkill(skill) {
		throw new SkillNotRegisteredError({
			skill,
			available: Object.keys(this.liveSkills),
			...this.attachedEnv ? { skillsDir: skillsDirIn(this.attachedEnv.cwd) } : {}
		});
	}
	toolTelemetry(source, tool) {
		return {
			origin: source === "adapter" ? "adapter" : source === "framework" || source === "result" ? "framework" : "model",
			description: tool.description
		};
	}
	wrapModelTool(tool, source, prepare = (toolCallId, params, signal) => ({
		args: params,
		run: () => tool.execute(toolCallId, params, signal),
		result: toolResultText
	})) {
		const telemetry = this.toolTelemetry(source, tool);
		const wrapped = {
			...tool,
			execute: async (toolCallId, params, signal) => {
				let prepared;
				try {
					if (signal?.aborted) throw abortErrorFor(signal);
					prepared = await abandonToolOnAbort(async () => prepare(toolCallId, params, signal), signal);
				} catch (error) {
					const call = this.activeToolCalls.get(toolCallId) ?? {
						startedAt: Date.now(),
						toolName: tool.name,
						telemetry,
						startEmitted: false
					};
					call.error = error;
					if (!call.startEmitted) {
						this.emit({
							type: "tool_start",
							toolName: tool.name,
							toolCallId
						}, telemetry);
						call.startEmitted = true;
					}
					this.activeToolCalls.set(toolCallId, call);
					throw error;
				}
				const call = this.activeToolCalls.get(toolCallId) ?? {
					startedAt: Date.now(),
					toolName: tool.name,
					telemetry,
					startEmitted: false
				};
				call.telemetry = telemetry;
				this.activeToolCalls.set(toolCallId, call);
				if (!call.startEmitted) {
					this.emit({
						type: "tool_start",
						toolName: tool.name,
						toolCallId
					}, {
						...telemetry,
						args: prepared.args
					});
					call.startEmitted = true;
				}
				try {
					const result = await interceptExecution({
						type: "tool",
						toolCallId,
						toolName: tool.name
					}, this.executionContext(), () => abandonToolOnAbort(prepared.run, signal));
					call.effectiveResult = prepared.result ? prepared.result(result) : result;
					call.effectiveResultCaptured = true;
					return result;
				} catch (error) {
					call.error = error;
					throw error;
				}
			}
		};
		this.modelToolTelemetry.set(wrapped, telemetry);
		return wrapped;
	}
	/**
	* `ctx.log` for one tool call: progress lines emitted into the
	* conversation stream as `log` events attributed to the call. Not part of
	* the tool result; the model never sees them.
	*/
	createToolLogger(tool, toolCallId) {
		return this.createAttributedLogger({
			tool,
			toolCallId
		});
	}
	/**
	* The invocation-scoped `step` behind `durable: true` tools. Each
	* completed step settles as a `tool_step_settled` record under the
	* deterministic id derived from `(toolCallId, stepName)`, and the append
	* is awaited before `do` resolves — a checkpoint that has not landed is
	* not a checkpoint. A recovery re-execution of the same toolCallId finds
	* a prior attempt's memo by that id and replays the recorded value
	* instead of running the step again. The returned value is always the
	* JSON clone, so first execution and replay hand the caller identical
	* shapes.
	*/
	createToolStep(toolName, toolCallId, log) {
		const used = /* @__PURE__ */ new Set();
		return { do: async (name, fn) => {
			const stepName = claimStepName(name, toolName, used);
			const recordId = toolStepRecordId(toolCallId, stepName);
			const existing = await this.conversationWriter.getRecord(recordId);
			if (existing?.type === "tool_step_settled") {
				log.info(`step "${stepName}" replayed`, { step: stepName });
				return existing.value;
			}
			const value = cloneStepValue(await fn(), toolName, stepName);
			await this.appendCanonical([{
				...this.canonicalEnvelope("tool_step_settled", recordId),
				type: "tool_step_settled",
				toolCallId,
				toolName,
				stepName,
				value
			}]);
			log.info(`step "${stepName}" completed`, { step: stepName });
			return value;
		} };
	}
	/**
	* The invocation-scoped harness behind `harness: true` tools and
	* lifecycle hook runs: the one interface between tool code and the agent's runtime
	* (sandbox shell/fs, sessions, model calls). Scoped to the invocation
	* (`close()` after the run), depth-counted against the general delegation
	* cap — the fuse on tool→session→tool recursion — and every child
	* conversation it opens is durably retained under the invocation id.
	* Callers must remove it from {@link activeActionHarnesses} and `close()`
	* it when the run settles.
	*/
	createInvocationHarness(invocationId, signal) {
		if (!this.createActionHarness) throw new Error("[flue] This session cannot run harness-connected tools.");
		if (this.delegationDepth >= MAX_DELEGATION_DEPTH) throw new DelegationDepthExceededError({ maxDepth: MAX_DELEGATION_DEPTH });
		const harness = this.createActionHarness({
			invocationId,
			depth: this.delegationDepth + 1,
			signal,
			executionContext: this.executionIdentity,
			eventCallback: this.eventCallback,
			config: this.config,
			env: this.attachedEnv,
			tools: this.agentTools,
			retainSession: async (session, conversation, harnessScope) => {
				await this.conversationWriter.ensureChildConversation({
					parent: {
						conversationId: this.conversationId,
						harness: this.executionIdentity.harness ?? "default",
						session: this.name
					},
					child: {
						kind: "action",
						conversationId: conversation.conversationId,
						harness: harnessScope,
						session,
						affinityKey: conversation.affinityKey,
						createdAt: conversation.createdAt,
						parentConversationId: this.conversationId,
						actionInvocationId: invocationId
					},
					ref: {
						conversationId: conversation.conversationId,
						harness: harnessScope,
						session,
						type: "action",
						invocationId
					}
				});
			}
		});
		this.activeActionHarnesses.add(harness);
		return harness;
	}
	createCustomTools(tools) {
		return tools.map((toolDef) => {
			const preparedToolAdapter = getPreparedToolAdapter(toolDef);
			if (!preparedToolAdapter) assertToolDefinition(toolDef, `Tool "${toolDef.name}"`);
			const nativeInput = !preparedToolAdapter && !isValibotSchema(toolDef.input) && isNativeToolInput(toolDef.input);
			const tool = {
				...(nativeInput ? { validateArguments: async (args, { toolCallId, signal }) => {
					const parsed = await abandonToolOnAbort(() => parseToolInput(toolDef, args, signal, { toolCallId }), signal);
					return parsed.data;
				} } : {}),
				name: toolDef.name,
				label: toolDef.name,
				...(toolDef.prepareArguments ? { prepareArguments: (args) => toolDef.prepareArguments(structuredClone(args)) } : {}),
				description: toolDef.description,
				parameters: preparedToolAdapter?.parameters ?? (toolDef.input ? toolInputToJsonSchema(toolDef.input) : {
					type: "object",
					properties: {},
					additionalProperties: false
				}),
				execute: async () => {
					throw new Error("unreachable");
				}
			};
			return this.wrapModelTool(tool, "custom", async (toolCallId, params, signal) => {
				if (preparedToolAdapter) return {
					args: params,
					run: async () => ({
						content: [{
							type: "text",
							text: await preparedToolAdapter.execute(params, signal)
						}],
						details: { customTool: toolDef.name }
					}),
					result: toolResultText
				};
				const toolLogger = this.createToolLogger(toolDef.name, toolCallId);
				const facilities = { log: toolLogger, toolCallId, ...toolDef.durable ? { step: this.createToolStep(toolDef.name, toolCallId, toolLogger) } : {} };
				// Native args were parsed once by validateArguments, before beforeToolCall.
				const parsed = nativeInput ? { data: params, context: { ...toolContextBase(toolDef, signal, facilities), data: params } } : await parseToolInput(toolDef, params, signal, facilities);
				return {
					args: parsed.data,
					run: async () => {
						const invocationId = toolDef.harness ? generateInvocationId() : void 0;
						const harness = invocationId ? this.createInvocationHarness(invocationId, signal) : void 0;
						try {
							const context = harness ? {
								...parsed.context,
								harness
							} : parsed.context;
							const resolved = resolveToolRun(toolDef, await toolDef.run(context));
							const output = resolved.output;
							return {
								content: [{
									type: "text",
									text: output === void 0 ? "null" : JSON.stringify(output)
								}],
								details: {
									customTool: toolDef.name,
									output,
									...invocationId ? { invocationId } : {}
								},
								...resolved.terminate ? { terminate: true } : {}
							};
						} finally {
							if (harness) {
								this.activeActionHarnesses.delete(harness);
								await harness.close();
							}
						}
					},
					result: (value) => value.details.output
				};
			});
		});
	}
	assembleModelTools(baseGroups, customDefinitions, extraTools) {
		const groups = [
			...baseGroups,
			{
				source: "custom",
				tools: this.createCustomTools(customDefinitions)
			},
			{
				source: "result",
				tools: extraTools
			}
		];
		const seen = /* @__PURE__ */ new Map();
		const frameworkReserved = /* @__PURE__ */ new Set([
			"task",
			"activate_skill",
			READ_SKILL_RESOURCE_TOOL_NAME,
			FINISH_TOOL_NAME,
			GIVE_UP_TOOL_NAME
		]);
		for (const group of groups) for (const tool of group.tools) {
			if (frameworkReserved.has(tool.name) && group.source !== "framework" && !(group.source === "result" && (tool.name === "finish" || tool.name === "give_up"))) throw new ToolNameConflictError({
				name: tool.name,
				conflict: "reserved",
				source: group.source,
				reserved: [...frameworkReserved]
			});
			if (seen.has(tool.name)) throw new ToolNameConflictError({
				name: tool.name,
				conflict: "duplicate",
				source: group.source
			});
			seen.set(tool.name, group.source);
		}
		return groups.flatMap((group) => group.source === "custom" ? group.tools : group.tools.map((tool) => group.source === "result" ? this.wrapModelTool(tool, group.source, (_toolCallId, params, signal) => {
			if (signal?.aborted) throw abortErrorFor(signal);
			const prepared = prepareResultTool(tool, params);
			if (!prepared) throw new Error("[flue] Result tool has no registered preparer.");
			return prepared;
		}) : this.wrapModelTool(tool, group.source)));
	}
	/** Build built-in tools from the sandbox adapter or the framework defaults. */
	createBuiltinToolGroups(env, model, thinkingLevel, activePackagedSkills) {
		const runTask = (params, signal, toolCallId) => this.runTaskForTool(params, model, thinkingLevel, signal, toolCallId);
		const packagedSkills = {
			...getRegisteredPackagedSkills(this.liveSkills),
			...activePackagedSkills
		};
		const activateSkillTool = Object.keys(this.liveSkills).length > 0 ? createActivateSkillTool((name) => this.activateSkillForTool(name)) : void 0;
		const packagedRead = Object.values(packagedSkills).some((skill) => Object.keys(skill.files).some((path) => path !== "SKILL.md")) ? createPackagedSkillReadTool(packagedSkills) : void 0;
		const frameworkTools = () => [
			createTaskTool(runTask),
			...activateSkillTool ? [activateSkillTool] : [],
			...packagedRead ? [packagedRead] : []
		];
		if (!env) return [{
			source: "framework",
			tools: frameworkTools()
		}];
		const toolEnv = overlayPackagedSkills(env, packagedSkills);
		if (this.toolFactory) return [{
			source: "adapter",
			tools: this.toolFactory(toolEnv, { subagents: this.liveSubagents })
		}, {
			source: "framework",
			tools: frameworkTools()
		}];
		return [{
			source: "builtin",
			tools: [
				createReadTool(toolEnv),
				createWriteTool(toolEnv),
				createEditTool(toolEnv),
				createBashTool(toolEnv),
				createGrepTool(toolEnv),
				createGlobTool(toolEnv)
			]
		}, {
			source: "framework",
			tools: frameworkTools()
		}];
	}
	async withCallOverrides(options, fn) {
		const previousTools = this.agentLoop.state.tools;
		const previousModel = this.agentLoop.state.model;
		const previousThinkingLevel = this.agentLoop.state.thinkingLevel;
		const resolvedModel = this.resolveModelForCall(options.model);
		this.agentLoop.state.model = resolvedModel;
		this.agentLoop.state.thinkingLevel = this.resolveThinkingLevelForCall(options.thinkingLevel);
		const builtinToolGroups = this.createBuiltinToolGroups(this.attachedEnv, options.model, options.thinkingLevel, options.activePackagedSkills);
		this.agentLoop.state.tools = this.assembleModelTools(builtinToolGroups, [...this.agentTools, ...options.tools], options.extraTools ?? []);
		this.activeCallOverrides = options;
		try {
			return await fn({ resolvedModel });
		} finally {
			this.activeCallOverrides = void 0;
			this.agentLoop.state.tools = this.rerender ? this.assembleModelTools(this.createBuiltinToolGroups(this.attachedEnv), this.agentTools, []) : previousTools;
			this.agentLoop.state.model = previousModel;
			this.agentLoop.state.thinkingLevel = previousThinkingLevel;
		}
	}
	resolveSubagent(name, delivery) {
		const subagents = this.liveSubagents;
		const subagent = subagents[name];
		if (!subagent) throw new SubagentNotDeclaredError({
			subagent: name,
			available: Object.keys(subagents)
		});
		return resolveSubagentDefinition(subagent, delivery);
	}
	async runTaskForTool(params, inheritedModel, inheritedThinkingLevel, signal, toolCallId) {
		if (!params.agent || !this.liveSubagents[params.agent]) {
			const available = Object.keys(this.liveSubagents);
			return {
				content: [{
					type: "text",
					text: `Subagent "${params.agent}" is not declared. Available subagents: ${available.length > 0 ? available.join(", ") : "(none)"}.`
				}],
				details: {
					agent: params.agent,
					available
				}
			};
		}
		const attachmentIds = [...new Set((params.attachments ?? []).map((attachment) => attachment.id))];
		const images = await this.resolveCanonicalImages(attachmentIds);
		const result = await this.executeTask(params.prompt, {
			agent: params.agent,
			inheritedModel,
			inheritedThinkingLevel,
			cwd: params.cwd,
			images,
			toolCallId
		}, signal);
		return {
			content: [{
				type: "text",
				text: result.text || "(task completed with no text)"
			}],
			details: {
				taskId: result.taskId,
				session: result.session,
				messageId: result.messageId,
				agent: result.agent,
				cwd: result.cwd
			}
		};
	}
	async executeTask(text, options, signal) {
		this.assertActive();
		if (!this.createTaskSession) throw new Error("[flue] This session cannot create task sessions.");
		if (this.delegationDepth >= MAX_DELEGATION_DEPTH) throw new DelegationDepthExceededError({ maxDepth: MAX_DELEGATION_DEPTH });
		assertImagesWithinLimit(options?.images);
		if (signal?.aborted) throw abortErrorFor(signal);
		const taskId = generateTaskId();
		const taskAgent = options?.agent ? this.resolveSubagent(options.agent, taskDeliveryMessage(text, options?.images)) : void 0;
		let child;
		let abortListener;
		const taskStartMs = Date.now();
		try {
			child = await this.createTaskSession({
				parentSession: this.name,
				parentConversationId: this.conversationId,
				taskId,
				parentEnv: this.attachedEnv,
				cwd: options?.cwd,
				agent: taskAgent,
				depth: this.delegationDepth + 1,
				...options?.toolCallId ? { parentToolCallId: options.toolCallId } : {},
				...options?.toolCallId && this.canonicalToolRequestMessageId ? { parentAssistantEntryId: this.canonicalToolRequestMessageId } : {}
			});
			this.activeTasks.add(child);
			this.emit({
				type: "task_start",
				taskId,
				prompt: text,
				agent: taskAgent?.name,
				cwd: options?.cwd,
				parentSession: this.name,
				session: child.name,
				conversationId: child.conversationId
			}, {
				agentInput: {
					text: buildPromptText(text, options?.result),
					...options?.images?.length ? { images: options.images.map((image) => ({ mimeType: image.mimeType })) } : {}
				},
				...options?.toolCallId ? { toolCallId: options.toolCallId } : {}
			});
			if (signal) {
				abortListener = () => child?.abort();
				signal.addEventListener("abort", abortListener, { once: true });
			}
			const schema = options?.result;
			const childOptions = {
				model: options?.model ?? (taskAgent?.model !== void 0 ? void 0 : options?.inheritedModel),
				thinkingLevel: options?.thinkingLevel ?? (taskAgent?.thinkingLevel !== void 0 ? void 0 : options?.inheritedThinkingLevel),
				tools: options?.tools,
				images: options?.images,
				signal
			};
			if (schema) childOptions.result = schema;
			const taskChild = child;
			const output = await interceptExecution({
				type: "task",
				taskId
			}, this.executionContext({
				conversationId: taskChild.conversationId,
				session: taskChild.name,
				taskId
			}), async () => taskChild.prompt(text, childOptions));
			const taskResult = {
				output,
				text: typeof output?.text === "string" ? output.text : child.getAssistantText(),
				taskId,
				session: child.name,
				messageId: await child.getLatestAssistantMessageId(),
				agent: taskAgent?.name,
				cwd: options?.cwd
			};
			this.emit({
				type: "task",
				taskId,
				agent: taskAgent?.name,
				isError: false,
				result: taskResult.text,
				durationMs: durationSince(taskStartMs),
				parentSession: this.name,
				session: child.name,
				conversationId: child.conversationId
			}, { agentOutput: child.agentInvocationOutput(output) });
			return taskResult;
		} catch (error) {
			this.emit({
				type: "task",
				taskId,
				agent: taskAgent?.name,
				isError: true,
				result: getErrorMessage(error),
				durationMs: durationSince(taskStartMs),
				parentSession: this.name,
				...child ? {
					session: child.name,
					conversationId: child.conversationId
				} : {}
			}, { errorInfo: classifyError(error) });
			throw error;
		} finally {
			if (signal && abortListener) signal.removeEventListener("abort", abortListener);
			if (child) {
				await child.close();
				this.activeTasks.delete(child);
			}
		}
	}
	async runOperation(operation, signal, fn) {
		const operationSignal = signal && this.scopeSignal ? AbortSignal.any([signal, this.scopeSignal]) : signal ?? this.scopeSignal;
		return this.runExclusive(operation, async () => {
			if (operationSignal?.aborted) throw abortErrorFor(operationSignal);
			this.activeOperationId = generateOperationId();
			const operationId = this.activeOperationId;
			const startedAt = Date.now();
			this.emit({
				type: "operation_start",
				operationId,
				operationKind: operation
			});
			const onAbort = () => this.abort(operationSignal?.reason);
			operationSignal?.addEventListener("abort", onAbort, { once: true });
			try {
				const execute = () => fn();
				const result = operation === "prompt" || operation === "skill" ? await interceptExecution({
					type: "agent",
					operationId,
					operationKind: operation
				}, this.executionContext({ operationId }), execute) : await execute();
				this.emit({
					type: "operation",
					operationId,
					operationKind: operation,
					durationMs: durationSince(startedAt),
					isError: false,
					result,
					usage: usageFromResult(result)
				}, operation === "prompt" || operation === "skill" ? {
					agentInput: this.activeAgentInput,
					agentOutput: this.agentInvocationOutput(result)
				} : void 0);
				return result;
			} catch (error) {
				const surfaced = operationSignal?.aborted ? abortErrorFor(operationSignal) : error;
				this.emit({
					type: "operation",
					operationId,
					operationKind: operation,
					durationMs: durationSince(startedAt),
					isError: true,
					error: serializeEventError(surfaced)
				}, operation === "prompt" || operation === "skill" ? {
					agentInput: this.activeAgentInput,
					errorInfo: classifyError(surfaced)
				} : { errorInfo: classifyError(surfaced) });
				throw surfaced;
			} finally {
				operationSignal?.removeEventListener("abort", onAbort);
				this.emit({ type: "idle" });
				this.activeOperationId = void 0;
				this.activeAgentInput = void 0;
			}
		});
	}
	async runExclusive(operation, fn) {
		this.assertActive();
		if (this.activeOperation) throw new SessionBusyError({
			session: this.name,
			activeOperation: this.activeOperation
		});
		this.activeOperation = operation;
		this.activeOperationSettlement = new Promise((resolve) => {
			this.resolveActiveOperationSettlement = resolve;
		});
		try {
			return await fn();
		} finally {
			this.activeOperation = void 0;
			this.resolveActiveOperationSettlement?.();
			this.resolveActiveOperationSettlement = void 0;
		}
	}
	executionContext(overrides = {}) {
		return {
			...this.executionIdentity,
			conversationId: this.conversationId,
			session: this.name,
			...this.activeOperationId ? { operationId: this.activeOperationId } : {},
			...this.activeTurnId ? { turnId: this.activeTurnId } : {},
			...overrides
		};
	}
	emit(event, observation) {
		const decorated = {
			...redactEventImages(event),
			conversationId: event.conversationId ?? this.conversationId,
			session: event.session ?? this.name
		};
		const operationId = event.operationId ?? this.activeOperationId;
		if (operationId !== void 0) decorated.operationId = operationId;
		const turnId = event.turnId ?? this.activeTurnId;
		if (turnId !== void 0) decorated.turnId = turnId;
		this.eventCallback?.(decorated, redactObservationDetailImages(observation));
	}
	assertActive() {
		if (this.closed) throw abortErrorFor(AbortSignal.abort());
	}
	/** Resolve attachment ids visible in the live context to their images. */
	async resolveCanonicalImages(ids) {
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation) throw new AttachmentNotAvailableError({ attachmentId: ids[0] ?? "" });
		const available = this.visibleCanonicalAttachments(conversation);
		const images = [];
		for (const id of ids) {
			const attachment = available.get(id);
			if (!attachment) throw new AttachmentNotAvailableError({ attachmentId: id });
			const stored = await this.attachmentStore.get({
				streamPath: this.conversationWriter.path,
				conversationId: this.conversationId,
				attachmentId: id
			});
			if (!stored) throw new AttachmentNotAvailableError({ attachmentId: id });
			images.push({
				type: "image",
				data: encodeBase64(stored.bytes),
				mimeType: attachment.mimeType
			});
		}
		return images;
	}
	visibleCanonicalAttachments(conversation) {
		const available = /* @__PURE__ */ new Map();
		for (const contextEntry of buildConversationContextEntries(conversation, { resolveAttachment: (attachment) => ({
			data: attachment.id,
			mimeType: attachment.mimeType
		}) })) {
			if (contextEntry.sourceEntry.type !== "message") continue;
			for (const attachment of contextEntry.sourceEntry.attachmentRefs?.values() ?? []) available.set(attachment.id, attachment);
		}
		return available;
	}
	async persistCanonicalAttachments(attachments) {
		const refs = [];
		for (const attachment of attachments) {
			const bytes = decodeBase64(attachment.data);
			const ref = await createAttachmentRef({
				id: attachment.id,
				mimeType: attachment.mimeType,
				bytes,
				...attachment.filename ? { filename: attachment.filename } : {}
			});
			await this.attachmentStore.put({
				streamPath: this.conversationWriter.path,
				attachment: ref,
				bytes,
				conversationId: this.conversationId
			});
			refs.push(ref);
		}
		return refs;
	}
	/**
	* Persist a tool result's image blocks as canonical attachments
	* (`att_<messageId>_<index>`) and return the record-shaped content with
	* each image replaced by its attachment ref.
	*/
	async persistToolResultContent(result, messageId) {
		const refs = await this.persistCanonicalAttachments(result.content.flatMap((content, index) => content.type === "image" ? [{
			id: `att_${messageId}_${index}`,
			mimeType: content.mimeType,
			data: content.data
		}] : []));
		let imageIndex = 0;
		return result.content.map((content) => {
			if (content.type === "text") return {
				type: "text",
				text: content.text
			};
			const attachment = refs[imageIndex++];
			if (!attachment) throw new Error("[flue] Canonical tool outcome attachment is missing.");
			return {
				type: "attachment",
				attachment
			};
		});
	}
	/** Append a `session.shell()` call as an LLM-shaped bash tool exchange. */
	async appendShellTriple(toolCallId, args, toolResult, isError) {
		const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
		const userMessageId = generateConversationEntryId();
		const assistantMessageId = generateConversationEntryId();
		const resultMessageId = toolResultEntryId(assistantMessageId, toolCallId);
		const outcomeContent = await this.persistToolResultContent(toolResult, resultMessageId);
		await this.appendCanonical([
			{
				...this.canonicalEnvelope("user_message"),
				type: "user_message",
				messageId: userMessageId,
				parentId,
				content: [{
					type: "text",
					text: `Run this shell command:\n\n\`\`\`bash\n${String(args.command)}\n\`\`\``
				}]
			},
			{
				...this.canonicalEnvelope("assistant_message_started"),
				type: "assistant_message_started",
				messageId: assistantMessageId,
				parentId: userMessageId,
				modelInfo: {
					api: "flue-shell",
					provider: "flue",
					model: ""
				}
			},
			{
				...this.canonicalEnvelope("assistant_tool_call"),
				type: "assistant_tool_call",
				messageId: assistantMessageId,
				blockId: generateBlockId(),
				blockIndex: 0,
				toolCallId,
				name: "bash",
				arguments: args
			},
			{
				...this.canonicalEnvelope("assistant_message_completed"),
				type: "assistant_message_completed",
				messageId: assistantMessageId,
				stopReason: "toolUse",
				usage: zeroProviderUsage()
			},
			{
				...this.canonicalEnvelope("tool_outcome", `record_tool_outcome_${encodeCanonicalId(assistantMessageId)}_${encodeCanonicalId(toolCallId)}`),
				type: "tool_outcome",
				assistantMessageId,
				toolCallId,
				toolName: "bash",
				isError,
				content: outcomeContent
			},
			{
				...this.canonicalEnvelope("tool_results_committed"),
				type: "tool_results_committed",
				assistantMessageId,
				parentId: assistantMessageId,
				outcomeIds: [`record_tool_outcome_${encodeCanonicalId(assistantMessageId)}_${encodeCanonicalId(toolCallId)}`]
			}
		]);
		await this.rebuildCanonicalContext();
	}
	async requireConversation() {
		const conversation = await this.conversationWriter.getConversation(this.conversationId);
		if (!conversation) throw new Error("[flue] Canonical conversation is missing.");
		return conversation;
	}
	async resolveCanonicalContextAttachments(conversation) {
		const resolved = /* @__PURE__ */ new Map();
		for (const attachment of this.visibleCanonicalAttachments(conversation).values()) {
			const stored = await this.attachmentStore.get({
				streamPath: this.conversationWriter.path,
				conversationId: this.conversationId,
				attachmentId: attachment.id
			});
			if (!stored) throw new AttachmentNotAvailableError({ attachmentId: attachment.id });
			resolved.set(attachment.id, {
				type: "image",
				data: encodeBase64(stored.bytes),
				mimeType: stored.attachment.mimeType
			});
		}
		return resolved;
	}
	async rebuildCanonicalContext() {
		const conversation = await this.requireConversation();
		const resolved = await this.resolveCanonicalContextAttachments(conversation);
		const messages = buildConversationContext(conversation, { resolveAttachment: (attachment) => {
			const image = resolved.get(attachment.id);
			if (!image) throw new AttachmentNotAvailableError({ attachmentId: attachment.id });
			return image;
		} });
		this.agentLoop.state.messages = messages;
	}
	/**
	* Drive the agent loop with recovery: each iteration first evaluates the
	* trailing assistant (overflow → compact, transient error → back off) and
	* then starts the next turn, so one loop body serves both live turns and
	* resumption of persisted state.
	*
	* Live callers pass only `start`; their first iteration has nothing to
	* evaluate and recovery applies to the turns the loop itself produces.
	* The persisted-input resume path additionally passes `resume` with the
	* trailing assistant the classifier found after the input (if any), so
	* the persisted state gets the same recovery evaluation before the first
	* `continue()`. When recovery is already exhausted at resume entry, the
	* loop throws `OperationFailedError` for `resume.errorLabel`: no live
	* turn has run, so `agentLoop.state.errorMessage` is unset and the
	* caller's `throwIfError` could not surface the failure.
	*/
	async runModelTurnWithRecovery(options) {
		let start = options.start;
		let assistant = options.resume?.assistant;
		let turnCompleted = false;
		let overflowRecoveryAttempted = false;
		const continueRebuilt = () => {
			if (options.restart && this.agentLoop.state.messages.at(-1)?.role === "assistant") return options.restart();
			return this.agentLoop.continue();
		};
		const throwIfHalted = () => {
			if (options.signal.aborted) throw abortErrorFor(options.signal);
			if (this.activeTimeoutAt !== void 0 && Date.now() >= this.activeTimeoutAt) throw new SubmissionTimeoutError();
		};
		while (true) {
			const overflow = assistant !== void 0 && isAssistantContextOverflow(assistant, this.agentLoop.state.model.contextWindow ?? 0);
			const retryable = !overflow && assistant !== void 0 && isRetryableModelError(assistant);
			if (turnCompleted && !overflow && !retryable) {
				if (assistant !== void 0) {
					await this.checkCompaction(assistant);
					if (assistant.stopReason === "error" || assistant.stopReason === "aborted") await this.rebuildCanonicalContext();
				}
				return;
			}
			if (overflow && overflowRecoveryAttempted) {
				await this.rebuildCanonicalContext();
				return;
			}
			throwIfHalted();
			if (overflow && assistant !== void 0) {
				overflowRecoveryAttempted = true;
				this.internalLog("info", "[flue:compaction] Overflow detected, compacting and retrying...");
				await this.rebuildCanonicalContext();
				if (!await this.runCompaction("overflow")) {
					if (!turnCompleted && options.resume) throw new OperationFailedError({
						operation: options.resume.errorLabel,
						reason: assistant.errorMessage ?? assistant.stopReason
					});
					return;
				}
				this.internalLog("info", "[flue:compaction] Retrying after overflow recovery...");
				start = continueRebuilt;
			} else if (retryable && assistant !== void 0) {
				const canonicalConversation = await this.requireConversation();
				const transientRetries = countConsecutiveRetryableModelErrors(getActiveConversationPath(canonicalConversation).flatMap((entry) => entry.type === "message" ? [entry] : []));
				if (!await this.waitForTransientModelRetry(assistant, transientRetries)) {
					if (!turnCompleted && options.resume) throw new OperationFailedError({
						operation: options.resume.errorLabel,
						reason: assistant.errorMessage ?? assistant.stopReason
					});
					return;
				}
				start = continueRebuilt;
			}
			if (overflow || retryable) throwIfHalted();
			try {
				await start();
				await this.agentLoop.waitForIdle();
			} catch (error) {
				await this.rebuildCanonicalContext();
				throw error;
			}
			turnCompleted = true;
			const messages = this.agentLoop.state.messages;
			const latest = messages[messages.length - 1];
			assistant = latest?.role === "assistant" ? latest : void 0;
		}
	}
	async waitForTransientModelRetry(assistant, attempt) {
		if (attempt > MAX_TRANSIENT_MODEL_RETRIES) {
			this.internalLog("warn", "[flue:model-retry] Transient model error retries exhausted", {
				attempts: attempt - 1,
				error: assistant.errorMessage
			});
			await this.rebuildCanonicalContext();
			return false;
		}
		const delayMs = modelRetryDelayMs(attempt);
		await this.rebuildCanonicalContext();
		this.modelRetryAbortController = new AbortController();
		this.internalLog("warn", "[flue:model-retry] Retrying transient model error", {
			attempt,
			maxRetries: MAX_TRANSIENT_MODEL_RETRIES,
			delayMs,
			error: assistant.errorMessage
		});
		try {
			await sleepUntilRetry(delayMs, this.modelRetryAbortController.signal);
		} finally {
			this.modelRetryAbortController = void 0;
		}
		return true;
	}
	async checkCompaction(assistantMessage) {
		if (assistantMessage.stopReason === "aborted" || assistantMessage.stopReason === "error") return;
		const model = this.agentLoop.state.model;
		const settings = this.resolveCompactionSettings(model);
		if (!settings.enabled) return;
		const contextWindow = model.contextWindow ?? 0;
		const contextTokens = calculateContextTokens(assistantMessage.usage);
		if (shouldCompact(contextTokens, contextWindow, settings)) {
			this.internalLog("info", `[flue:compaction] Threshold reached — ${contextTokens} tokens used, window ${contextWindow}, reserve ${settings.reserveTokens}, triggering compaction`);
			await this.runCompaction("threshold");
		}
	}
	/**
	* Runs a compaction pass. The summarization cost (1–2 internal LLM
	* calls) is persisted on the resulting canonical compaction usage, which
	* `aggregateUsageSince` later folds into the surrounding call's
	* `response.usage` — so users see the true cost of the call that
	* triggered compaction.
	*/
	async runCompaction(reason) {
		this.compactionAbortController = new AbortController();
		const messagesBefore = this.agentLoop.state.messages.length;
		const compactionStartMs = Date.now();
		let terminalPending = false;
		try {
			const sessionModel = this.agentLoop.state.model;
			const settings = this.resolveCompactionSettings(sessionModel);
			const compactionConfig = this.config.compaction === false ? void 0 : this.config.compaction;
			const summarizationModel = compactionConfig?.model ? this.resolveModelForCall(compactionConfig.model) : sessionModel;
			const canonicalConversation = await this.requireConversation();
			const resolvedAttachments = await this.resolveCanonicalContextAttachments(canonicalConversation);
			const contextEntries = buildConversationContextEntries(canonicalConversation, { resolveAttachment: (attachment) => {
				const image = resolvedAttachments.get(attachment.id);
				if (!image) throw new AttachmentNotAvailableError({ attachmentId: attachment.id });
				return image;
			} });
			const messages = contextEntries.map((entry) => entry.message);
			const latestCompaction = getLatestConversationCompaction(canonicalConversation);
			const preparation = prepareCompaction(messages, settings, latestCompaction ? {
				summary: latestCompaction.summary,
				firstKeptIndex: 1,
				details: latestCompaction.details
			} : void 0);
			if (!preparation) {
				this.internalLog("info", "[flue:compaction] Nothing to compact (no valid cut point found)");
				return false;
			}
			const firstKeptEntry = contextEntries[preparation.firstKeptIndex]?.sourceEntry;
			if (!firstKeptEntry || firstKeptEntry.type !== "message") {
				this.internalLog("info", "[flue:compaction] Nothing to compact (first kept message has no entry)");
				return false;
			}
			this.internalLog("info", `[flue:compaction] Summarizing ${preparation.messagesToSummarize.length} messages` + (preparation.isSplitTurn ? ` (split turn: ${preparation.turnPrefixMessages.length} prefix messages)` : "") + `, keeping messages from index ${preparation.firstKeptIndex}`);
			const estimatedTokens = preparation.tokensBefore;
			this.emit({
				type: "compaction_start",
				reason,
				estimatedTokens
			});
			terminalPending = true;
			const result = await compact(preparation, summarizationModel, this.compactionAbortController.signal, {
				start: (purpose, model, context, options) => {
					const handle = { turnId: generateTurnId() };
					this.emitTurnRequest(handle.turnId, purpose, model, context, options);
					return handle;
				},
				run: (handle, execute) => interceptExecution({
					type: "model",
					turnId: handle.turnId
				}, this.executionContext({
					operationId: this.activeOperationId,
					turnId: handle.turnId
				}), execute),
				end: (purpose, handle, response, error) => {
					const request = this.modelRequests.get(handle.turnId);
					if (!request) throw new Error(`[flue] Missing model request telemetry for turn "${handle.turnId}".`);
					this.emitTurn(handle.turnId, purpose, response, request.info, error);
					this.modelRequests.delete(handle.turnId);
				}
			});
			if (this.compactionAbortController.signal.aborted) {
				const abortError = abortErrorFor(this.compactionAbortController.signal);
				this.emit({
					type: "compaction",
					messagesBefore,
					messagesAfter: this.agentLoop.state.messages.length,
					durationMs: durationSince(compactionStartMs),
					isError: true,
					error: serializeEventError(abortError)
				}, { errorInfo: classifyError(abortError) });
				terminalPending = false;
				if (reason === "manual") throw abortError;
				return false;
			}
			{
				const sourceLeafId = (await this.requireConversation()).activeLeafId;
				if (!sourceLeafId) throw new Error("[flue] Canonical compaction has no source leaf.");
				await this.rebaselineResources({
					...this.canonicalEnvelope("compaction"),
					type: "compaction",
					entryId: generateConversationEntryId(),
					parentId: sourceLeafId,
					summary: result.summary,
					firstKeptEntryId: firstKeptEntry.id,
					sourceLeafId,
					tokensBefore: result.tokensBefore,
					details: result.details,
					usage: result.usage
				});
			}
			await this.rebuildCanonicalContext();
			const messagesAfter = this.agentLoop.state.messages.length;
			this.internalLog("info", `[flue:compaction] Complete — messages: ${messagesBefore} → ${messagesAfter}, tokens before: ${result.tokensBefore}`);
			this.emit({
				type: "compaction",
				messagesBefore,
				messagesAfter,
				durationMs: durationSince(compactionStartMs),
				isError: false,
				usage: result.usage
			});
			terminalPending = false;
			return true;
		} catch (error) {
			const errorMessage = error instanceof Error ? error.message : String(error);
			this.internalLog("error", `[flue:compaction] Failed: ${errorMessage}`, { error });
			if (terminalPending) this.emit({
				type: "compaction",
				messagesBefore,
				messagesAfter: this.agentLoop.state.messages.length,
				durationMs: durationSince(compactionStartMs),
				isError: true,
				error: serializeEventError(error)
			}, { errorInfo: classifyError(error) });
			if (reason === "manual") throw error;
			return false;
		} finally {
			this.compactionAbortController = void 0;
		}
	}
	internalLog(level, message, attributes) {
		if (level === "error") console.error(message);
		this.emit({
			type: "log",
			level,
			message,
			attributes: normalizeLogAttributes(attributes)
		});
	}
	throwIfError(context) {
		const errorMsg = this.agentLoop.state.errorMessage;
		if (errorMsg) throw new OperationFailedError({
			operation: context,
			reason: errorMsg
		});
	}
	/**
	* Sum the usage of every entry the call appended to the active path
	* after `beforeLeafId`: assistant messages contribute their per-turn
	* `usage` (provider-reported, normalized through `fromProviderUsage`),
	* and compaction entries contribute the aggregated cost of the
	* summarization call(s) they dispatched. Returns zeros when nothing
	* was appended (defensive — `throwIfError` normally fires first).
	*
	* Walks the durable, parent-linked active path rather than the volatile
	* flat `agentLoop.state.messages` array, so the result is robust to
	* mid-call mutations (e.g. overflow recovery removing a failed
	* assistant turn before retry).
	*/
	async aggregateCanonicalUsageSince(beforeLeafId) {
		return aggregateConversationUsageSince(await this.requireConversation(), beforeLeafId) ?? emptyUsage();
	}
	agentInvocationOutput(result) {
		if (typeof result !== "object" || result === null) return void 0;
		if ("data" in result) return {
			type: "data",
			data: result.data
		};
		if ("text" in result && typeof result.text === "string") {
			const messages = this.agentLoop.state.messages;
			for (let i = messages.length - 1; i >= 0; i--) {
				const message = messages[i];
				if (message?.role === "assistant") return {
					type: "text",
					text: result.text,
					finishReason: message.stopReason
				};
			}
		}
	}
	getAssistantText() {
		const messages = this.agentLoop.state.messages;
		for (let i = messages.length - 1; i >= 0; i--) {
			const msg = messages[i];
			if (msg?.role !== "assistant") continue;
			const content = msg.content;
			if (!Array.isArray(content)) continue;
			const textParts = [];
			for (const block of content) if (block.type === "text") textParts.push(block.text);
			return textParts.join("\n");
		}
		return "";
	}
	async getLatestAssistantMessageId() {
		return getActiveConversationPath(await this.requireConversation()).findLast((entry) => entry.type === "message" && entry.message.role === "assistant")?.id;
	}
	canonicalInputEntryId(input) {
		return submissionEntryId(input.kind, input.submissionId);
	}
	inspectCanonicalState(state) {
		switch (state.kind) {
			case "absent": return "absent";
			case "completed": return "completed";
			default: return "interrupted";
		}
	}
	/**
	* Build the canonical `user_message` or `signal` record for a delivered
	* message and drive the conversation from it — the single input path for
	* both a direct HTTP prompt and a `dispatch()` call. Which kind of
	* canonical record gets written depends only on `input.message.kind`, not
	* on whether the submission is `input.kind === 'direct'` or `'dispatch'`
	* (that distinction remains relevant only for record-id namespacing).
	*/
	async runPersistedSubmissionInput(input, signal, options) {
		const message = input.message;
		this.activeAgentInput = message.kind === "user" ? {
			text: message.body,
			...message.attachments?.length ? { images: message.attachments.map((attachment) => ({ mimeType: attachment.mimeType })) } : {}
		} : { text: renderSignalMessage({
			role: "signal",
			type: message.type,
			tagName: message.tagName,
			content: message.body,
			attributes: message.attributes,
			timestamp: Date.now()
		}) };
		return this.runPersistedContextInput({
			inputEntryId: submissionEntryId(input.kind, input.submissionId),
			createCanonicalInput: (parentId) => this.buildSubmissionInputRecord(input, parentId),
			errorLabel: `${input.kind}(${input.submissionId})`,
			onInputApplied: options?.onInputApplied,
			submissionAttempt: options?.submissionAttempt,
			startedAt: options?.startedAt,
			timeoutAt: options?.timeoutAt,
			joinSource: options?.joinSource,
			signal
		});
	}
	/**
	* The canonical `user_message`/`signal` record for a submission's
	* delivered message. Shared by the submission's own input path and the
	* turn-boundary join path. A joined delivery's record carries the
	* DELIVERY's `submissionId` (not the active host's) — that is what keys
	* its `agent_start_run` adoption marker and distinguishes joined input
	* from the host's in the stream; the store authorizes the mismatch
	* against the delivery's durable `joining`/`joined` claim.
	*/
	async buildSubmissionInputRecord(input, parentId, options) {
		const message = input.message;
		const owner = options?.asJoinedDelivery ? { submissionId: input.submissionId } : {};
		const messageId = submissionEntryId(input.kind, input.submissionId);
		const recordId = `record_${input.kind}_input_${input.submissionId}`;
		if (message.kind === "user") {
			const refs = await this.persistCanonicalAttachments((message.attachments ?? []).map((attachment, index) => ({
				id: `att_${input.kind}_${input.submissionId}_${index}`,
				mimeType: attachment.mimeType,
				data: attachment.data,
				...attachment.filename ? { filename: attachment.filename } : {}
			})));
			return {
				...this.canonicalEnvelope("user_message", recordId),
				...owner,
				type: "user_message",
				messageId,
				parentId,
				content: [{
					type: "text",
					text: message.body
				}, ...refs.map((attachment) => ({
					type: "attachment",
					attachment
				}))]
			};
		}
		return {
			...this.canonicalEnvelope("signal", recordId),
			...owner,
			type: "signal",
			messageId,
			parentId,
			signalType: message.type,
			...message.tagName ? { tagName: message.tagName } : {},
			content: message.body,
			...message.attributes ? { attributes: message.attributes } : {}
		};
	}
	/**
	* Repair phase of the resume seam: classify the persisted state after the
	* input and repair the conversation TAIL — upgrade a continuable aborted
	* partial, repair a trailing (partial or unresolved) tool batch — BEFORE
	* anything else appends. Repair requires the interrupted toolUse assistant
	* (or aborted partial) to still be the conversation leaf, so at every
	* ownership seam the order is converge → repair → only then append/steer/
	* drive; structural convergence (`materializeGhostStream`) is the only
	* append allowed earlier, because classification here reads committed
	* entries only. Idempotent: a repaired tail reclassifies to a non-repair
	* state and every branch below no-ops.
	*/
	async repairResumableTail(inputEntryId, signal) {
		const state = classifyConversationSubmission(await this.requireConversation(), inputEntryId, { contextWindow: this.agentLoop.state.model.contextWindow ?? 0 });
		if (state.kind === "resume" && state.mode === "aborted_partial") await this.upgradeAbortedPartialToContinuation();
		if (state.kind === "resume" && state.mode === "tool_results_partial" || state.kind === "tool_use_unresolved") await this.repairTrailingPartialToolBatch(inputEntryId, signal, { batchRequired: state.kind === "resume" || hasToolCallBlocks(state.assistant) });
	}
	/**
	* Resume the conversation from a persisted input entry to completion:
	* repair the conversation tail, classify the canonical state after the
	* input, then drive the model turn(s). Conversation-level and
	* submission-agnostic — used both by the top-level submission resume
	* (`runPersistedContextInput`) and by an in-process subagent reattach
	* (`resumeReattachedChild`). Both callers converge the stream structurally
	* (`materializeGhostStream`) before reaching here, so classification only
	* ever sees complete units.
	*/
	async resumeConversationToCompletion(options) {
		await this.repairResumableTail(options.inputEntryId, options.signal);
		const state = classifyConversationSubmission(await this.requireConversation(), options.inputEntryId, { contextWindow: this.agentLoop.state.model.contextWindow ?? 0 });
		switch (state.kind) {
			case "absent": throw new OperationFailedError({
				operation: options.errorLabel,
				reason: "the input could not be persisted"
			});
			case "advanced_past_input": throw new OperationFailedError({
				operation: options.errorLabel,
				reason: "the session advanced past this input before it completed"
			});
			case "terminal_error": throw new OperationFailedError({
				operation: options.errorLabel,
				reason: state.reason
			});
			case "completed":
			case "resume":
				if (state.kind === "completed" && !state.overflow) break;
				await this.runModelTurnWithRecovery({
					start: () => this.agentLoop.continue(),
					signal: options.signal,
					resume: {
						assistant: state.assistant,
						errorLabel: options.errorLabel
					}
				});
				this.throwIfError(options.errorLabel);
				break;
			case "tool_use_unresolved":
				await this.runModelTurnWithRecovery({
					start: () => this.agentLoop.continue(),
					signal: options.signal,
					resume: {
						assistant: state.assistant,
						errorLabel: options.errorLabel
					}
				});
				this.throwIfError(options.errorLabel);
				break;
			default: throw new Error(`[flue] Unhandled submission classification: ${JSON.stringify(state)}`);
		}
	}
	/**
	* Resume a reattached subagent (recovery only) to completion, returning its
	* final assistant text for the parent's `task` outcome. Runs in the child's
	* own operation so child-internal events stay on the child context; inherits
	* the parent's deadline; converges any interrupted partial stream (D-A,
	* identical to top-level recovery) before classifying and continuing from the
	* child's durable input. Idempotent: an already-completed child resumes as a
	* no-op and returns its recorded text.
	*/
	resumeReattachedChild(options) {
		return createCallHandle(options.signal, (signal) => this.runOperation("prompt", signal, async () => {
			const previousTimeout = this.activeTimeoutAt;
			this.activeTimeoutAt = options.timeoutAt;
			try {
				return await this.withCallOverrides({
					tools: [],
					model: void 0,
					thinkingLevel: void 0
				}, async () => {
					await this.materializeGhostStream({ submissionId: void 0 });
					const conversation = await this.requireConversation();
					const inputEntry = getActiveConversationPath(conversation).find((entry) => entry.type === "message" && entry.message.role === "user");
					if (!inputEntry) throw new Error("[flue] Resumed task conversation has no durable input.");
					await this.resumeConversationToCompletion({
						inputEntryId: inputEntry.id,
						errorLabel: "task",
						signal
					});
					return this.getAssistantText();
				});
			} finally {
				this.activeTimeoutAt = previousTimeout;
			}
		}));
	}
	resolveSubmissionDurability(startedAt, timeoutAt) {
		return {
			maxAttempts: this.config.durability?.maxAttempts ?? 10,
			timeoutAt: timeoutAt ?? (startedAt ?? Date.now()) + (this.config.durability?.timeoutMs ?? 36e5)
		};
	}
	async runPersistedContextInput(options) {
		return this.withCallOverrides({
			tools: [],
			model: void 0,
			thinkingLevel: void 0
		}, async () => {
			this.activeSubmissionId = options.submissionAttempt?.submissionId;
			this.activeSubmissionAttemptId = options.submissionAttempt?.attemptId;
			this.activeJoinSource = options.joinSource;
			this.activeJoinSignal = options.signal;
			this.activeInputEntryId = options.inputEntryId;
			const durability = this.resolveSubmissionDurability(options.startedAt, options.timeoutAt);
			this.activeTimeoutAt = durability.timeoutAt;
			try {
				await this.materializeGhostStream("any");
				if (!await this.conversationWriter.hasConversationEntry(this.conversationId, options.inputEntryId)) {
					await this.settleTrailingToolBatch("any");
					const parentId = await this.conversationWriter.getConversationLeaf(this.conversationId);
					await this.appendCanonical([await options.createCanonicalInput(parentId)]);
				}
				await this.rebuildCanonicalContext();
				await options.onInputApplied?.(durability);
				await this.beginResponseOutput();
				await this.repairResumableTail(options.inputEntryId, options.signal);
				await this.narrateResourceDelta();
				await this.narrateMcpUnavailable();
				await this.runAgentStartHooks(options.signal);
				await this.resolveInterruptedJoins(options.signal);
				await this.applyQueuedJoins();
				await this.resumeConversationToCompletion({
					inputEntryId: options.inputEntryId,
					errorLabel: options.errorLabel,
					signal: options.signal
				});
				await this.runWouldStopPhase({
					errorLabel: options.errorLabel,
					signal: options.signal
				});
				await this.flushResponseOutput();
			} finally {
				this.pendingSignalAppends = [];
				this.agentLoop.clearSteeringQueue();
				this.outputWriteQueue = Promise.resolve();
				this.activeSubmissionId = void 0;
				this.activeSubmissionAttemptId = void 0;
				this.activeJoinSource = void 0;
				this.activeJoinSignal = void 0;
				this.activeInputEntryId = void 0;
				this.activeTimeoutAt = void 0;
			}
		});
	}
	/**
	* Shared body of `prompt()` and `skill()`: scope the runtime, optionally
	* inject the result-tool pair, drive the agent loop, and aggregate usage.
	*
	* Returns `PromptResultResponse<T>` when a result schema is set, else `PromptResponse`.
	*/
	async runPromptCall(args) {
		assertImagesWithinLimit(args.images);
		this.activeAgentInput = {
			text: args.promptText,
			...args.images?.length ? { images: args.images.map((image) => ({ mimeType: image.mimeType })) } : {}
		};
		const resultBundle = args.schema ? createResultTools(args.schema) : void 0;
		return this.withCallOverrides({
			tools: args.tools ?? [],
			model: args.model,
			thinkingLevel: args.thinkingLevel,
			extraTools: resultBundle?.tools,
			activePackagedSkills: args.activePackagedSkills
		}, async ({ resolvedModel }) => {
			const beforeLeafId = await this.conversationWriter.getConversationLeaf(this.conversationId);
			const messageId = generateConversationEntryId();
			const refs = await this.persistCanonicalAttachments((args.images ?? []).map((image, index) => ({
				id: `att_prompt_${messageId}_${index}`,
				mimeType: image.mimeType,
				data: image.data
			})));
			await this.appendCanonical([{
				...this.canonicalEnvelope("user_message"),
				type: "user_message",
				messageId,
				parentId: beforeLeafId,
				content: [{
					type: "text",
					text: args.promptText
				}, ...refs.map((attachment) => ({
					type: "attachment",
					attachment
				}))]
			}]);
			await this.rebuildCanonicalContext();
			const projectedPrompt = this.agentLoop.state.messages.pop();
			if (projectedPrompt?.role !== "user") throw new Error("[flue] Canonical prompt projection is missing its user message.");
			const projectedContent = Array.isArray(projectedPrompt.content) ? projectedPrompt.content : [{
				type: "text",
				text: projectedPrompt.content
			}];
			const projectedText = projectedContent.filter((block) => block.type === "text").map((block) => block.text).join("\n");
			const projectedImages = projectedContent.filter((block) => block.type === "image");
			const model = {
				provider: resolvedModel.provider,
				id: resolvedModel.id
			};
			if (resultBundle) return {
				data: await this.runWithResultTools(projectedText, projectedImages, resultBundle, args.errorLabel, args.signal),
				usage: await this.aggregateCanonicalUsageSince(beforeLeafId),
				model
			};
			await this.runModelTurnWithRecovery({
				start: () => this.agentLoop.prompt(projectedText, projectedImages),
				signal: args.signal
			});
			this.throwIfError(args.errorLabel);
			return {
				text: this.getAssistantText(),
				usage: await this.aggregateCanonicalUsageSince(beforeLeafId),
				model
			};
		});
	}
	/**
	* Drive the agent loop through one or more turns until the LLM either calls
	* the `finish` tool (success) or the `give_up` tool (typed error).
	*
	* If a turn ends with neither tool called, we send a brief reminder and
	* loop. There is no retry cap from the framework's perspective: the model has a
	* clear escape hatch via `give_up`, the user has cancellation via `signal`,
	* and pi-agent-core has its own iteration limits as the final ceiling.
	* `MAX_FOLLOWUPS` is a defense-in-depth ceiling against pathological loops.
	*
	*/
	async runWithResultTools(initialPrompt, initialImages, bundle, errorLabel, signal) {
		const MAX_FOLLOWUPS = 32;
		for (let attempt = 0; attempt <= MAX_FOLLOWUPS; attempt++) {
			if (signal.aborted) throw abortErrorFor(signal);
			await this.runModelTurnWithRecovery({
				start: () => this.agentLoop.prompt(attempt === 0 ? initialPrompt : buildResultFollowUpPrompt(), attempt === 0 ? initialImages : void 0),
				...attempt > 0 ? { restart: () => this.agentLoop.prompt(buildResultFollowUpPrompt()) } : {},
				signal
			});
			this.throwIfError(errorLabel);
			const outcome = bundle.getOutcome();
			if (outcome.type === "finished") return outcome.value;
			if (outcome.type === "gave_up") throw new ResultUnavailableError(outcome.reason, this.getAssistantText());
		}
		throw new ResultUnavailableError(`Agent did not call \`finish\` or \`give_up\` after 33 attempts.`, this.getAssistantText());
	}
};
const publicSessionsBySession = /* @__PURE__ */ new WeakMap();
const internalSessionsByFacade = /* @__PURE__ */ new WeakMap();
/**
* Wrap an internal Session in a facade exposing exactly the {@link FlueSession}
* contract. Session instances carry internal runtime surface (the durable
* submission executor, `abort()`/`close()`, load-bearing `metadata`) that must
* not leak to user code at runtime. Repeated calls for the same Session return
* the same facade.
*/
function createPublicSession(session) {
	const existing = publicSessionsBySession.get(session);
	if (existing) return existing;
	const facade = {
		name: session.name,
		conversationId: session.conversationId,
		fs: session.fs,
		prompt: session.prompt.bind(session),
		shell: session.shell.bind(session),
		skill: session.skill.bind(session),
		task: session.task.bind(session),
		compact: session.compact.bind(session)
	};
	publicSessionsBySession.set(session, facade);
	internalSessionsByFacade.set(facade, session);
	return facade;
}
/**
* Recover the internal Session behind a facade produced by
* {@link createPublicSession}, or `undefined` when the object is not a
* registered facade (e.g. a test fake injected through a harness seam).
* Runtime-internal use only (durable submission processing).
*/
function getInternalSession(session) {
	return internalSessionsByFacade.get(session);
}
function zeroProviderUsage() {
	return {
		input: 0,
		output: 0,
		cacheRead: 0,
		cacheWrite: 0,
		totalTokens: 0,
		cost: {
			input: 0,
			output: 0,
			cacheRead: 0,
			cacheWrite: 0,
			total: 0
		}
	};
}
function submissionEntryId(kind, id) {
	return `entry_${kind}_${encodeCanonicalId(id)}`;
}
/**
* The parent's task prompt as the delegate's delivered message — the same
* `kind: 'user'` shape the child conversation records as its input, so a
* delegate's `useDelivery()` mirrors a root agent's exactly.
*/
function taskDeliveryMessage(text, images) {
	return {
		kind: "user",
		body: text,
		...images?.length ? { attachments: images } : {}
	};
}
function hasToolCallBlocks(message) {
	return message.content.some((block) => block.type === "toolCall");
}
function durationSince(start) {
	return start === void 0 ? 0 : Date.now() - start;
}
function usageFromResult(result) {
	if (typeof result !== "object" || result === null) return void 0;
	const usage = result.usage;
	return isPromptUsage(usage) ? usage : void 0;
}
function isPromptUsage(value) {
	return typeof value === "object" && value !== null && typeof value.input === "number" && typeof value.output === "number" && typeof value.totalTokens === "number";
}
//#endregion
//#region src/runtime/agent-submissions.ts
/**
* Admission-side gate for one send's contact with an instance — sends are
* CONDITIONAL requests (the uid plays the ETag):
*
* - no condition: unconditional deliver — continues an existing instance or
*   creates a fresh one; `initialData` is the seed, consulted only when creating.
* - `uid: '<value>'`: continue only the incarnation the caller knows —
*   absent instance or mismatched uid throws {@link AgentInstanceNotFoundError}.
*   Combining with `initialData` is a contradiction (the condition forbids
*   creation, so a seed is dead weight) and throws.
* - `uid: null`: create only when fresh — an existing instance throws
*   {@link AgentInstanceExistsError} with the existing uid in its details.
*
* Creating sends additionally validate `initialData` against the agent's
* `initialData` contract static (when declared). Everything here runs synchronously BEFORE anything
* durable is admitted, so a failed condition or invalid creation leaves no
* queued submission behind. The uid itself is minted by
* {@link ensureInstanceIdentity} during admission-side materialization — never
* here, and never carried on the durable submission payload — so dispatch
* replays remain idempotent: a replayed admission finds the recorded identity.
*/
async function admitInstanceContact(options) {
	const condition = options.uid;
	if (typeof condition === "string" && options.initialData !== void 0) throw new InvalidRequestError({ reason: "A send conditioned on an existing instance (`uid`) cannot carry `initialData` — the condition forbids creation, so the seed could never apply." });
	const reduced = await options.loadReducedState();
	if (!reduced) {
		if (condition !== void 0) throw new InvalidRequestError({ reason: "Conditional sends (`uid`) require the runtime conversation store, which is unavailable here. Send without a uid condition." });
		return { uid: void 0 };
	}
	const exists = reduced.initialData !== void 0;
	if (typeof condition === "string") {
		if (!exists || reduced.uid !== condition) throw new AgentInstanceNotFoundError({ id: options.id });
		return { uid: reduced.uid };
	}
	if (condition === null && exists) {
		if (reduced.uid === void 0) throw new Error("[flue] invariant: an existing instance's birth record must carry a uid.");
		throw new AgentInstanceExistsError({
			id: options.id,
			uid: reduced.uid
		});
	}
	if (exists) return { uid: reduced.uid };
	parseCreationData(options.agent, options.initialData);
	return { uid: void 0 };
}
/**
* Validate creation data against the agent's `initialData` contract static
* (when declared) and return the schema-parsed output — the value renders see
* and the birth record stores. Shared by admission's contact gate and
* {@link ensureInstanceIdentity} so both surfaces reject with one message.
*/
function parseCreationData(agent, initialData) {
	const schema = resolveAgentInitialDataSchema(agent);
	if (schema === void 0) return initialData;
	const parsed = v.safeParse(schema, initialData);
	if (!parsed.success) throw new InvalidRequestError({ reason: `The agent requires creation data matching its initialData schema: ${parsed.issues.map((issue) => issue.message).join("; ")}. Creation data rides the instance's first message ({ initialData, ... } beside the message).` });
	return parsed.output;
}
/**
* Idempotent find-or-create of the instance's birth record — the single code
* path that creates root instance identity. Admission (both coordinators'
* dispatch/direct paths and their unready-row recovery passes) calls this
* before anything renders; execution (`initializeRootHarness`) requires the
* record to already exist. No render, no sandbox, no workspace discovery.
*
* On a miss, the creation data is schema-parsed before it is recorded and the
* uid is minted here — never carried on the durable submission payload — so a
* replayed or recovered admission finds the recorded identity and receipts
* stay deterministic.
*/
async function ensureInstanceIdentity(writer, agent, initialData) {
	const existing = await writer.findConversation(SUBMISSION_HARNESS_NAME, SUBMISSION_SESSION_NAME);
	if (existing) {
		const { uid } = await writer.loadReducedState();
		if (uid === void 0) throw new Error("[flue] invariant: an existing instance's birth record must carry a uid.");
		return {
			conversationId: existing.conversationId,
			uid
		};
	}
	const data = parseCreationData(agent, initialData);
	const identity = createConversationIdentity();
	const uid = generateInstanceUid();
	await writer.ensureConversation({
		kind: "root",
		conversationId: identity.conversationId,
		harness: SUBMISSION_HARNESS_NAME,
		session: SUBMISSION_SESSION_NAME,
		affinityKey: identity.affinityKey,
		createdAt: identity.createdAt,
		...data !== void 0 ? { initialData: data } : {},
		uid
	});
	return {
		conversationId: identity.conversationId,
		uid
	};
}
function createDispatchAgentSubmissionInput(input) {
	return {
		kind: "dispatch",
		submissionId: input.submissionId,
		agent: input.agent,
		id: input.id,
		message: input.message,
		...input.initialData !== void 0 ? { initialData: input.initialData } : {},
		acceptedAt: input.acceptedAt
	};
}
async function createDirectAgentSubmissionInput(options) {
	return {
		kind: "direct",
		submissionId: options.idempotencyKey !== void 0 ? await deriveKeyedSubmissionId(options.agent, options.id, options.idempotencyKey) : generateSubmissionId(),
		agent: options.agent,
		id: options.id,
		message: options.message,
		...options.initialData !== void 0 ? { initialData: options.initialData } : {},
		acceptedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...options.traceCarrier ? { traceCarrier: options.traceCarrier } : {}
	};
}
/**
* A gate rejection a keyed retry may adopt through: `admitInstanceContact`
* runs before store admission, so a retry whose ORIGINAL send already changed
* the world can fail its own condition — e.g. a create-only send
* (`uid: null`) whose first attempt created the instance throws
* {@link AgentInstanceExistsError} on redelivery. Validation errors are
* excluded: they reject identically on every attempt.
*/
function isInstanceContactRejection(error) {
	return error instanceof AgentInstanceExistsError || error instanceof AgentInstanceNotFoundError;
}
/**
* Converge a keyed admission on the submission its key already names.
*
* The store's byte-exact payload compare is deliberately untouched (it stays
* the corruption tripwire for internal crash/retry replays); a caller retry
* re-stamps `acceptedAt`/`traceCarrier`, so it lands in the store's
* `conflict` branch even when it redelivers the same payload. This helper is
* the keyed-admission escape hatch both coordinators run above the store:
* compare SUBMISSION IDENTITY — `kind`, `agent`, `id`, deep-equal `message`
* (against the hydrated stored input; the store re-hydrates attachment
* bytes), deep-equal `initialData` — ignoring the server-stamped fields.
*
* Matching identity → return the stored row to adopt (the durable input, and
* therefore the executed message, remains the original's). Divergent →
* {@link SubmissionConflictError}: the key names a different delivery.
* No row → `undefined`; the caller falls back to its own failure (rethrowing
* a gate rejection, or treating a rowless store conflict as the conflict).
*/
async function adoptKeyedSubmissionReplay(submissions, input) {
	const existing = await submissions.getSubmission(input.submissionId);
	if (!existing) return void 0;
	if (!sameSubmissionIdentity(input, existing.input)) throw new SubmissionConflictError({ submissionId: input.submissionId });
	return existing;
}
function sameSubmissionIdentity(incoming, stored) {
	return incoming.kind === stored.kind && incoming.agent === stored.agent && incoming.id === stored.id && deepEquals(incoming.message, stored.message) && deepEquals(incoming.initialData, stored.initialData);
}
/** Structural equality; explicitly-`undefined` properties count as absent. */
function deepEquals(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object" || a === null || b === null) return false;
	if (Array.isArray(a) || Array.isArray(b)) {
		if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
		return a.every((value, index) => deepEquals(value, b[index]));
	}
	const left = a;
	const right = b;
	const leftKeys = Object.keys(left).filter((key) => left[key] !== void 0);
	const rightKeys = Object.keys(right).filter((key) => right[key] !== void 0);
	if (leftKeys.length !== rightKeys.length) return false;
	return leftKeys.every((key) => deepEquals(left[key], right[key]));
}
/**
* Attachments are a property of the delivered message, not of the transport:
* this persists them for a `kind: 'user'` message regardless of whether the
* submission arrived as a direct HTTP prompt or a `dispatch()` call. Keyed by
* the deterministic stream path; `conversationId` (the instance identity's
* root conversation) is the idempotency stamp the session reads back with.
* A no-op when the message carries no attachments.
*/
async function materializeSubmissionAttachments(input, conversationId, attachmentStore) {
	const message = input.message;
	if (message.kind !== "user" || !attachmentStore) return;
	for (const [index, attachment] of (message.attachments ?? []).entries()) {
		const bytes = decodeBase64(attachment.data);
		const ref = await createAttachmentRef({
			id: `att_${input.kind}_${input.submissionId}_${index}`,
			mimeType: attachment.mimeType,
			bytes,
			...attachment.filename ? { filename: attachment.filename } : {}
		});
		const streamPath = agentStreamPath(input.agent, input.id);
		await attachmentStore.put({
			streamPath,
			attachment: ref,
			bytes,
			conversationId
		});
	}
}
function createAgentSubmissionSessionHandler(agent, input, execute) {
	return async (ctx) => {
		return execute(await openAgentSubmissionSession(ctx, agent, input));
	};
}
/**
* Shared reconciliation decision tree for an interrupted running submission.
* Used by both the Cloudflare and Node agent coordinators.
*
* Returns the replacement submission when a new attempt was claimed and the
* coordinator should start processing it. Returns `undefined` for every
* other outcome (already completed, requeued, failed/terminalized, or stale)
* because all durable side effects have already been applied inside this
* function and the coordinator needs no further action.
*
* The `createContext` callback builds a `FlueContextInternal` for handler
* execution. Submission input is delivered through the session handler rather
* than context construction.
*/
async function reconcileInterruptedSubmission(submissions, submission, agent, createContext, lease, conversationWriter, emitCoordinatorEvent) {
	const { input } = submission;
	const attempt = submissionAttemptRef(submission);
	if (!attempt) return void 0;
	const ctx = createContext(input.submissionId);
	const state = await createAgentSubmissionSessionHandler(agent, input, (s) => s.inspectSubmissionInput(input))(ctx);
	if (state === "completed") {
		await settleJoinedSubmissions(submissions, attempt, ctx, "completed", void 0, conversationWriter);
		await settleSubmissionWithRecord(submissions, submission.kind, attempt, ctx, "completed", void 0, conversationWriter);
		return;
	}
	if (submission.abortRequestedAt !== void 0) {
		await settleAbortedWithContext(submissions, submission, attempt, agent, createContext(input.submissionId), conversationWriter, emitCoordinatorEvent);
		return;
	}
	if (submission.attemptCount >= submission.maxAttempts) {
		await failInterruptedSubmission(submissions, submission, attempt, agent, "exhausted_retry_budget", (interruptedTools) => state === "absent" ? new SubmissionInterruptedError({
			phase: "retry_exhausted_before_input",
			attemptCount: submission.attemptCount,
			maxAttempts: submission.maxAttempts
		}) : new SubmissionRetryExhaustedError({
			attemptCount: submission.attemptCount,
			maxAttempts: submission.maxAttempts,
			...interruptedTools ? { interruptedTools } : {}
		}), createContext, conversationWriter, emitCoordinatorEvent);
		return;
	}
	if (submission.timeoutAt > 0 && Date.now() >= submission.timeoutAt) {
		await failInterruptedSubmission(submissions, submission, attempt, agent, "exceeded_timeout", () => new SubmissionTimeoutError(), createContext, conversationWriter, emitCoordinatorEvent);
		return;
	}
	if (state === "interrupted") {
		const replacement = await submissions.replaceSubmissionAttempt(attempt, generateAttemptId(), lease);
		if (!replacement?.attemptId) return void 0;
		return replacement;
	}
	await submissions.requeueSubmission(attempt);
}
/**
* The wall-clock deadline after which a queued submission that never became
* claimable (materialization permanently failing, agent definition
* unavailable) is auto-failed by the coordinators' unready passes. Mirrors
* the durability budget philosophy for claimed work: the agent's
* `durability.timeoutMs` static when readable without a render (an invalid
* static falls back rather than stalling termination), else the store default
* (1h) — anchored at admission (`acceptedAt`), so it is computed entirely
* from existing columns.
*/
function unreadySubmissionDeadline(submission, agent) {
	let timeoutMs = DURABILITY_DEFAULT_TIMEOUT_MS;
	if (agent) try {
		assertDurability(agent.durability, `[agent "${submission.input.agent}"]`);
		timeoutMs = agent.durability?.timeoutMs ?? 36e5;
	} catch {}
	return submission.acceptedAt + timeoutMs;
}
/**
* Settle a queued submission that can never be claimed — a durable abort on
* an unready row, or materialization failing past
* {@link unreadySubmissionDeadline}. Settles through
* {@link AgentSubmissionStore.settleQueuedSubmission} (first terminal state
* wins; no attempt, no canonical settlement record) and publishes the live
* `submission_settled` — plus, for a failed outcome, the `terminated`
* `submission_recovery` — only when this call won the terminal transition, so
* recovery convergence (two coordinators re-running the unready pass) emits
* once per settlement. Returns whether this call settled the row.
*/
async function settleUnclaimableSubmission(submissions, submission, outcome, error, emitCoordinatorEvent) {
	if (!await submissions.settleQueuedSubmission(submission.submissionId, outcome, error)) return false;
	const errorInfo = { errorInfo: classifyError(error) };
	emitCoordinatorEvent({
		type: "submission_settled",
		submissionId: submission.submissionId,
		outcome,
		error: serializeSubmissionError(error)
	}, errorInfo);
	if (outcome === "failed") emitCoordinatorEvent({
		type: "submission_recovery",
		submissionId: submission.submissionId,
		kind: submission.kind,
		operation: "materialize_submission",
		outcome: "terminated",
		error: serializeSubmissionError(error)
	}, errorInfo);
	return true;
}
/** Synthetic request for the submission's kind: an agent route for direct prompts, the dispatch path for dispatches. */
function submissionSyntheticRequest(input) {
	if (input.kind === "direct") return new Request(`https://flue.invalid/agents/${encodeURIComponent(input.agent)}/${encodeURIComponent(input.id)}`, { method: "POST" });
	return new Request("https://flue.invalid/_dispatch", { method: "POST" });
}
/**
* Shared submission processing logic used by both Node and Cloudflare
* coordinators. Validates the submission, creates a context, runs the agent
* handler, and settles the submission on success or failure.
*/
async function processSubmission(opts) {
	const { submissions, submission } = opts;
	const { input } = submission;
	if (!submission.attemptId) return;
	const attempt = {
		submissionId: submission.submissionId,
		attemptId: submission.attemptId
	};
	const persisted = await submissions.getSubmission(submission.submissionId);
	if (persisted?.status !== "running" || persisted.attemptId !== attempt.attemptId) return;
	const agent = opts.resolveAgent(input.agent);
	const ctx = opts.createContext(input.submissionId);
	ctx.emitEvent({
		type: "submission_running",
		submissionId: submission.submissionId,
		kind: submission.kind,
		attemptCount: submission.attemptCount,
		maxAttempts: submission.maxAttempts
	});
	const joinSource = {
		claim: () => submissions.claimJoinableSubmissions(attempt, input.agent),
		finalize: (submissionId) => submissions.finalizeJoinedSubmission(attempt, submissionId),
		revert: (submissionId) => submissions.revertJoiningSubmission(attempt, submissionId),
		listUnresolved: () => submissions.listJoinedSubmissions(attempt.submissionId)
	};
	const execute = () => createAgentSubmissionSessionHandler(agent, input, (session) => {
		const handle = session.processSubmissionInput(input, {
			joinSource,
			onInputApplied: async (durability) => {
				if (!await submissions.markSubmissionInputApplied(attempt, durability)) throw new Error("[flue] Agent submission attempt lost ownership before input application.");
				if (submission.kind === "direct") try {
					await ctx.flushEventCallbacks();
				} catch (callbackError) {
					console.error("[flue:event-stream] Direct user event persistence failed before provider execution:", callbackError);
				}
			},
			startedAt: submission.startedAt,
			timeoutAt: submission.inputAppliedAt !== void 0 && submission.timeoutAt > 0 ? submission.timeoutAt : void 0,
			submissionAttempt: attempt
		});
		if (opts.signal && !opts.signal.aborted) {
			const signal = opts.signal;
			const onAbort = () => handle.abort(signal.reason);
			signal.addEventListener("abort", onAbort, { once: true });
			handle.then(() => signal.removeEventListener("abort", onAbort), () => signal.removeEventListener("abort", onAbort));
		} else if (opts.signal?.aborted) handle.abort(opts.signal.reason);
		return handle;
	})(ctx);
	if (persisted.abortRequestedAt !== void 0) {
		await settleAbortedWithContext(submissions, submission, attempt, agent, ctx, opts.conversationWriter, opts.emitCoordinatorEvent);
		return;
	}
	try {
		const run = () => interceptExecution({
			type: "agent",
			operationId: submission.submissionId,
			operationKind: "prompt"
		}, {
			instanceId: input.id,
			submissionId: submission.submissionId,
			agentName: input.agent,
			traceCarrier: input.traceCarrier
		}, execute);
		await run();
	} catch (error) {
		if (opts.isShutdownAbort?.(error)) throw error;
		if (opts.signal?.reason instanceof SubmissionAbortedError) {
			await settleAbortedWithContext(submissions, submission, attempt, agent, ctx, opts.conversationWriter, opts.emitCoordinatorEvent);
			return;
		}
		const settleError = opts.signal?.reason instanceof SubmissionTimeoutError ? opts.signal.reason : error;
		await settleJoinedSubmissions(submissions, attempt, ctx, "failed", settleError, opts.conversationWriter);
		await settleSubmissionWithRecord(submissions, submission.kind, attempt, ctx, "failed", settleError, opts.conversationWriter);
		throw error;
	}
	await settleJoinedSubmissions(submissions, attempt, ctx, "completed", void 0, opts.conversationWriter);
	await settleSubmissionWithRecord(submissions, submission.kind, attempt, ctx, "completed", void 0, opts.conversationWriter);
}
async function failInterruptedSubmission(submissions, submission, attempt, agent, reason, createError, createContext, conversationWriter, emitCoordinatorEvent) {
	const { input } = submission;
	const ctx = createContext(input.submissionId);
	let interruptedTools;
	try {
		interruptedTools = await createAgentSubmissionSessionHandler(agent, input, (s) => s.recordSubmissionTerminal({
			submissionId: submission.submissionId,
			kind: submission.kind,
			reason,
			message: createError(void 0).message
		}))(ctx);
	} catch (terminalError) {
		console.error("[flue:submission-reconciliation] Failed to record terminal message for submission", submission.submissionId, terminalError);
		emitCoordinatorEvent?.({
			type: "submission_recovery",
			submissionId: submission.submissionId,
			kind: submission.kind,
			operation: "reconcile_submission",
			outcome: "terminated",
			attemptCount: submission.attemptCount,
			maxAttempts: submission.maxAttempts,
			error: serializeSubmissionError(terminalError)
		}, { errorInfo: classifyError(terminalError) });
	}
	const error = createError(interruptedTools?.length ? interruptedTools : void 0);
	await settleJoinedSubmissions(submissions, attempt, ctx, "failed", error, conversationWriter);
	await settleSubmissionWithRecord(submissions, submission.kind, attempt, ctx, "failed", error, conversationWriter);
}
/**
* Settle a submission as the distinct `aborted` terminal outcome. Shared by the
* pre-execution abort check, the in-flight abort catch, and the recovery abort
* branch.
*
* Both kinds record a `submission_aborted` conversation advisory (best-effort —
* a persistent save failure must not wedge settlement in a reconciliation loop)
* so the abort is always visible in the message timeline, and both settle
* through the two-phase outbox with `outcome: 'aborted'` — the durable
* terminal record a reconnecting waiter observes.
*/
async function settleAbortedWithContext(submissions, submission, attempt, agent, ctx, conversationWriter, emitCoordinatorEvent) {
	const error = new SubmissionAbortedError();
	try {
		await createAgentSubmissionSessionHandler(agent, submission.input, (s) => s.recordSubmissionTerminal({
			submissionId: submission.submissionId,
			kind: submission.kind,
			reason: "aborted",
			message: error.message
		}))(ctx);
	} catch (advisoryError) {
		console.error("[flue:submission-abort] Failed to record abort advisory for submission", submission.submissionId, advisoryError);
		emitCoordinatorEvent?.({
			type: "submission_recovery",
			submissionId: submission.submissionId,
			kind: submission.kind,
			operation: "process_submission",
			outcome: "terminated",
			attemptCount: submission.attemptCount,
			maxAttempts: submission.maxAttempts,
			error: serializeSubmissionError(advisoryError)
		}, { errorInfo: classifyError(advisoryError) });
	}
	await settleJoinedSubmissions(submissions, attempt, ctx, "aborted", error, conversationWriter);
	await settleSubmissionWithRecord(submissions, submission.kind, attempt, ctx, "aborted", error, conversationWriter);
}
/**
* Settle every delivery joined into the host through the settlement outbox —
* each gets its durable `submission_settled` record with the host's outcome,
* reserved and finalized under the host's attempt — so settlement waiters
* (HTTP `wait()`, an awaited `init()` handle call) always resolve. Runs
* BEFORE the host's own settle in every terminal path; this ordering shares
* the single-process hazard model of the pre-settle terminal advisory (see
* the TODO(multi-process) bounded-hazard note in
* `reconcileInterruptedSubmission` — same deferral, same fix). Idempotent
* across re-attempts: a row
* already terminalizing replays its retained obligation, and one already
* settled is skipped by the reserve gate. The store's settle fan-out remains
* the backstop for any joined row still present when the host settles.
*/
async function settleJoinedSubmissions(submissions, hostAttempt, ctx, outcome, error, conversationWriter) {
	for (const joined of await submissions.listJoinedSubmissions(hostAttempt.submissionId)) {
		if (joined.status !== "joined") continue;
		await settleSubmissionWithRecord(submissions, joined.kind, {
			submissionId: joined.submissionId,
			attemptId: hostAttempt.attemptId
		}, ctx, outcome, error, conversationWriter);
	}
}
async function settleSubmissionWithRecord(submissions, kind, attempt, ctx, outcome, error, conversationWriter) {
	const event = ctx.createEvent({
		type: "submission_settled",
		submissionId: attempt.submissionId,
		outcome,
		...outcome === "completed" ? {} : { error: serializeSubmissionError(error) }
	});
	const publishTerminalEvent = async () => {
		ctx.publishEvent(event, outcome === "completed" ? void 0 : { errorInfo: classifyError(error) });
		try {
			await ctx.flushEventCallbacks();
		} catch (callbackError) {
			console.error("[flue:subscriber] Terminal event subscriber failed:", callbackError);
		}
	};
	const settleOperationalRow = async () => {
		if (outcome === "completed") await submissions.completeSubmission(attempt);
		else await submissions.failSubmission(attempt, error ?? new SubmissionAbortedError());
		await publishTerminalEvent();
	};
	if (!conversationWriter) {
		await settleOperationalRow();
		return;
	}
	const eventKey = `record_${kind}-submission:${attempt.submissionId}:settled`;
	const reduced = await conversationWriter.loadReducedState();
	const conversation = [...reduced.conversations.values()].find((candidate) => [...candidate.entries.values()].some((entry) => entry.submissionId === attempt.submissionId)) ?? [...reduced.conversations.values()].find((candidate) => candidate.harness === "default" && candidate.session === "default");
	if (!conversation) {
		await settleOperationalRow();
		return;
	}
	const pending = (await submissions.listPendingSubmissionSettlements()).find((candidate) => candidate.submissionId === attempt.submissionId);
	const settlement = pending?.record ?? {
		v: 1,
		id: eventKey,
		type: "submission_settled",
		conversationId: conversation.conversationId,
		harness: conversation.harness,
		session: conversation.session,
		timestamp: (/* @__PURE__ */ new Date()).toISOString(),
		submissionId: attempt.submissionId,
		attemptId: attempt.attemptId,
		outcome,
		...outcome === "completed" ? {} : { error: serializeSubmissionError(error) }
	};
	const obligation = pending ?? await submissions.reserveSubmissionSettlement(attempt, {
		recordId: eventKey,
		record: settlement
	});
	if (!obligation) {
		const row = await submissions.getSubmission(attempt.submissionId).catch(() => null);
		if (row && row.status !== "settled") {
			console.error("[flue:submission-settlement]", {
				submissionId: attempt.submissionId,
				attemptId: attempt.attemptId,
				operation: "reserve_settlement",
				outcome: "refused",
				rowStatus: row.status,
				rowAttemptId: row.attemptId
			});
			ctx.publishEvent(ctx.createEvent({
				type: "submission_recovery",
				submissionId: attempt.submissionId,
				kind,
				operation: "process_submission",
				outcome: "deferred",
				error: {
					name: "Error",
					message: "Settlement reservation refused for an unsettled submission; the settle will be retried by reconciliation."
				}
			}));
		}
		return;
	}
	const existing = await conversationWriter.getRecord(eventKey);
	if (!existing) await conversationWriter.append([obligation.record], { submission: attempt });
	else if (JSON.stringify(existing) !== JSON.stringify(obligation.record)) console.error("[flue:submission-settlement] Canonical settlement conflict; the existing durable record is authoritative.", {
		submissionId: attempt.submissionId,
		recordId: eventKey
	});
	await publishTerminalEvent();
	await submissions.finalizeSubmissionSettlement(attempt, eventKey, { ...outcome === "completed" || error === void 0 ? {} : { errorMessage: error instanceof Error ? error.message : String(error) } });
}
/**
* Finalize one reserved pending settlement during a reconcile pass: ensure
* the canonical `submission_settled` record is durable (append the retained
* record when absent; an existing record must match byte-for-byte), then
* finalize the operational row. Shared by both coordinators' reconcile
* passes; everything platform-specific — lease guards, writer acquisition,
* per-item error containment — stays at the call sites.
*
* Deliberately NOT shared with `settleSubmissionWithRecord`, whose mismatch
* policy is the opposite (log-and-proceed: at settle time the durable
* canonical record is the client-visible authority, and refusing would wedge
* reconciliation). Here a mismatch fails loud: the caller leaves the row
* pending and the next pass retries.
*
* `emitCoordinatorEvent` publishes the live `submission_settled` event for
* the recovered settlement — the process that reserved it died before its own
* publish, and this crash-window path has no submission context of its own.
* At-least-once: a finalize retried after a partial failure re-emits.
*/
async function finalizePendingSettlement(submissions, writer, pending, emitCoordinatorEvent) {
	const attempt = {
		submissionId: pending.submissionId,
		attemptId: pending.attemptId
	};
	const canonical = await writer.getRecord(pending.recordId);
	if (!canonical) await writer.append([pending.record], { submission: attempt });
	else if (JSON.stringify(canonical) !== JSON.stringify(pending.record)) throw new Error("[flue] Pending settlement does not match its canonical record. Clear incompatible beta persistence.");
	emitCoordinatorEvent?.({
		type: "submission_settled",
		submissionId: pending.submissionId,
		outcome: pending.record.outcome,
		...pending.record.outcome === "completed" || pending.record.error === void 0 ? {} : { error: pending.record.error }
	});
	await submissions.finalizeSubmissionSettlement(attempt, pending.recordId);
}
/**
* The durable-shaped, stackless error projection shared by the settlement
* record, the live `submission_settled` event, and `submission_recovery`
* payloads. Non-`FlueError` failures are replaced wholesale — internal
* messages never ride event or record error fields; the live observation's
* `errorInfo` detail carries the classified error (with throw-site stack)
* instead.
*/
function serializeSubmissionError(error) {
	if (error instanceof FlueError) return {
		name: error.name,
		message: error.message,
		type: error.type,
		details: error.details,
		...error.meta ? { meta: error.meta } : {}
	};
	return {
		name: "Error",
		message: "The agent submission failed because of an internal error.",
		type: "internal_error",
		details: "The server encountered an unexpected error while processing the agent submission. When reporting this failure, quote the settlement submissionId — server-side logs carry the same id."
	};
}
function submissionAttemptRef(submission) {
	if (!submission.attemptId) return null;
	return {
		submissionId: submission.submissionId,
		attemptId: submission.attemptId
	};
}
async function openAgentSubmissionSession(ctx, agent, input) {
	const session = await (await ctx.initializeRootHarness(agent, input.message, input.initialData)).session(SUBMISSION_SESSION_NAME);
	return getInternalSession(session) ?? session;
}
//#endregion
//#region src/runtime/conversation-stream-store.ts
const CREATE_STREAMS_TABLE = `
CREATE TABLE IF NOT EXISTS flue_conversation_streams (
  path TEXT PRIMARY KEY,
  identity_json TEXT NOT NULL,
  next_offset INTEGER NOT NULL DEFAULT 0,
  producer_id TEXT,
  producer_epoch INTEGER NOT NULL DEFAULT 0,
  next_producer_sequence INTEGER NOT NULL DEFAULT 0,
  incarnation TEXT NOT NULL
)`;
const CREATE_BATCHES_TABLE = `
CREATE TABLE IF NOT EXISTS flue_conversation_stream_batches (
  path TEXT NOT NULL,
  seq INTEGER NOT NULL,
  producer_id TEXT NOT NULL,
  producer_epoch INTEGER NOT NULL,
  producer_sequence INTEGER NOT NULL,
  data TEXT NOT NULL,
  submission_id TEXT,
  attempt_id TEXT,
  PRIMARY KEY (path, seq),
  UNIQUE (path, producer_id, producer_epoch, producer_sequence)
)`;
const CREATE_BATCH_CHUNKS_TABLE = `
CREATE TABLE IF NOT EXISTS flue_conversation_stream_batch_chunks (
  path TEXT NOT NULL,
  seq INTEGER NOT NULL,
  chunk_index INTEGER NOT NULL CHECK (chunk_index >= 0),
  chunk_count INTEGER NOT NULL CHECK (chunk_count > 0),
  data TEXT NOT NULL,
  PRIMARY KEY (path, seq, chunk_index)
)`;
/**
* Serialized batches longer than this (in UTF-16 code units) spill into
* `flue_conversation_stream_batch_chunks` instead of the batch row's `data`
* column: Cloudflare Durable Object SQLite caps an individual value at ~2MB.
*/
const CONVERSATION_BATCH_SPILL_THRESHOLD = 1048576;
/** Code units per spilled chunk row; every cell stays far under the value cap. */
const BATCH_CHUNK_LENGTH = 524288;
/**
* Split serialized data into spill-chunk parts. A boundary never splits a
* surrogate pair: serialized JSON carries astral characters unescaped, and a
* lone surrogate does not survive the backend's TEXT encoding.
*/
function splitChunks(data) {
	const parts = [];
	let start = 0;
	while (start < data.length) {
		let end = Math.min(start + BATCH_CHUNK_LENGTH, data.length);
		const last = data.charCodeAt(end - 1);
		if (end < data.length && last >= 55296 && last <= 56319) end += 1;
		parts.push(data.slice(start, end));
		start = end;
	}
	return parts;
}
/**
* Ceiling on one serialized batch, generous by an order of magnitude: a 2MB
* record already approximates 200k tokens against a 1M-token maximum context
* window, so a batch past 12MB indicates an unbounded tool result or message
* rather than real conversation data.
*/
const MAX_BATCH_DATA_LENGTH = 12582912;
function oversizedBatchReason(dataLength, records) {
	const mb = (length) => `${(length / 1048576).toFixed(1)}MB`;
	let largest = records[0];
	let largestLength = 0;
	for (const record of records) {
		const length = JSON.stringify(record).length;
		if (length > largestLength) {
			largest = record;
			largestLength = length;
		}
	}
	return `The batch serializes to ~${mb(dataLength)}, above the 12MB per-append ceiling. The largest record is a "${largest.type}" record (id "${largest.id}") at ~${mb(largestLength)}. Oversized tool results and message content must be truncated before they are recorded (built-in tools cap results at 50KB).`;
}
/**
* Shared in-memory listener registry for conversation-stream `subscribe` /
* `notify`. Every conversation store keeps a process-local fan-out of change
* listeners keyed by stream path; this class encapsulates the registration,
* unsubscribe-and-prune, and error-swallowing notify behavior so the stores do
* not each re-implement the same `Map<string, Set<() => void>>`.
*/
var StreamListenerRegistry = class {
	listeners = /* @__PURE__ */ new Map();
	subscribe(path, listener) {
		let listeners = this.listeners.get(path);
		if (!listeners) {
			listeners = /* @__PURE__ */ new Set();
			this.listeners.set(path, listeners);
		}
		listeners.add(listener);
		return () => {
			listeners?.delete(listener);
			if (listeners?.size === 0) this.listeners.delete(path);
		};
	}
	notify(path) {
		for (const listener of this.listeners.get(path) ?? []) try {
			listener();
		} catch {}
	}
};
const CREATE_FOLD_CHECKPOINTS_TABLE = `
CREATE TABLE IF NOT EXISTS flue_conversation_fold_checkpoints (
  path TEXT PRIMARY KEY,
  head_offset TEXT NOT NULL,
  incarnation TEXT NOT NULL,
  format_version INTEGER NOT NULL,
  data TEXT,
  chunk_count INTEGER
)`;
const CREATE_FOLD_CHECKPOINT_CHUNKS_TABLE = `
CREATE TABLE IF NOT EXISTS flue_conversation_fold_checkpoint_chunks (
  path TEXT NOT NULL,
  chunk_index INTEGER NOT NULL CHECK (chunk_index >= 0),
  data TEXT NOT NULL,
  PRIMARY KEY (path, chunk_index)
)`;
function ensureSqlConversationStreamTables(sql) {
	migrateFlueSqlSchema(sql, () => {
		sql.exec(CREATE_STREAMS_TABLE);
		sql.exec(CREATE_BATCHES_TABLE);
		sql.exec(CREATE_BATCH_CHUNKS_TABLE);
		sql.exec(CREATE_FOLD_CHECKPOINTS_TABLE);
		sql.exec(CREATE_FOLD_CHECKPOINT_CHUNKS_TABLE);
	});
}
var InMemoryConversationStreamStore = class {
	submissionStore;
	streams = /* @__PURE__ */ new Map();
	listeners = new StreamListenerRegistry();
	appendChain = Promise.resolve();
	/**
	* With a submission store, appends enforce the same submission fence as
	* the SQL stores (attempt ownership, the turn-boundary join allowance,
	* terminalizing settlements). Without one — the local conversation
	* runtime, which has no submission coordination — only in-record
	* ownership consistency is checked.
	*/
	constructor(submissionStore) {
		this.submissionStore = submissionStore;
	}
	async createStream(path, identity) {
		const existing = this.streams.get(path);
		if (existing) {
			if (existing.identity.agentName !== identity.agentName || existing.identity.instanceId !== identity.instanceId) this.fail("create", path, "Stream identity conflicts.");
			return;
		}
		this.streams.set(path, {
			identity: { ...identity },
			incarnation: generateIncarnationId(),
			producerId: null,
			producerEpoch: 0,
			nextProducerSequence: 0,
			batches: []
		});
	}
	async acquireProducer(path, producerId) {
		const stream = this.streams.get(path);
		if (!stream) this.fail("acquire_producer", path, "Stream does not exist.");
		stream.producerId = producerId;
		stream.producerEpoch += 1;
		stream.nextProducerSequence = 0;
		return {
			producerId,
			producerEpoch: stream.producerEpoch,
			incarnation: stream.incarnation,
			nextProducerSequence: 0,
			offset: formatOffset(stream.batches.length - 1)
		};
	}
	async append(input) {
		const result = this.appendChain.then(() => this.appendSerialized(input));
		this.appendChain = result.then(() => void 0, () => void 0);
		return result;
	}
	async appendSerialized(input) {
		if (input.records.length === 0) this.fail("append", input.path, "A canonical batch cannot be empty.");
		const data = JSON.stringify(input.records);
		const stream = this.streams.get(input.path);
		if (!stream) this.fail("append", input.path, "Stream does not exist.");
		if (stream.producerId !== input.producerId || stream.producerEpoch !== input.producerEpoch || stream.incarnation !== input.incarnation) this.fail("append", input.path, "Producer ownership is stale.");
		const retry = stream.batches.find((batch) => batch.producerId === input.producerId && batch.producerEpoch === input.producerEpoch && batch.producerSequence === input.producerSequence);
		if (retry) {
			if (retry.data !== data || retry.submissionId !== (input.submission?.submissionId ?? null) || retry.attemptId !== (input.submission?.attemptId ?? null)) this.fail("append", input.path, "Producer sequence has conflicting content.");
			return { offset: retry.offset };
		}
		if (stream.nextProducerSequence !== input.producerSequence) this.fail("append", input.path, "Producer sequence is not the next expected value.");
		await this.assertSubmissionAuthorization(input.path, input.submission, input.records);
		const offset = formatOffset(stream.batches.length);
		stream.batches.push({
			offset,
			records: JSON.parse(data),
			producerId: input.producerId,
			producerEpoch: input.producerEpoch,
			producerSequence: input.producerSequence,
			data,
			submissionId: input.submission?.submissionId ?? null,
			attemptId: input.submission?.attemptId ?? null
		});
		stream.nextProducerSequence += 1;
		this.listeners.notify(input.path);
		return { offset };
	}
	async read(path, options) {
		const stream = this.streams.get(path);
		if (!stream) return {
			batches: [],
			nextOffset: "-1",
			upToDate: true
		};
		const head = stream.batches.length - 1;
		const rawOffset = options?.offset ?? "-1";
		if (rawOffset === "now") return {
			batches: [],
			nextOffset: formatOffset(head),
			upToDate: true
		};
		const startAfter = parseOffset(rawOffset);
		if (!Number.isSafeInteger(startAfter) || startAfter > head) this.fail("read", path, "Read offset is beyond the canonical stream head.");
		const limit = clampLimit(options?.limit, 100, MAX_READ_LIMIT);
		const page = stream.batches.slice(startAfter + 1, startAfter + 1 + limit);
		return {
			batches: page.map((batch) => ({
				offset: batch.offset,
				records: JSON.parse(batch.data)
			})),
			nextOffset: page.at(-1)?.offset ?? formatOffset(startAfter),
			upToDate: startAfter + page.length >= head
		};
	}
	async getMeta(path) {
		const stream = this.streams.get(path);
		if (!stream) return null;
		return {
			identity: { ...stream.identity },
			incarnation: stream.incarnation,
			nextOffset: formatOffset(stream.batches.length - 1),
			producerId: stream.producerId,
			producerEpoch: stream.producerEpoch,
			nextProducerSequence: stream.nextProducerSequence
		};
	}
	subscribe(path, listener) {
		return this.listeners.subscribe(path, listener);
	}
	foldCheckpoints = /* @__PURE__ */ new Map();
	async putFoldCheckpoint(path, checkpoint) {
		this.foldCheckpoints.set(path, { ...checkpoint });
	}
	async getFoldCheckpoint(path, options) {
		const checkpoint = this.foldCheckpoints.get(path);
		if (!checkpoint) return null;
		if (options?.atOrBefore !== void 0 && parseOffset(checkpoint.offset) > parseOffset(options.atOrBefore)) return null;
		return { ...checkpoint };
	}
	async assertSubmissionAuthorization(path, submission, records) {
		const owned = records.filter((record) => record.submissionId !== void 0 || record.attemptId !== void 0);
		if (!submission) {
			if (owned.length > 0) this.fail("append", path, "Submission-owned records require an attempt authorization.");
			return;
		}
		for (const record of owned) {
			if (record.submissionId === submission.submissionId && record.attemptId === submission.attemptId) continue;
			if (this.submissionStore && record.attemptId === submission.attemptId && record.submissionId !== void 0) {
				const delivery = await this.submissionStore.getSubmission(record.submissionId);
				if ((delivery?.status === "joining" || delivery?.status === "joined") && delivery.joinedInto === submission.submissionId) continue;
			}
			this.fail("append", path, "Record ownership does not match the authorized submission attempt.");
		}
		if (!this.submissionStore) return;
		const row = await this.submissionStore.getSubmission(submission.submissionId);
		const sessionIdentity = row ? parseSessionStorageKey(row.sessionKey) : void 0;
		const streamIdentity = this.streams.get(path)?.identity;
		const obligation = (await this.submissionStore.listPendingSubmissionSettlements()).find((pending) => pending.submissionId === submission.submissionId);
		const terminalizingSettlement = row?.status === "terminalizing" && records.length === 1 && owned.length === 1 && owned[0]?.type === "submission_settled" && obligation?.recordId === owned[0].id && JSON.stringify(obligation.record) === JSON.stringify(owned[0]);
		if (!row || row.status !== "running" && !terminalizingSettlement || row.attemptId !== submission.attemptId || !sessionIdentity || !streamIdentity || sessionIdentity.agentName !== streamIdentity.agentName || sessionIdentity.instanceId !== streamIdentity.instanceId) this.fail("append", path, "Submission attempt no longer owns work for this agent instance.");
	}
	fail(operation, path, reason) {
		throw new ConversationStreamStoreError({
			operation,
			path,
			reason
		});
	}
};
var SqliteConversationStreamStore = class {
	sql;
	runTransaction;
	listeners = new StreamListenerRegistry();
	constructor(sql, runTransaction) {
		this.sql = sql;
		this.runTransaction = runTransaction;
		ensureSqlConversationStreamTables(sql);
	}
	async createStream(path, identity) {
		const data = JSON.stringify(identity);
		this.runTransaction(() => {
			const existing = this.sql.exec("SELECT identity_json FROM flue_conversation_streams WHERE path = ?", path).toArray()[0];
			if (existing) {
				if (existing.identity_json !== data) this.fail("create", path, "Stream identity conflicts.");
				return;
			}
			this.sql.exec("INSERT INTO flue_conversation_streams (path, identity_json, incarnation) VALUES (?, ?, ?)", path, data, generateIncarnationId());
		});
	}
	async acquireProducer(path, producerId) {
		return this.runTransaction(() => {
			const row = this.sql.exec(`UPDATE flue_conversation_streams
					 SET producer_id = ?, producer_epoch = producer_epoch + 1, next_producer_sequence = 0
					 WHERE path = ?
					 RETURNING producer_epoch, next_offset, incarnation`, producerId, path).toArray()[0];
			if (!row) this.fail("acquire_producer", path, "Stream does not exist.");
			return {
				producerId,
				producerEpoch: row.producer_epoch,
				incarnation: row.incarnation,
				nextProducerSequence: 0,
				offset: formatOffset(row.next_offset - 1)
			};
		});
	}
	async append(input) {
		if (input.records.length === 0) this.fail("append", input.path, "A canonical batch cannot be empty.");
		const data = JSON.stringify(input.records);
		if (data.length > MAX_BATCH_DATA_LENGTH) this.fail("append", input.path, oversizedBatchReason(data.length, input.records));
		const result = this.runTransaction(() => {
			const meta = this.sql.exec(`SELECT next_offset, producer_id, producer_epoch, next_producer_sequence, incarnation
					 FROM flue_conversation_streams WHERE path = ?`, input.path).toArray()[0];
			if (!meta) this.fail("append", input.path, "Stream does not exist.");
			if (meta.producer_id !== input.producerId || meta.producer_epoch !== input.producerEpoch || meta.incarnation !== input.incarnation) this.fail("append", input.path, "Producer ownership is stale.");
			const retry = this.sql.exec(`SELECT seq, data, submission_id, attempt_id FROM flue_conversation_stream_batches
					 WHERE path = ? AND producer_id = ? AND producer_epoch = ? AND producer_sequence = ?`, input.path, input.producerId, input.producerEpoch, input.producerSequence).toArray()[0];
			if (retry) {
				if (this.materializeBatchData("append", input.path, retry.seq, retry.data) !== data || retry.submission_id !== (input.submission?.submissionId ?? null) || retry.attempt_id !== (input.submission?.attemptId ?? null)) this.fail("append", input.path, "Producer sequence has conflicting content.");
				return {
					offset: formatOffset(retry.seq),
					appended: false
				};
			}
			if (meta.next_producer_sequence !== input.producerSequence) this.fail("append", input.path, "Producer sequence is not the next expected value.");
			this.assertSubmissionAuthorization(input.path, input.submission, input.records);
			const seq = meta.next_offset;
			const stored = data.length > 1048576 ? this.spillBatchData(input.path, seq, data) : data;
			this.sql.exec(`INSERT INTO flue_conversation_stream_batches
				 (path, seq, producer_id, producer_epoch, producer_sequence, data, submission_id, attempt_id)
				 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, input.path, seq, input.producerId, input.producerEpoch, input.producerSequence, stored, input.submission?.submissionId ?? null, input.submission?.attemptId ?? null);
			this.sql.exec(`UPDATE flue_conversation_streams
				 SET next_offset = next_offset + 1, next_producer_sequence = next_producer_sequence + 1
				 WHERE path = ?`, input.path);
			return {
				offset: formatOffset(seq),
				appended: true
			};
		});
		if (result.appended) this.listeners.notify(input.path);
		return { offset: result.offset };
	}
	async read(path, options) {
		const meta = await this.getMeta(path);
		if (!meta) return {
			batches: [],
			nextOffset: "-1",
			upToDate: true
		};
		const rawOffset = options?.offset ?? "-1";
		if (rawOffset === "now") return {
			batches: [],
			nextOffset: meta.nextOffset,
			upToDate: true
		};
		const startAfter = parseOffset(rawOffset);
		const head = parseOffset(meta.nextOffset);
		if (!Number.isSafeInteger(startAfter) || startAfter > head) this.fail("read", path, "Read offset is beyond the canonical stream head.");
		const limit = clampLimit(options?.limit, 100, MAX_READ_LIMIT);
		const rows = this.sql.exec(`SELECT seq, data FROM flue_conversation_stream_batches
				 WHERE path = ? AND seq > ? ORDER BY seq ASC LIMIT ?`, path, startAfter, limit + 1).toArray();
		const batches = rows.slice(0, limit).map((row) => ({
			offset: formatOffset(row.seq),
			records: JSON.parse(this.materializeBatchData("read", path, row.seq, row.data))
		}));
		return {
			batches,
			nextOffset: batches.at(-1)?.offset ?? formatOffset(startAfter),
			upToDate: rows.length <= limit
		};
	}
	/**
	* Writes `data` as chunk rows keyed by `(path, seq)` and returns the spill
	* sentinel to store in the batch row's `data` column.
	*/
	spillBatchData(path, seq, data) {
		const parts = splitChunks(data);
		for (const [index, part] of parts.entries()) this.sql.exec(`INSERT INTO flue_conversation_stream_batch_chunks
				 (path, seq, chunk_index, chunk_count, data) VALUES (?, ?, ?, ?, ?)`, path, seq, index, parts.length, part);
		return JSON.stringify({ $flueChunkCount: parts.length });
	}
	/**
	* Returns the full serialized batch for a stored `data` value. A spilled
	* batch row stores the sentinel `{"$flueChunkCount":N}` instead of the
	* serialized records; the two shapes cannot collide because real batch
	* data is `JSON.stringify` of a records array and always starts with `[`,
	* so a stored value starting with `{` is always the sentinel.
	*/
	materializeBatchData(operation, path, seq, stored) {
		if (!stored.startsWith("{")) return stored;
		const chunkCount = JSON.parse(stored).$flueChunkCount;
		if (typeof chunkCount !== "number" || !Number.isSafeInteger(chunkCount) || chunkCount <= 0) this.fail(operation, path, "Spilled batch sentinel is malformed.");
		const rows = this.sql.exec(`SELECT chunk_index, chunk_count, data FROM flue_conversation_stream_batch_chunks
				 WHERE path = ? AND seq = ? ORDER BY chunk_index`, path, seq).toArray();
		if (rows.length !== chunkCount) this.fail(operation, path, "Spilled batch chunk rows do not match the recorded count.");
		const parts = [];
		for (const [index, row] of rows.entries()) {
			if (row.chunk_index !== index || row.chunk_count !== chunkCount) this.fail(operation, path, "Spilled batch chunk rows are not contiguous.");
			parts.push(row.data);
		}
		return parts.join("");
	}
	async getMeta(path) {
		const row = this.sql.exec(`SELECT identity_json, next_offset, producer_id, producer_epoch, next_producer_sequence, incarnation
				 FROM flue_conversation_streams WHERE path = ?`, path).toArray()[0];
		if (!row) return null;
		return {
			identity: JSON.parse(row.identity_json),
			incarnation: row.incarnation,
			nextOffset: formatOffset(row.next_offset - 1),
			producerId: row.producer_id ?? null,
			producerEpoch: row.producer_epoch,
			nextProducerSequence: row.next_producer_sequence
		};
	}
	subscribe(path, listener) {
		return this.listeners.subscribe(path, listener);
	}
	async putFoldCheckpoint(path, checkpoint) {
		this.runTransaction(() => {
			this.sql.exec("DELETE FROM flue_conversation_fold_checkpoint_chunks WHERE path = ?", path);
			const spill = checkpoint.data.length > CONVERSATION_BATCH_SPILL_THRESHOLD;
			let chunkCount = null;
			if (spill) {
				const parts = splitChunks(checkpoint.data);
				for (const [index, part] of parts.entries()) this.sql.exec(`INSERT INTO flue_conversation_fold_checkpoint_chunks (path, chunk_index, data)
						 VALUES (?, ?, ?)`, path, index, part);
				chunkCount = parts.length;
			}
			this.sql.exec(`INSERT INTO flue_conversation_fold_checkpoints
				 (path, head_offset, incarnation, format_version, data, chunk_count)
				 VALUES (?, ?, ?, ?, ?, ?)
				 ON CONFLICT(path) DO UPDATE SET
				   head_offset = excluded.head_offset,
				   incarnation = excluded.incarnation,
				   format_version = excluded.format_version,
				   data = excluded.data,
				   chunk_count = excluded.chunk_count`, path, checkpoint.offset, checkpoint.incarnation, checkpoint.formatVersion, spill ? null : checkpoint.data, chunkCount);
		});
	}
	async getFoldCheckpoint(path, options) {
		return this.runTransaction(() => {
			const row = this.sql.exec(`SELECT head_offset, incarnation, format_version, data, chunk_count
					 FROM flue_conversation_fold_checkpoints WHERE path = ?`, path).toArray()[0];
			if (!row) return null;
			if (options?.atOrBefore !== void 0 && parseOffset(row.head_offset) > parseOffset(options.atOrBefore)) return null;
			let data = row.data;
			if (data === null) {
				const chunkCount = row.chunk_count;
				if (chunkCount === null || chunkCount <= 0) this.fail("get_fold_checkpoint", path, "Checkpoint row has neither data nor chunks.");
				const chunks = this.sql.exec(`SELECT chunk_index, data FROM flue_conversation_fold_checkpoint_chunks
						 WHERE path = ? ORDER BY chunk_index`, path).toArray();
				if (chunks.length !== chunkCount) this.fail("get_fold_checkpoint", path, "Checkpoint chunk rows do not match the recorded count.");
				const parts = [];
				for (const [index, chunk] of chunks.entries()) {
					if (chunk.chunk_index !== index) this.fail("get_fold_checkpoint", path, "Checkpoint chunk rows are not contiguous.");
					parts.push(chunk.data);
				}
				data = parts.join("");
			}
			return {
				offset: row.head_offset,
				incarnation: row.incarnation,
				formatVersion: row.format_version,
				data
			};
		});
	}
	assertSubmissionAuthorization(path, submission, records) {
		const submissionRecords = records.filter((record) => record.submissionId !== void 0 || record.attemptId !== void 0);
		if (!submission) {
			if (submissionRecords.length > 0) this.fail("append", path, "Submission-owned records require an attempt authorization.");
			return;
		}
		for (const record of submissionRecords) {
			if (record.submissionId === submission.submissionId && record.attemptId === submission.attemptId) continue;
			if (record.attemptId === submission.attemptId && record.submissionId !== void 0) {
				const delivery = this.sql.exec("SELECT status, joined_into FROM flue_agent_submissions WHERE submission_id = ?", record.submissionId).toArray()[0];
				if ((delivery?.status === "joining" || delivery?.status === "joined") && delivery.joined_into === submission.submissionId) continue;
			}
			this.fail("append", path, "Record ownership does not match the authorized submission attempt.");
		}
		const row = this.sql.exec(`SELECT status, attempt_id, session_key, settlement_record_id, settlement_record
				 FROM flue_agent_submissions WHERE submission_id = ?`, submission.submissionId).toArray()[0];
		const sessionIdentity = typeof row?.session_key === "string" ? parseSessionStorageKey(row.session_key) : void 0;
		const streamIdentityRow = this.sql.exec("SELECT identity_json FROM flue_conversation_streams WHERE path = ?", path).toArray()[0];
		const streamIdentity = streamIdentityRow ? JSON.parse(streamIdentityRow.identity_json) : void 0;
		const terminalizingSettlement = row?.status === "terminalizing" && records.length === 1 && submissionRecords.length === 1 && submissionRecords[0]?.type === "submission_settled" && row.settlement_record_id === submissionRecords[0].id && row.settlement_record === JSON.stringify(submissionRecords[0]);
		if (!row || row.status !== "running" && !terminalizingSettlement || row.attempt_id !== submission.attemptId || !sessionIdentity || !streamIdentity || sessionIdentity.agentName !== streamIdentity.agentName || sessionIdentity.instanceId !== streamIdentity.instanceId) this.fail("append", path, "Submission attempt no longer owns work for this agent instance.");
	}
	fail(operation, path, reason) {
		throw new ConversationStreamStoreError({
			operation,
			path,
			reason
		});
	}
};
//#endregion
export { isSubmissionPayload as A, renderAgentFunctionWithStructure as C, SUBMISSION_SESSION_NAME as D, SUBMISSION_HARNESS_NAME as E, sameSubmissionChunks as F, DURABILITY_DEFAULT_MAX_ATTEMPTS as I, DURABILITY_DEFAULT_TIMEOUT_MS as L, hydratePersistedSubmissionAttachments as M, matchesPersistedSubmissionAttachments as N, admitSubmissionWithBackend as O, prepareSubmissionAttachments as P, LEASE_DURATION_MS as R, assertRenderStructureInvariance as S, skillCatalogEntries as T, submissionSyntheticRequest as _, admitInstanceContact as a, createPublicSession as b, createDispatchAgentSubmissionInput as c, isInstanceContactRejection as d, materializeSubmissionAttachments as f, settleUnclaimableSubmission as g, serializeSubmissionError as h, ensureSqlConversationStreamTables as i, parseAcceptedAt as j, clampLimit as k, ensureInstanceIdentity as l, reconcileInterruptedSubmission as m, SqliteConversationStreamStore as n, adoptKeyedSubmissionReplay as o, processSubmission as p, StreamListenerRegistry as r, createDirectAgentSubmissionInput as s, InMemoryConversationStreamStore as t, finalizePendingSettlement as u, unreadySubmissionDeadline as v, discoverSessionContext as w, digestInstructions as x, Session as y };
