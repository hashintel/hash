# TEST synthetic transport attempts

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21PSQWTA6E1QCGTNWMQH7MG, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21PSR6GZMD3ZPEEXYP1YZ6B, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21PSRB3NM3SD6B48RDC2HSB, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.
