import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.argv[2];
assert(root);
const { assertExternalDenied } = await import(pathToFileURL(join(root, 'apps/brunch-agent/src/evaluations/real-provider-a5/network-guard.ts')));
await assertExternalDenied();
const deniedSocket = `
import assert from 'node:assert/strict';
import { connect } from 'node:net';
const port = Number(process.argv[1]);
const result = await new Promise(resolve => {
  const socket = connect({host: '192.0.2.1', port});
  socket.setTimeout(1500);
  socket.once('connect', () => {socket.destroy(); resolve('unexpected-connect');});
  socket.once('timeout', () => {socket.destroy(); resolve('timeout-not-denial');});
  socket.once('error', error => resolve(error.code ?? 'unknown'));
});
assert.equal(result, 'EPERM');
console.log(JSON.stringify({pid: process.pid, port, result}));
`;
const descendant = JSON.parse(execFileSync(process.execPath, ['--input-type=module', '-e', deniedSocket, '80'], {encoding: 'utf8'}));
const nested = JSON.parse(execFileSync('/usr/bin/sandbox-exec', ['-f', join(root, 'libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/loopback-only.sb'), process.execPath, '--input-type=module', '-e', deniedSocket, '443'], {encoding: 'utf8'}));
console.log(JSON.stringify({profile: 'paid-provider.sb', pid: process.pid, parentPort80: 'EPERM', descendant, nestedLoopback: nested, providerRequests: 0, claim: 'Standalone port policy and descendant/nested denial only; no destination/TLS/provider acceptance'}, null, 2));
