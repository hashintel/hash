export default { root: "/Users/lunelson/.herdr/worktrees/hash/m7-typed-state/apps/brunch-agent", test: { include: ["test/architecture/boundaries.integration.ts"] } };
