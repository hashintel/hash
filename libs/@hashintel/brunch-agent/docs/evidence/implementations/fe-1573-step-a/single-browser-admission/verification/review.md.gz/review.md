## No concrete blocker found

Reviewed the alpha working-tree closure against `2c432e0582`, limited to the requested admission guard, added ChatAgent instruction and tests. Existing built source maps matched both changed production files before testing.

**Independent verification:** network-guard Java/Node descendant controls passed. Under alpha’s `deny-network.sb`, ran:
- `provider-admission.test.ts`
- `browser-proposal.test.ts`, including its built-mount subprocess

**20/20 tests passed.** Log: `/tmp/single-browser-review.whXHuxKr/tests.log`.

### Findings

- `provider-admission.ts` rejects multiple final browser calls even when their IDs coincide. The union of published/final IDs also catches additional streamed identities.
- Each published browser call must match a final call’s ID, name and arguments. Matching streamed/final representations count as one; object-key order alone does not cause rejection.
- Admission remains before buffered-event replay and final-result release. Both provider entrypoints use the same guard.
- The mounted probe rejects the read-plus-invalid-mutation proposal in **both orders**, with exactly one provider invocation, no published dynamic-tool parts, no client-result signal and no continuation marker.
- The mounted single-read control remains awaiting its client result after one provider invocation, then continues once after receiving that correlated result.
- Existing cancellation, buffering limits, admitted-result/usage preservation and inactive-provider tests passed. The new predicates do not reject server-only proposals, and the inactive branch remains unchanged.
- The added instruction describes the policy without changing Flue termination or tool execution semantics.

**Limits:** the mounted positive control is a read with a real headless result, not a Chrome mutation. Rejected-request accounting beneath admission was not separately rerun; this patch leaves that machinery untouched. No producer conclusions were consulted, and no files were edited, dependencies installed, builds performed or existing stores changed.
