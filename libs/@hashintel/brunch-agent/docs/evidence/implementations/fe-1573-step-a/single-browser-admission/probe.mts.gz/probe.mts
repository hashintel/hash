import {mkdtempSync,writeFileSync} from "node:fs";
import {join} from "node:path";
import {fauxProvider,fauxAssistantMessage,fauxToolCall,fauxText} from "@earendil-works/pi-ai";
import {createFlueClient} from "@flue/sdk";
import {agentOwnershipHeaders,flueConversationIdFrom} from "../src/conversation/identity.ts";
import {installFauxProvider} from "../src/evaluations/install-faux-provider.ts";
import {loadBuiltBrunchApplication} from "../src/evaluations/runbook/load-built-application.ts";
const out=process.env.RUN_DIR!;
process.env.NODE_ENV="test";process.env.HASH_OTLP_ENDPOINT="";process.env.BRUNCH_CHAT_MODEL="claude-sonnet-4-6";
process.env.BRUNCH_DEV_DB_PATH=join(out,"conversation.db");
globalThis.fetch=()=>{throw Error("External fetch forbidden")};
const faux=fauxProvider({provider:"anthropic",models:[{id:"claude-sonnet-4-6"}]});
installFauxProvider(faux.provider);
faux.setResponses([
 fauxAssistantMessage([fauxToolCall("getLatestNetDefinition",{},{id:"pending-read"}),fauxToolCall("addType",{id:"invalid-type"},{id:"invalid-mutation"})],{stopReason:"toolUse"}),
 fauxAssistantMessage([fauxText("CONTINUED_WITHOUT_CLIENT_RESULT")])
]);
const app=await loadBuiltBrunchApplication();
const identity={principalKey:"TEST-multi-browser",conversationId:"TEST-multi-browser"};
const client=createFlueClient({url:`http://brunch.local/agents/chat/${flueConversationIdFrom(identity)}`,headers:agentOwnershipHeaders(identity),fetch:(input,init)=>app.fetch(input instanceof Request?input:new Request(input,init))});
try {
 let failure;
 try { await client.wait(await client.send({initialData:{mode:"validated-construction"},message:{kind:"user",body:"TEST mixed-validity browser-only proposal; no client result will be sent."}})); }catch(error){failure=String(error)}
 const history=await client.history();
 const report={providerCalls:faux.state.callCount,failure,tools:history.messages.flatMap(message=>message.parts).filter(part=>part.type==="dynamic-tool"),clientResultSignals:history.messages.filter(message=>message.signal?.tagName==="client-tool-result").length,continued:JSON.stringify(history).includes("CONTINUED_WITHOUT_CLIENT_RESULT")};
 writeFileSync(join(out,"report.json"),JSON.stringify(report,null,2));writeFileSync(join(out,"history.json"),JSON.stringify(history,null,2));console.log(JSON.stringify(report,null,2));
}finally{await app.stop()}
