# Independent full root-node construction checkpoint review

## Verdict and scope

**No confirmed reachable safety blocker found in the reviewed root-node checkpoint.** The new actual ChatAgent/Chrome path, raw capacity reopening, offline record audit and callback-assertion falsifier passed their respective positive/negative discriminators. This is a bounded synthetic mechanical checkpoint, not construction-lane closure, full class-stratum coverage, semantic usefulness, genuine/provider admission, paid authorization or mission/Step B acceptance.

Reviewed the actual target `/Users/lunelson/.herdr/worktrees/hash/m7-root-creation`, fixed HEAD `5ebe50c8adc8d716b4a3a20ac8f309d1ba979789`, base `3f86c1461c`. The worktree started and ended clean at that HEAD. Read target root/app/Brunch AGENTS, ALPHA's current MISSION protected construction/capacity/evidence/admission semantics, and the post-capacity handoff/class table. This is a review of the new node/schema/effect/why/host implementation, not a restatement of earlier capacity or arc reviews.

No tracked edits, installs, rebuilds, provider/DNS calls, live-ledger access, paid-profile commands or history restoration. Only fresh owned `/tmp/m7-root-review.QJJken` outputs were written. A delegated reader failed to locate the implementation because it guessed wrong paths; no source-review credit or findings are taken from it. The findings below come from direct parent inspection of the correct paths and independent runs.

## Independently observed results

| Check | Result and retained output |
| --- | --- |
| Process-tree guard | Existing shell → Java/Node verifier passed external EPERM for deny/commit/loopback profiles; loopback allowed only in browser profile. `guard.log`, exit 0. |
| Source/build/runtime pins | **1,254 SHA-256 entries checked**, no missing files or mismatches, against the post-capacity source/build manifest. `pin-verification.json`. No ledger/paid/activation file was read by this verification. |
| Packaged evidence pins | **178 artifact hashes checked**, no mismatch. `artifact-pin-check.json`. Evidence pins are provenance checks, not substitutes for replay. |
| Primary actual Chrome | Run once under loopback-only, exit 0. **50 synthetic requests / 36 completed callbacks / seven applied records**, plus no-op/stale controls. `primary/summary.json`, `primary.log`. No page/server/blocked-origin/callback errors. |
| Unchanged capacity diagnostic | Exit 0 on this new run's actual records. `direct.json`, empty `direct.stderr`. Script retains its original required capacity assertion. |
| New offline audit | Exit 0, **nine records: seven applied, one no-op, one stale; 27 created, two updated, zero deleted/derived entries**. Earlier verified read/base and binding checks pass; full direct/reopen definitions match. `audit.json`, empty `audit.stderr`. |
| Independent effect reconstruction | Separately recomputed every actual pre/post raw hash, rejected duplicate/overlapping effect pointers and applied all reported primary/derived effects to each pre-state; reconstructed the entire post-state for all nine records. `independent-effects.json`. This does not rely solely on the producer's effect derivation helper. |
| Required assertion falsifier | Same frozen primary with `M7_FALSIFY_EMPTY_ASSERTION=1`, separate fresh output: **exit 1**. `falsifier.log`, `falsifier/callback-errors.json` retain `Real first read must be empty: 0 !== 1`, surfaced by the outer `Callback assertions must reach the outer oracle` assertion. |
| Plugin focused units | **21 passed / three files**: root-node, native-input, transition-record. `plugin-tests.log`. |
| App focused units | **31 passed / two files**: reconciliation, provider-admission. `app-tests.log`. |
| Host focused units | **20 passed / two files**: transition recorder and route selection. `host-tests.log`. |

All unit/offline probes used deny-network. The only two Chrome runs were the requested successful primary and explicit required-assertion falsifier, both loopback-only. No broad reported portfolio or legacy browser rerun is claimed as independently executed here.

## Data/control and contract findings

### Bound empty entry, schemas and admission

`apps/petrinaut-website/src/main/app/local-storage-demo/local-storage-demo-app.tsx:352-386` selects a separately identified root-creation route and uses the canonical empty SDCPN, with no prepared workpiece. Conversation/document incarnation identities stay separate from both prepared root arc and previous construction substrate. Existing first-user initialData/ownership wiring remains in use; the primary asserts zero earlier deliveries and the exact initialData. Its first actual user body is TEST operational prose, not the scripted assistant Markdown or net. The first verified browser read observes zero places/transitions.

`packages/plugin-sdcpn/src/root-node.ts:60-85` composes canonical Zod schemas with only the existing Brunch basis/read envelope and root restriction; explicit `.meta(...)` preserves native root metadata. Four node native schema exports are compared to their canonical owner in units and through actual serialized requests in the primary. No copied canonical field schema or converter was added. `flue.ts:110-127` mounts the explicit candidate catalogue and teaches unavailable classes, derived-effect limits and one-browser sequencing. `tools/petrinaut-construction.ts:74-109` validates settled revision/basis, verified earlier read and exact hash before returning awaiting-client. Compilation is a canonical client read, not mutation/provenance or behavioral proof.

The existing app registration consumes the shared plugin browser catalogue. Actual node+revision and read+node proposals each fail before any sibling dynamic-tool publication and without continuation. No admission algorithm/accounting/core-runtime modification is hidden in this slice.

### Identity and execution boundary

`apps/brunch-agent/src/conversation/root-arc.ts:135-208` gathers retained verified full reads/records within the bound conversation before `assertNodeIdentity`; unknown construction history refuses. `root-node.ts:89-147` rejects current duplicate/cross-class IDs, known-retired creation, unknown/ambiguous update targets, and unavailable embedded component-port/ambiguous endpoints. Actual duplicate, unknown read and known-retired controls produce no browser outcome; the retired case uses real UI deletion followed by a fresh full read.

`apps/petrinaut-website/.../transition-record.ts` retains per-call request/output identity. It rechecks the exact live raw base synchronously, refuses disabled-extension node observation, checks current identity and canonical feasibility before the actual callback, and observes the real handle immediately afterward. Detached expected action execution is **not** used as a fake browser result. The real post observation is independently required to match it before applied can be claimed. Duplicate delivery replay uses the original idempotency key and does not recontinue; foreign/conflicting result controls fail typed submissions without new requests. Stale UI capacity 4/request 5 leaves the field at 4 and renders Not applied with the actual base-mismatch reason.

Known-retired is specifically a known-history refusal, not a general epoch/deletion implementation. Recorded removals remain unavailable. Unprobed cross-turn collision or lifecycle variants are not promoted to P1s.

### Complete effects, expected action and array identity

`packages/plugin-sdcpn/src/transition-record.ts:182-228` runs the canonical owning action against a structured clone for expected-node verification, with the candidate's all-enabled/no-global-stripping semantics. `:231-308` derives changes from actual full pre/post definitions and partitions creation fields, rather than overlapping an entity-parent effect with generated children. Only an explicitly supplied field whose actual value agrees with that input earns direct classification; other changes remain derived. `:350-360` requires complete actual-post versus expected-action content equality for node applied status. Failed/no-op/stale/unknown attempts are not successful causes.

The actual path has **zero derived changes**, so no browser-generated-kernel/sanitization success is earned. Existing node units execute canonical detached generation/sanitization cases, classify derived fields and reject a tampered generated post. The source why refusal for derived fields is inspected, not represented as a new real-browser derived-field witness.

The effect pointers are snapshot-relative; `apps/brunch-agent/src/conversation/why.ts:433-486` relocates targets by stable ID within each relevant full snapshot instead of recycling the current array index. Creation and update operations in this witness append or modify stable nodes; external deletion/content gaps cause conservative refusal. This is not proof of recorded deletion/index-shift/epoch breadth.

### Why and reopened scope

`why.ts` verifies correlated records and full-history continuity before attribution, separates attempt history from applied changes, finds entity origin from absent-pre/present-post, and chooses the latest relevant field change. Derived/unmapped governing effects refuse basis inheritance. Returned prose remains untrusted, partially-supported operation-level/revision-local linkage; source relevance, template completeness and utility remain unassessed.

The actual reopened capacity query retains origin `creation-queue`, field change `creation-capacity`, revision two, and excludes `creation-no-op` from applied changes while retaining it as an attempt. The code query retains origin `creation-step` and field correction `creation-pause`. Raw capacity 3/null and complete predicate code survive. Full definitions match only modulo object-key order; distinct raw hashes remain explicit and no mutation uses equivalence in place of exact base equality.

Crucially, `primary/reopened-why.json` and the outside assertions require **first observationScope = live-observed, second = as-of**. Both use serialization-equivalent reconciliation in this run; that status is not confused with live scope. The first consumes the active browser-result delivery; the subsequent server turn reuses an older read and is correctly as-of. The independent artifact check separately asserts these exact ordered scopes. No “either label passes” oracle was accepted.

Screenshots `primary/reopened-why.png` and `primary/stale.png` were inspected: capacity 3 after reload, then actual 4 alongside a neutral Not applied card after the stale request. The existing workpiece/panel overlap is visible and not a new usefulness claim. Compilation was checked before the later false-predicate correction; neither the successful compilation string nor the schema counts establish behavioral correctness or the corrected net's final diagnostic/utility state.

## Oracle integrity and retained diagnostics

All test response callbacks are wrapped by `checked`: assertions complete before the callback count increments; failures are saved and rethrown. `send` asserts `callbackErrors` in its outer finally block. The final outside total requires 36 callbacks, and record/schema/reopen/scope/result-rejection checks also execute outside faux callbacks. The actual falsifier proved the required empty-read assertion reaches a nonzero process despite faux/native error-message conversion. No falsified success response or edited source was used.

`primary.log` retains expected admission/foreign/conflict failure stack traces and the SQLite experimental warning. Positive output exits 0 with empty error arrays. The falsifier's failure is explicitly negative proof, never counted as positive creation success. The historical unchanged capacity diagnostic still prints an old “Diagnostic reproduction of loss” label; its unchanged required assertion and the separate full-content audit, not that stale string, establish the new result.

## Remaining contract stratum and limits

This review supports the narrow new root-place/transition creation/correction path on the real entrypoint, not completion of the root construction lane. Remaining obligations include recorded deletions/retirement, additional arc connectivity/type operations, types/elements and scenario migration, scenarios, parameters when used, actual colored/generated/sanitized browser footprints, broader failed/unknown and identity lifecycle cases, and useful entity/field coverage. No new provider/genuine class admission or accepted-region meaning follows from 9 records or 29 diff entries.

Legacy arc schemas and prepared mode branches remain readable and the focused regression tests pass. The changed construction-only duplicate-arc guard now refuses an already-present endpoint rather than admitting a redundant add. Legacy prepared mount/input behavior is not silently replaced. Existing source/citation/core locator/runtime/admission/accounting and Voice paths are inspected as protected/unchanged seams; their complete browser/retention/paid portfolios were not rerun. True process restart, compaction and arbitrary concurrency remain outside this review. The parent's existing legacy browser evidence remains prior evidence, not an independently replayed result here.

## Commands

All commands below ran in the target root worktree, never the older review cwd. Exit codes were saved to matching `.exit` files.

```sh
R=/Users/lunelson/.herdr/worktrees/hash/m7-root-creation
O=/tmp/m7-root-review.QJJken
cd "$R"
git status --short
git rev-parse HEAD
git diff 3f86c1461c HEAD -- apps libs/@hashintel/brunch-agent/packages > "$O/code.diff"
git diff --word-diff=plain 3f86c1461c HEAD -- apps libs/@hashintel/brunch-agent/packages > "$O/semantic.diff"
E=libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery
node "$E/verify-network-guard.mjs" > "$O/guard.log" 2>&1

cd "$R/apps/brunch-agent"
M7_ROOT_CREATION_OUTPUT="$O/primary" sandbox-exec -f "../../$E/loopback-only.sb" node --experimental-strip-types test/root-creation.integration.ts > "$O/primary.log" 2>&1
M7_ROOT_CREATION_OUTPUT="$O/falsifier" M7_FALSIFY_EMPTY_ASSERTION=1 sandbox-exec -f "../../$E/loopback-only.sb" node --experimental-strip-types test/root-creation.integration.ts > "$O/falsifier.log" 2>&1
sandbox-exec -f "../../$E/deny-network.sb" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts test/reconciliation.test.ts test/provider-admission.test.ts > "$O/app-tests.log" 2>&1

cd "$R"
sandbox-exec -f "$E/deny-network.sb" node libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/root-creation-checkpoint/capacity-reopen.mjs "$O/primary/records.json" > "$O/direct.json" 2> "$O/direct.stderr"
sandbox-exec -f "$E/deny-network.sb" node libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/root-creation-post-capacity/audit.mjs "$O/primary" "$O/direct.json" > "$O/audit.json" 2> "$O/audit.stderr"

cd "$R/libs/@hashintel/brunch-agent/packages/plugin-sdcpn"
sandbox-exec -f ../../docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../../../node_modules/vitest/vitest.mjs run test/root-node.test.ts test/native-input.test.ts test/transition-record.test.ts > "$O/plugin-tests.log" 2>&1

cd "$R/apps/petrinaut-website"
sandbox-exec -f "../../$E/deny-network.sb" node ../../node_modules/vitest/vitest.mjs run src/main/app/local-storage-demo/transition-record.test.ts src/main/app/local-storage-demo/local-storage-demo-search.test.ts > "$O/host-tests.log" 2>&1
```

Additional read-only Python inspections recursively checked manifest file hashes, checked 178 packaged artifact hashes, and independently reconstructed complete actual posts from disjoint effect pointers and raw-hash-verified observations. Results are `pin-verification.json`, `artifact-pin-check.json`, `independent-effects.json`. `wiring.diff` retains the focused host/tool/ChatAgent exact diff; `manifest-summary.txt` records protected-object declarations for context. No provenance declaration alone was treated as a production pass.
