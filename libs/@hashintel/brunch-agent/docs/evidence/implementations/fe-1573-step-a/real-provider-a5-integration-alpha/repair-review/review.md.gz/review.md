# Focused ALPHA repair-catalogue review

## Result

**Accept this bounded guard closure; no concrete issue found in the three-file integration delta.** The actual driver now calls the zero-argument `repairBudget()`. The factory owns its canonical name set, derived from `Object.keys(petrinautAiTools)`, rather than accepting the driver's legacy six-name subset. The independently replayed `updateArcWeight` discriminator now records all three rejected IDs and refuses further dispatch eligibility.

Reviewed in `/Users/lunelson/.herdr/worktrees/hash/alpha`, HEAD `923394c119bf83026ac9aa0c2a1884fa1092025d`, with exactly these pre-existing uncommitted changes:

- `apps/brunch-agent/src/evaluations/real-provider-a5.ts`
- `apps/brunch-agent/src/evaluations/real-provider-a5/preflight.ts`
- `apps/brunch-agent/test/real-provider-a5.test.ts`

No reviewer source edits, builds, installs, freeze, auth/provider/DNS requests or live-ledger operations occurred. Commands ran from ALPHA, using ALPHA's identity-checked deny-network profile. Only fresh `/tmp/a5-repair-review.3xg7fC/` outputs were created. Applicable app instructions and current MISSION changes were inspected; the bounded repair limit and no-active-reservation posture remain intact.

## Evidence and wiring

The parent's retained red (`/tmp/m7-repair-catalogue-owner.ltm6mQ/result.json`) shows `updateArcWeight` is canonical but not counted by the legacy configuration: `refused:false`, empty rejected map, and six configured names lacking it. This is the relevant observed omission, not a module-loading failure.

`preflight.ts:157–161` now constructs the set internally from the canonical registry. The registry in `libs/@hashintel/petrinaut-core/src/ai.ts` is generated from canonical mutation/command schemas plus canonical read/document tools. In the actual ALPHA import it contains **46 names**, including `updateArcWeight`. This broadens only which rejected canonical names consume repair budget; it does not mount any tool or admit a new operation/class.

`real-provider-a5.ts:190` uses `repairBudget()` directly. Existing checks remain before provider work and after observing cumulative request history (`:207–212`), with browser results observed at the HTTP boundary (`:309–315`). The factory no longer has a caller-selected subset seam. The request/response paths, rejection parsing, deduplication, three-rejection threshold and snapshot behavior are otherwise unchanged.

The new test checks each actual registry name separately: the check permits each of the first three attempts, then refuses after the third distinct rejection. Existing repeated-history deduplication, browser stale/failed/unknown result and unattributed-error tests remain. **Focused suite: 27/27 passed**, including its existing mounted accounting regression child. This is not a claim that I independently reran the reported full 315-test app suite, lint or typecheck.

A separate direct helper replay used `updateArcWeight` and the same zero-argument factory as the real driver. Actual result:

```json
{"canonicalNames":46,"refused":true,"rejected":{"updateArcWeight":["one","two","three"]}}
```

This verifies the omitted-name closure and the real driver configuration by source inspection plus direct execution. It is not a paid/model-generated repair-loop proof. Raw attester, transport and ledger review is not reopened by this change.

## Exact verification commands

The deny-network file's working-file and HEAD Git object identities both matched `ed8fca7b2aecc3c96b013e15094156be40018130`. Commands below record completed execution; existing output files should not be overwritten.

```bash
cd /Users/lunelson/.herdr/worktrees/hash/alpha
pwd
git rev-parse HEAD
git status --short
git diff -- apps/brunch-agent/src/evaluations/real-provider-a5.ts apps/brunch-agent/src/evaluations/real-provider-a5/preflight.ts apps/brunch-agent/test/real-provider-a5.test.ts
git hash-object libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb

cd /Users/lunelson/.herdr/worktrees/hash/alpha
git diff 862f6d72345d3313ff09c8f00d986e9577abe4d1 HEAD -- AGENTS.md apps/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/MISSION.md
rg -n 'repairBudget\(|budget\.(check|observe)' apps/brunch-agent/src/evaluations/real-provider-a5.ts apps/brunch-agent/test/real-provider-a5.test.ts
OUT=$(mktemp -d /tmp/a5-repair-review.XXXXXX)
echo "$OUT"
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
(cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5.test.ts) > "$OUT/focused-tests.log" 2>&1
echo tests=$?

cd /Users/lunelson/.herdr/worktrees/hash/alpha
/usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-strip-types --input-type=module -e 'import assert from "node:assert/strict"; import {repairBudget} from "./apps/brunch-agent/src/evaluations/real-provider-a5/preflight.ts"; import {petrinautAiTools} from "@hashintel/petrinaut-core/ai"; assert(Object.hasOwn(petrinautAiTools,"updateArcWeight")); const budget=repairBudget(); for(const id of ["one","two","three"]){budget.check(); budget.observe([{type:"tool_use",id,name:"updateArcWeight"},{type:"tool_result",tool_use_id:id,is_error:true}]);} assert.throws(()=>budget.check(),/three rejected/); console.log(JSON.stringify({canonicalNames:Object.keys(petrinautAiTools).length,refused:true,rejected:budget.snapshot()}));' > /tmp/a5-repair-review.3xg7fC/updateArcWeight.json 2> /tmp/a5-repair-review.3xg7fC/updateArcWeight.stderr
git status --short
```

Both test execution and direct discriminator exited0. Final worktree status still showed only the same three parent-owned modifications. Artifacts: `focused-tests.log`, `updateArcWeight.json`, `updateArcWeight.stderr` alongside this report.

## Limits and ownership

Acceptance here is limited to closing the demonstrated canonical repair-budget catalogue omission. It does not grant tool mounting, class admission, changed generation behavior, a paid run, final freeze, egress/policy acceptance or mission acceptance. The parent retains integration/freeze/reservation authority. No previous failure evidence was altered.
