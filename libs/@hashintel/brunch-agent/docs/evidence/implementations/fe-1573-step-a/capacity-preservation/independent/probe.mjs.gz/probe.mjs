import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const alpha='/Users/lunelson/.herdr/worktrees/hash/alpha';
const worker='/Users/lunelson/.herdr/worktrees/hash/m7-root-creation';
const core=await import(`${alpha}/libs/@hashintel/petrinaut-core/dist/index.js`);
const rootCore=await import(`${worker}/libs/@hashintel/petrinaut-core/dist/index.js`);
const plugin=await import(`${worker}/libs/@hashintel/brunch-agent/packages/plugin-sdcpn/dist/index.js`);
const json=(p)=>JSON.parse(readFileSync(p,'utf8'));
const records=json('/tmp/m7-root-creation-final/records.json');
const record=records.find(r=>r.toolCallId==='creation-pause'); assert(record);
const attempt=await plugin.verifyArcTransitionAttempt(record.metadata.transitionRecord.attempts[0]);
const before=attempt.post.definition;
const storage=json('/tmp/m7-root-creation-final/storage-before-reopen.json')['synthetic-root-creation-v1'];
const raw=json('/tmp/m7-root-creation-final/raw-reopen-result.json');
const hash=(v)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
assert.deepEqual(storage.sdcpn,before);
assert.deepEqual(raw.output.definition,raw.metadata.observation.observed.definition);
assert.equal(hash(raw.output.definition),raw.metadata.observation.observed.sha256);
assert.deepEqual(raw.metadata.observation.binding,attempt.binding);
assert.equal(core.parseSDCPNFile({...before,title:'Actual Chrome record'}).ok,true);
const extensions=core.resolvePetrinautHandleCapabilities({disabledExtensions:[]}).extensions;
assert.deepEqual(core.sanitizeSDCPNForExtensions(before,extensions),before);
const normalized=core.normalizeSDCPN(before);
const reopened=core.createJsonDocHandle({id:'review-only',initial:before,capabilities:{disabledExtensions:[]}}).doc();
assert.deepEqual(reopened,raw.output.definition);
const own=(place)=>({present:Object.hasOwn(place,'capacity'),...(Object.hasOwn(place,'capacity')?{value:place.capacity}:{})});
const controls=[];
for(const [name,value] of [['absent',undefined],['null',null],['zero',0],['positive',3]]) {
 const place={id:'review',name:'ReviewPlace',colorId:null,dynamicsEnabled:false,differentialEquationId:null,x:17,y:29,description:'Preserve this description',showAsInitialState:false,...(name==='absent'?{}:{capacity:value})};
 assert(core.placeSchema.safeParse(place).success);
 const doc={places:[place],transitions:[],types:[],parameters:[],differentialEquations:[]};
 assert.equal(core.parseSDCPNFile({...doc,title:'Canonical API control'}).ok,true);
 const n=core.normalizeSDCPN(doc), h=core.createJsonDocHandle({initial:doc,capabilities:{disabledExtensions:[]}}).doc(), s=core.sanitizeSDCPNForExtensions(doc,extensions);
 assert.deepEqual(rootCore.normalizeSDCPN(doc),n);
 for(const out of [n,h,s]) {assert.equal(out.places[0].description,place.description);assert.equal(out.places[0].x,17);assert.equal(out.places[0].showAsInitialState,false);}
 assert.deepEqual(s,doc); assert.deepEqual(own(place),name==='absent'?{present:false}:{present:true,value});
 controls.push({name,original:own(place),normalized:own(n.places[0]),handle:own(h.places[0]),sanitized:own(s.places[0]),normalizedEquivalent:core.isSDCPNEqual(n,doc),descriptionPreserved:true});
}
const result={actualRecordVerified:true,canonicalParserAccepts:true,storageExactlyPreservesPreReopen:true,rawReopenHashVerified:true,bindingMatches:true,alphaHandleMatchesActualRawReopen:true,normalization:normalized,controls};
writeFileSync('/tmp/m7-capacity-review.p48bar/result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(controls,null,2));
// Preserve a genuinely failing preservation discriminator after recording every control.
assert.equal(reopened.places[0].capacity,3,'Complete canonical place capacity must survive handle initialization');
