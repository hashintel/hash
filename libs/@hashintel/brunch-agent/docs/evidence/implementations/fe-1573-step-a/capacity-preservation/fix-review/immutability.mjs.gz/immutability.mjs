import assert from 'node:assert/strict';
import {normalizeSDCPN,createJsonDocHandle} from '/Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/petrinaut-core/dist/index.js';
const freeze=(x)=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
for(const kind of ['absent','undefined','null','zero','positive']){
 const cap={undefined:undefined,null:null,zero:0,positive:3}[kind];
 const input={places:[{id:'p',name:'Place',x:1,y:2,colorId:null,dynamicsEnabled:false,differentialEquationId:null,description:'preserved',...(kind==='absent'?{}:{capacity:cap})}],transitions:[],types:[],parameters:[],differentialEquations:[]};
 const original=structuredClone(input);freeze(input);
 const expected=structuredClone(input);if(cap===undefined)delete expected.places[0].capacity;
 assert.deepEqual(normalizeSDCPN(input),expected);
 assert.deepEqual(createJsonDocHandle({initial:input,capabilities:{disabledExtensions:[]}}).doc(),expected);
 assert.deepEqual(input,original);
 console.log('PASS',kind,'exact output shape, retained neighboring field, frozen input unchanged');
}
