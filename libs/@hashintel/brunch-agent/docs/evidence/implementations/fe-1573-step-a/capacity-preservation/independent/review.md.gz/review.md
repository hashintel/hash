# Capacity reopen — bounded independent diagnosis

## Verdict

**Confirmed canonical-core preservation defect.** The actual Chrome artifacts demonstrate that valid root `Place.capacity` values **3 and null are present before reopen and absent afterward**. An independent discriminator against ALPHA's existing published-core build reproduces the loss directly in `normalizeSDCPN`, before host storage, browser projection or extension sanitization. `createJsonDocHandle` invokes that same normalizer and produces a definition deeply equal to the actual raw Chrome reopened definition.

This is not merely an XML-escaped model-context object or a Brunch-only result discrepancy. The canonical producing code explains the observed loss. No production fix was made.

## Exact ownership and semantics

ALPHA HEAD: `47ebb1ef570d4514d2f3bb88f4df1896f1e76df8`. Root witness worktree HEAD: `e1387e7b04abccafe16654f7bc5b6ba59315fac3`. Both worktrees were initially clean and final status outputs are retained. Read applicable core AGENTS; existing root/Petrinaut/Brunch context guidance remains applicable. Only ALPHA canonical core and the requested root witness/code paths were investigated.

- `libs/@hashintel/petrinaut-core/src/types/sdcpn.ts:87-106`: canonical `Place` owns `capacity?: number | null`; absent or null means unbounded.
- `src/schemas/entity-schemas.ts:213-216`: canonical place schema accepts optional nullable nonnegative integers. The owner explicitly defines zero as a place that cannot receive tokens, positive values as a finite maximum, absent/null as unbounded. All four independent controls passed this existing schema and the full document parser; no schema was invented or widened.
- `src/types/sdcpn-input.ts:51-67`: `SDCPNPlaceInput` omits capacity entirely, even though a complete `SDCPN` is documented as valid input.
- `src/types/sdcpn-input.ts:123-156`: normalization explicitly promises equivalence for an already-complete SDCPN, constructs a new root-place object field by field and returns it without copying capacity. That omission is the loss site.
- `src/handle/json-doc-handle/create-json-doc-handle.ts:93-96`: initialization calls `sanitizeSDCPNForExtensions(normalizeSDCPN(opts.initial), ...)`; capacity is already absent before sanitization receives the definition.
- `src/types/sdcpn-input.test.ts:194-229`: the existing complete-document idempotence test has no capacity, so it does not discriminate this failure.

Null → absent preserves the engine's unbounded interpretation but violates complete canonical value/shape preservation. Zero/3 → absent also removes a finite behavioral constraint. I did not run a simulation or infer new capacity semantics; the owner type/schema and `simulation/engine/capacity.ts:52-59` already distinguish finite values from absent/null unbounded values.

## Independent probe

Created only `/tmp/m7-capacity-review.p48bar/probe.mjs`; ran it with ALPHA's existing `deny-network.sb`, no listeners, install, rebuild, provider calls or networking. Core APIs were imported explicitly from ALPHA's installed `petrinaut-core/dist/index.js`. The root worker's plugin verifier was used only to verify its actual `creation-pause` observation record; additional independent SHA-256 checks do not rely solely on that verifier.

`result.json` and `probe.stdout` preserve all controls before an intentionally real failing preservation assertion. **Exit 1**, exact error in `probe.stderr`:

```text
AssertionError [ERR_ASSERTION]: Complete canonical place capacity must survive handle initialization

undefined !== 3
```

The assertion runs at top level, not inside a faux callback. This is a retained failing preservation oracle, not an expected-failure exit misreported as a repaired pass.

| Complete canonical place input | Direct normalization | New JSON handle | Sanitizer alone, all extensions enabled | Owner equality after normalization |
| --- | --- | --- | --- | --- |
| capacity absent | absent | absent | absent | equal |
| capacity null | absent | absent | null retained | unequal |
| capacity 0 | absent | absent | 0 retained | unequal |
| capacity 3 | absent | absent | 3 retained | unequal |

The independent fixtures contain every required canonical document/place field. `description`, x=17 and explicit `showAsInitialState:false` survive every path. Both worktrees' built normalizers produce the same outcomes. Missing capacity is not explained by a generally invalid/minimal fixture, dropped falsey fields in JSON serialization, or wholesale place loss.

## Actual artifact checks and attempted refutations

Read `/tmp/m7-root-creation-final/{records.json,storage-before-reopen.json,raw-reopen-result.json}` and the requested worker diagnostic, plus `/tmp/m7-capacity-owner.6yEDSg/{reproduction.json,reproduction.stderr}`. The prior owner failure agrees with, but does not replace, the new independent probe.

1. **Model/XML projection alternative — refuted for this loss.** `creation-pause`'s full post definition is canonical-parser-valid. `storage-before-reopen.json` contains capacity 3/null in plain JSON. The raw reopened output definition equals its independently hash-verified observation definition and lacks both capacity keys. These are the raw records/storage/read result, not scraped assistant prose or an escaped model projection. `independent-artifact-hashes.txt` verifies pre/post/reopen SHA-256 directly from complete definitions with an independent Python implementation.
2. **Storage writer loss — refuted at the supplied pre-reopen boundary.** Stored `sdcpn` is deeply equal to the verified Chrome post definition, including capacity 3/null. Storage had retained the values before reload. Root website `local-storage-demo-app.tsx:184-189` passes `net.sdcpn` directly as `initial` to `createJsonDocHandle`; `:134-136` supplies `disabledExtensions:[]`.
3. **Wrong document/incarnation — refuted for the compared artifacts.** Reopened observation binding exactly equals the creation attempt binding. The same stored synthetic root document contains the pre-reopen definition.
4. **Extension sanitization — refuted as the cause here.** `sanitizeSDCPNForExtensions` directly on the intact actual definition is deeply equal to its input with the observed all-enabled settings. Each four-way control likewise preserves capacity through sanitizer-only execution. Source clones place fields (`extensions.ts:460-461`) and all-enabled place sanitization retains the place (`:272-290`). Direct normalization already loses capacity without invoking this machinery.
5. **Wrong API or incomplete document — refuted.** Owner docs explicitly promise complete SDCPN acceptance/equivalence, and actual record plus independent complete controls pass the published parser/schema. The exact same canonical handle entrypoint used by the website reproduces the raw reopened result.
6. **Stale core build — refuted for the causal code.** `pins.txt` hashes both core source/build sets and artifacts. Both worktrees' normalizer source SHA-256 is `b75b0930c4dcdf4bf7ece969798819ef41178d1379889f36e9a7bcb3586f68e7`; handle source hash is `8fc07f4708e43267a13793e5744f1a078d5085cca706d1b8ccb71db5a0363428`. Both builds' source maps embed exact current normalizer and handle source; no mismatch. ALPHA's handle output equals the actual raw Chrome reopen definition. No rebuild was needed to attribute this omission.

## Minimum owning fix and protected semantics — not implemented

The smallest owning correction belongs in published **Petrinaut core's `SDCPNPlaceInput` and `normalizeSDCPN`**, not Brunch, browser storage, transition records or result projection. Admit the already-canonical capacity field through the authoring input type using its owner meaning and carry supplied valid values into the normalized root place. Preserve zero and null literally; do not use truthiness or a nullish fallback that collapses their meaning/presence. Keep absence absent under the existing optional-field normalization convention. Do not add a capacity workaround/backfill, infer bounds from workpiece/history, change canonical validation, or bypass handle initialization.

Minimum proof should cover direct normalization and real JSON-handle initialization for absent/null/zero/positive on a complete canonical document, value/shape equivalence and an unaffected neighboring field. Preserve loose-input defaults, schema validity/invalid-input policy, extension behavior, nonmutation of input and existing serialization/equality semantics. Explicit own-property `capacity:undefined` was not a requested control and is not assigned new meaning by this diagnosis. A package fix would follow existing core publishing/changeset and documentation instructions.

## Limits

No new Chrome run, full browser rebuild provenance audit or simulation was performed. The artifacts' capacity loss and the direct owner-boundary cause are established; this does not prove every unrelated browser difference or the rest of root construction. Root Brunch code remains **unintegrated/red**, and later browser controls remain unearned. No capacity correction, broader field audit, workaround or integration/mission acceptance is authorized by this report.

## Commands and retained outputs

```sh
mktemp -d /tmp/m7-capacity-review.XXXXXX
git -C /Users/lunelson/.herdr/worktrees/hash/alpha rev-parse HEAD
git -C /Users/lunelson/.herdr/worktrees/hash/m7-root-creation rev-parse HEAD
git -C /Users/lunelson/.herdr/worktrees/hash/alpha status --short
git -C /Users/lunelson/.herdr/worktrees/hash/m7-root-creation status --short
sandbox-exec -f /Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node /tmp/m7-capacity-review.p48bar/probe.mjs > /tmp/m7-capacity-review.p48bar/probe.stdout 2> /tmp/m7-capacity-review.p48bar/probe.stderr
# Captured shell exit code separately in probe.exit (1).
```

Read-only Python scripts hashed source/build/artifact files, compared available source-map embedded content with existing source (`pins.txt`) and independently checked complete artifact hashes (`independent-artifact-hashes.txt`). Reads/searches used the exact owner/source/artifact paths listed above. Final worktree checks are in `alpha-final-status.txt` and `root-final-status.txt`. All created files reside in this fresh review-owned temporary directory.
