# Focused capacity fix review

## Verdict

**No blocker found.** The uncommitted five-file ALPHA delta implements the authorized minimum owner-boundary correction. The current core API preserves the original complete Chrome post definition, including capacity 3 and null. This is not evidence of corrected Chrome reopening: root-worker rebuild/replay of its unchanged browser gate remains required.

Reviewed ALPHA HEAD/authority `be29875ac3d5e7fd232102e398de45d06e67d0b2` plus the exact current uncommitted delta. `authority.diff` records the capacity-preservation amendment. `exact.diff` records the four tracked changes; the fifth file is the separately read untracked `.changeset/preserve-place-capacity.md`. `pins.txt` hashes all five files and core artifacts. No edits to repository source, installs, rebuilds, network/provider calls or root-worker changes. All tests ran under ALPHA's `deny-network.sb`; outputs are confined to this fresh review-owned directory. Final status retains the original five-file delta (`final-status.txt`).

## Source and contract

- `libs/@hashintel/petrinaut-core/src/types/sdcpn-input.ts:62-65` adds `capacity?: Place["capacity"]`, importing the canonical owner type rather than inventing a schema, numeric range, sentinel or meaning.
- `:151-153` copies capacity only when `!== undefined`. Zero and null survive literally. Absent/explicit undefined remain omitted, matching the authorized existing optional-field convention. Other defaults and field copying are unchanged.
- The function still constructs a new normalized place; there is no assignment into the supplied input. No handle implementation, storage, canonical validator, sanitization, mutation/history or Brunch source changed.
- `src/types/sdcpn-input.test.ts:66-88` asserts strict runtime output shapes for undefined/null/0/3 and strict idempotence. This is not merely a type-assignability test. The undefined case requires the output property to be absent.
- `src/handle/json-doc-handle/create-json-doc-handle.test.ts:71-96` separately tests absent/null/0/3 through initialization and serialization into a second handle, comparing both outputs to the original complete fixture. A stripped first handle cannot become the expected truth: the first strict assertion and final comparison both use the original fixture.
- `libs/@hashintel/petrinaut/docs/drawing-a-net.md:104` states that capacity persists with the net on reopening. `.changeset/preserve-place-capacity.md` is one core patch changeset. Neither invents different absent/null/zero/positive semantics.

The existing source tests do not themselves freeze the fixture, but the production delta is nonmutating and an additional independent frozen-input check below rules out passing by modifying the expected object.

## Independent verification

1. **Narrow source suites: 34/34 passed**, two files, exit 0 (`tests.log`, `tests.exit`). This independently confirms the reported green count. The parent’s prior 6-failure red and 66-task/3223-test portfolio were not rerun or independently certified here.
2. **Corrected canonical API discriminator on actual Chrome records: exit 0**, empty stderr (`corrected-probe.json`, `corrected-probe.stderr`, `corrected-probe.exit`). Inspected and ran `/tmp/m7-capacity-owner.6yEDSg/corrected-core-probe.mjs` from the root-worker directory: explicit ALPHA core import; root plugin verifies the original `creation-pause` record; original `reopened.places[0].capacity === 3` assertion remains; added deep equality compares both normalized and reopened definitions to the **original complete post definition**, not the already-stripped historical reopen. The original red files were not modified.
3. **Independent immutability/shape check: five cases passed**, exit 0 (`immutability.mjs`, `immutability.log`, `immutability.exit`). Deeply frozen complete inputs for absent, explicit undefined, null, zero and 3 were normalized and passed into a real JSON handle. Compared each output to a detached expected shape, retained a neighboring description, and asserted the original input was unchanged. Null/zero/3 stayed present; absent/undefined stayed omitted.
4. **Build pin:** current built core source-map content exactly matches the changed `sdcpn-input.ts`; SHA-256 inventory retained in `pins.txt`. Thus the API pass is against the changed installed normalizer, not a stale source-only test. No build was performed by this review.

The diagnostic's retained JSON still contains its inherited prose label “Diagnostic reproduction of loss; not a green preservation oracle or restored conversation.” That string is stale descriptive metadata, not the result: the unchanged required assertion plus two added complete-definition equality assertions now pass. This review credits only the canonical API preservation demonstrated by those assertions, not a corrected browser run or conversation restoration.

## Limits and handoff

No new Chrome run; no claim that the root-worker's already-stripped old reopened artifact has changed. No historical capacity restoration, backfill, schema widening, broad optional-field audit, simulation/utility verdict, root-class admission or mission/Step B acceptance. The parent can supply the reviewed core fix to the root worker, which still must rebuild/replay its unchanged raw browser reopen gate before later root-node controls are earned.

## Commands

```sh
git -C /Users/lunelson/.herdr/worktrees/hash/alpha status --short
git -C /Users/lunelson/.herdr/worktrees/hash/alpha rev-parse HEAD
git -C /Users/lunelson/.herdr/worktrees/hash/alpha diff > /tmp/m7-capacity-fix-review.LUbiJo/exact.diff
git -C /Users/lunelson/.herdr/worktrees/hash/alpha diff be29875ac3^ be29875ac3 -- libs/@hashintel/brunch-agent/MISSION.md > /tmp/m7-capacity-fix-review.LUbiJo/authority.diff

cd /Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/petrinaut-core
sandbox-exec -f ../brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../node_modules/vitest/vitest.mjs run src/types/sdcpn-input.test.ts src/handle/json-doc-handle/create-json-doc-handle.test.ts > /tmp/m7-capacity-fix-review.LUbiJo/tests.log 2>&1

cd /Users/lunelson/.herdr/worktrees/hash/m7-root-creation
sandbox-exec -f /Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node /tmp/m7-capacity-owner.6yEDSg/corrected-core-probe.mjs /tmp/m7-root-creation-final/records.json > /tmp/m7-capacity-fix-review.LUbiJo/corrected-probe.json 2> /tmp/m7-capacity-fix-review.LUbiJo/corrected-probe.stderr

sandbox-exec -f /Users/lunelson/.herdr/worktrees/hash/alpha/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node /tmp/m7-capacity-fix-review.LUbiJo/immutability.mjs > /tmp/m7-capacity-fix-review.LUbiJo/immutability.log 2>&1
```

Read-only Python hashed the five files and existing core JavaScript artifacts and asserted current source-map equality. Exit codes were retained separately for each test/probe. No output or historical evidence was overwritten outside this new review directory.
