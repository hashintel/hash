import { createElement } from '/Users/lunelson/.herdr/worktrees/hash/m7-construction-readiness/node_modules/react/index.js';
import { cleanup, fireEvent, render, screen } from '/Users/lunelson/.herdr/worktrees/hash/m7-construction-readiness/node_modules/@testing-library/react/dist/index.js';
import { afterEach, expect, test, vi } from '/Users/lunelson/.herdr/worktrees/hash/m7-construction-readiness/node_modules/vitest/dist/index.js';
import { AiAssistantToolList, toToolRenderItem } from '/Users/lunelson/.herdr/worktrees/hash/m7-construction-readiness/libs/@hashintel/petrinaut/src/ui/views/Editor/panels/ai-assistant-panel/ai-assistant-contents/tool-list.tsx';
const message = { id: 'review', role: 'assistant', parts: [] };
const show = (part, submit = vi.fn()) => render(createElement(AiAssistantToolList, { tools: [toToolRenderItem(message, part)], onInteractiveToolSubmit: submit }));
afterEach(cleanup);
test('stock layout decline crosses the real rendered widget then retains its honest submitted reason', () => {
 const part = { type: 'dynamic-tool', toolName: 'applyAutoLayout', toolCallId: 'layout', state: 'input-available', input: {askUserFirst: true} };
 const submit = vi.fn(); show(part, submit);
 fireEvent.click(screen.getByRole('button', {name: 'No, keep current layout'}));
 expect(submit).toHaveBeenCalledExactlyOnceWith({toolCallId: 'layout', toolName: 'applyAutoLayout', output: { applied: false, reason: 'User declined auto-layout.' }});
 cleanup();
 const view = show({...part, state:'output-available', output:{applied:false, reason:'User declined auto-layout.', title:'Auto-laid out 4 nodes'}});
 expect(screen.getByText('User declined auto-layout.')).toBeTruthy();
 expect(screen.queryByText('Auto-laid out 4 nodes')).toBeNull();
 expect(screen.queryByRole('button', {name:'No, keep current layout'})).toBeNull();
 expect(view.container.querySelector('[data-tool-result-icon="complete"]')).toBeNull();
});
test('contradictory generic mutation output cannot leak success title detail target or items into rendered card', () => {
 const view=show({type:'dynamic-tool',toolName:'updateArcWeight',toolCallId:'weight',state:'output-available',input:{weight:4},output:{applied:false,reason:'Host refused exact base.',title:'Updated arc weight',detail:'Requested value: 4',items:['Changed weight to 4'],target:{kind:'selection',item:{type:'place',id:'place'}}}});
 const row=screen.getByRole('button',{name:'Not applied Host refused exact base.'});
 expect(row.getAttribute('data-tone')).toBe('neutral');
 expect(row.disabled).toBe(true);
 expect(view.container.textContent).not.toContain('4');
 expect(view.container.textContent).not.toContain('Updated');
 expect(row.querySelector('[data-tool-result-icon="not-applied"]')).toBeTruthy();
 expect(row.querySelector('[data-tool-result-icon="complete"]')).toBeNull();
});
