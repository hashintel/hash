# Focused independent review — honest rendered tool results

## Verdict

**No blocker found in the approved renderer correction. The original green stale-result product blocker is closed at the exercised real browser boundary.** This is a focused code/proof verdict, not a waiver of the earlier blocker and not mission, integration, utility, paid/provider, broader-class or Step B acceptance.

Fixed comparison: `476370d652ef6abdf5bc808042a8d916ea04a920` → `6e722b13d0aa5511e4cae25be938dfe7ac643283`. Exactly five approved files differ: the Petrinaut patch changeset, assistant guide, existing assistant renderer tests, `ai-assistant-contents/tool-list.tsx`, and the candidate primary DOM assertions. Exact and word-level semantic diffs are retained as `exact.diff` and `semantic.diff`. Read applicable Petrinaut/app AGENTS; root/Brunch context instructions were already read in this review session. Read the pinned `4191a5f4d2` MISSION Visible-result correction authority (`authority.md:117`), not a broader inferred remit.

No tracked source edits, installs, rebuilds, provider egress, credentials, paid-profile commands or history import. Independent supplemental test/config files were created only inside this fresh owned `/tmp` directory. HEAD remained fixed. The tracked worktree remained unchanged; the final status showed an untracked `libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/construction-readiness/progression/` directory appearing during review, consistent with the permitted producer evidence packaging. It was neither modified nor removed (`final-head.txt`, `final-status.txt`). No untouched first-path ID/lifecycle edges were re-audited or promoted to findings.

## Actual visible discriminator

The primary probe ran **once**, with real Chrome, synthetic native responses, installed artifacts and verified loopback sandbox. Exit 0. `primary/observations.json`: 9 checked completions, 23 synthetic requests, two successful observed browser mutation records, no page/server errors, no blocked external browser requests and zero paid calls.

At the original stale boundary, the actual field stays **3** while the request is **4**. The rendered card now shows:

- **Not applied**;
- **“The requested base does not match the independently observed document.”**;
- neutral tone and an actual dash icon;
- no successful “Updated arc weight” summary and no completed-success check on that card.

The newly added primary assertions execute outside faux-response callbacks (`apps/brunch-agent/test/construction-progression.integration.ts:618-637`): actual properties input value 3, button accessible name, neutral data-tone, one not-applied icon, zero complete icons, absent successful summary. The retained screenshot `primary/stale-not-applied.png` was independently inspected: it visibly distinguishes the earlier successful weight **2** card/check from the later neutral **Not applied** card while properties display **3**. “2 operations” is visible instead of “2 changes.”

`raw-result-check.txt` independently inspects the wire delivery: `construction-stale`, raw `output.applied: false`, exact reason above, raw request weight 4, transition outcome `stale`, identical pre/post hashes `910f6bddf7b1ddd2cfedb294322254c99bdd1ed805a9ae8ea38bc7f1089d170d`. The renderer has not rewritten raw results, protocol state or actual document state to obtain this presentation.

## Source review

- `tool-list.tsx:364-370` detects only explicit boolean `applied === false` on an `output-available` result. Absent/unknown applied flags and error state are not relabelled as non-application.
- `:393-402` selects Not applied and the supplied string reason (fallback only if unavailable) before supplied success title/detail/items/target or requested-input summary. Thus contradictory output such as `{ applied:false, title:"Updated arc weight", detail:"Requested value: 4" }` cannot display the claimed success. Read-tool summary handling remains ahead of this branch; ordinary read contracts do not represent mutations.
- `:465-468` preserves output-error danger precedence and makes explicit non-application neutral. `:675-681` selects error close, then non-applied dash, then completed check. The false-result branch therefore cannot accidentally retain a success check.
- `:495-535` adds a derived rendering boolean; it does not mutate the source part, output or tool state. The interactive descriptor and submitted-output path remain unchanged. `ToolItem` still delegates registered interactive tools to their widget before generic cards.
- `:782` changes only the grouped label to operations, leaving grouping and completion behavior intact.
- The sole production delta is this generic renderer. No Brunch types, provenance, state transition, canonical execution, admission, transport or result validation changed. The changeset is a Petrinaut patch and the guide describes visible applied/not-applied/error states and the operations count.

## Independent controls

1. **Existing full focused renderer suite:** `renderer.log`, exit 0, **43/43 tests passed**. These render `AiAssistantContents` through React Testing Library rather than merely checking helper objects. They cover explicit blocked, declined, no-op, stale and contradictory-success output; applied and output-error presentation; reads, grouped rows, target selection, error details, interactive widgets/submission and existing Voice/composer controls. I did not rerun or reproduce the producer's historical “8 red” claim; source was frozen.
2. **Existing stock auto-layout widget controls:** `stock-widget.log`, exit 0, **4/4 passed**: actual confirm/decline button interactions, exact decline output, submitted summary and input gating.
3. **Additional independent rendered controls:** `render-controls.test.ts`, `vitest.config.mjs`, `independent-controls-correct-root.log`, exit 0, **2/2 passed**. These render the production `AiAssistantToolList` and real stock widget, not a fabricated browser result:
   - Click the actual “No, keep current layout” button, check the exact generic false/reason submission, then render the submitted widget with a contradictory success title. Only the real decline reason survives; no stale interactive button or complete-result icon appears.
   - Render a generic false mutation carrying success title, requested-value detail, child success items and a selectable target. Check neutral Not applied, exact reason, dash/no check, no “4” or “Updated” leakage anywhere in the rendered content, and disabled targetless row. This challenges more than the existing success-title test.

The first supplementary invocation failed before discovering tests because macOS resolved `/tmp` to `/private/tmp`: `Error: Cannot find module '/@fs/private/tmp/m7-render-review.QFvTnd/render-controls.test.ts'`. Full output retained in `independent-controls.log`; not counted as a pass. Corrected only the review-owned temporary config root/path, not repository source or assertions. The second invocation passed both tests.

## Guard, source/build pins and diagnostics

Before either suite or the browser probe, the existing `verify-network-guard.mjs` passed shell → Java and Node external EPERM tests under deny, commit and loopback profiles; loopback connection succeeded only under loopback (`guard.log`, `guard.exit: 0`). Renderer/control tests used `deny-network.sb`; the one Chrome probe used `loopback-only.sb`. No guarded failure was retried with networking enabled.

`pins.txt` retains SHA-256 hashes for all five changed files and the existing application, website and Petrinaut build artifacts. The installed Petrinaut source map embeds **exactly the current `tool-list.tsx` source**. All 23 available mapped app source files also match current source, including unchanged registration/execution-boundary wiring; no checked source-map mismatch. Website assets contain Not applied, not-applied/complete icon markers and operations. The primary run provides the stronger behavioral check that the actual served renderer has the correction.

**Pin limit:** no website source maps/reproducible-build manifest are supplied, so bundle hashing and markers plus actual behavior do not independently prove byte-for-byte reproduction of every website source file. No rebuild was performed or implied. The exact installed artifacts that ran are pinned.

Retained non-test-failure diagnostics:

- `renderer.log`: React Compiler warning at existing `voice-session-indicator.tsx:213`, `colorRef.current ??= targetColor`: “Logical assignment operators (||=, &&=, ??=) are not yet supported”; compiler skips optimizing that unchanged component. All 43 tests pass.
- `primary.log`: SQLite experimental warning and expected negative-control failures: mixed browser/server proposal refusal; multiple browser-call refusal; foreign browser record mismatch; canonical result versus observed outcome conflict. Exact stack traces and IDs are retained. The probe exits 0 with no page/server errors; these expected refusals are not hidden or interpreted as unexpected execution failures.

## Limits

The original rendered stale-result blocker is proven corrected, not treated as cosmetic. Actual submitted stock decline rendering is also independently checked, but not through a second Chrome session. Reads/applied/errors/interactive regression controls are rendered DOM tests plus the primary screenshot/product path, not a complete host/Voice/Stop/browser portfolio. No broad operation-class coverage, useful explanation coverage, genuine construction, paid/provider capability, remote/process durability, or Step B acceptance is earned by this renderer correction.

## Commands

Executed from the repository root unless shown otherwise. Read-only inspection commands and Python pin/record inspection are summarized below; their outputs remain alongside this report.

```sh
git status --short
git rev-parse HEAD
git diff --stat 476370d652 6e722b13d0
git diff 476370d652 6e722b13d0 > /tmp/m7-render-review.QFvTnd/exact.diff
git diff --word-diff=plain 476370d652 6e722b13d0 > /tmp/m7-render-review.QFvTnd/semantic.diff
git show 4191a5f4d2:libs/@hashintel/brunch-agent/MISSION.md > /tmp/m7-render-review.QFvTnd/authority.md
node libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/verify-network-guard.mjs > /tmp/m7-render-review.QFvTnd/guard.log 2>&1

cd libs/@hashintel/petrinaut
sandbox-exec -f ../brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../node_modules/vitest/vitest.mjs run src/ui/views/Editor/panels/ai-assistant-panel/ai-assistant-contents.test.tsx > /tmp/m7-render-review.QFvTnd/renderer.log 2>&1
sandbox-exec -f ../brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../node_modules/vitest/vitest.mjs run src/ui/views/Editor/panels/ai-assistant-panel/interactive-tools/apply-auto-layout-widget.test.tsx > /tmp/m7-render-review.QFvTnd/stock-widget.log 2>&1
# First temporary-config attempt (failed discovery; retained):
sandbox-exec -f ../brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../node_modules/vitest/vitest.mjs run --config /tmp/m7-render-review.QFvTnd/vitest.config.mjs > /tmp/m7-render-review.QFvTnd/independent-controls.log 2>&1
# Corrected review-owned root/path, same test assertions:
sandbox-exec -f ../brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../node_modules/vitest/vitest.mjs run --config /private/tmp/m7-render-review.QFvTnd/vitest.config.mjs > /tmp/m7-render-review.QFvTnd/independent-controls-correct-root.log 2>&1

cd /Users/lunelson/.herdr/worktrees/hash/m7-construction-readiness/apps/brunch-agent
M7_CONSTRUCTION_OUTPUT=/tmp/m7-render-review.QFvTnd/primary sandbox-exec -f ../../libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/loopback-only.sb node --experimental-strip-types test/construction-progression.integration.ts > /tmp/m7-render-review.QFvTnd/primary.log 2>&1
```

Read-only Python inspections used `hashlib.sha256`, JSON source-map `sourcesContent` equality, website marker lookup and actual `deliveries.json` inspection; outputs are `pins.txt` and `raw-result-check.txt`. Each executed test command has a retained `.exit` file. No producer report was substituted for an independent run.
