import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';
const [repo, bindingPath, runId, executionId, output] = process.argv.slice(2);
assert(repo && bindingPath && runId && executionId && output);
const { claimBrowser, digest } = await import(pathToFileURL(join(repo, 'apps/brunch-agent/src/evaluations/real-provider-a5/browser-session.ts')));
const { assertExternalDenied } = await import(pathToFileURL(join(repo, 'apps/brunch-agent/src/evaluations/real-provider-a5/network-guard.ts')));
await assertExternalDenied();
const ready = claimBrowser(bindingPath, runId, executionId);
assert.equal(process.ppid, ready.launcherPid);
const { chromium } = await import(pathToFileURL(join(repo, 'node_modules/@playwright/test/index.mjs')));
let browser;
let context;
const report = { runId, executionId, controllerPid: process.pid, launcherPid: process.ppid, ownerPid: ready.ownerPid, chromePid: ready.chromePid, controllerProfile: 'paid-provider.sb', browserProfile: 'loopback-only.sb', externalPort80: 'EPERM', endpointSha256: digest(ready.endpoint), providerRequests: 0, routeInterception: false, exposeNetwork: false };
try {
  browser = await chromium.connect(ready.endpoint, { timeout: 10000 });
  context = await browser.newContext({ serviceWorkers: 'block' });
  const page = await context.newPage();
  await page.setContent('<button onclick="document.querySelector(\'output\').textContent=\'Paid controller reached loopback browser\'">Check connection</button><output>Pending</output>');
  await page.getByRole('button', { name: 'Check connection' }).click();
  report.dom = await page.locator('output').textContent();
  assert.equal(report.dom, 'Paid controller reached loopback browser');
  try { await page.goto('https://192.0.2.1:443/', { timeout: 3000 }); throw new Error('Unexpected external browser connection'); }
  catch (error) { report.browserExternal443 = String(error); assert.match(report.browserExternal443, /ERR_(?:NETWORK_)?ACCESS_DENIED/); }
  report.connected = true;
  report.browserVersion = browser.version();
} finally {
  try { await context?.close(); } finally { await browser?.close(); }
  writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
}
