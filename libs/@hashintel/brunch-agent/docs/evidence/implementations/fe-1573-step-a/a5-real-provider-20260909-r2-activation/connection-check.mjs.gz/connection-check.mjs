import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, openSync, closeSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
const [repo, output] = process.argv.slice(2);
assert(repo && output);
const { createBrowserSession, loopbackProfile, privateJson, readPrivateJson, readBrowserReadiness, digest } = await import(pathToFileURL(join(repo, 'apps/brunch-agent/src/evaluations/real-provider-a5/browser-session.ts')));
// Process/filesystem orchestration only. All browser/socket code runs in guarded children.
const session = createBrowserSession('a5-real-provider-20260909-r2');
const environment = { PATH: '/usr/bin:/bin', HOME: join(session.directory, 'home'), TMPDIR: join(session.directory, 'tmp') };
const start = (label, profile, script, args) => {
  const stdout = openSync(join(output, label + '.stdout'), 'wx', 0o600);
  const stderr = openSync(join(output, label + '.stderr'), 'wx', 0o600);
  const child = spawn('/usr/bin/sandbox-exec', ['-f', profile, process.execPath, '--experimental-strip-types', script, ...args], { cwd: repo, env: environment, stdio: ['ignore', stdout, stderr] });
  closeSync(stdout); closeSync(stderr);
  let result;
  const exited = new Promise(resolve => { child.once('error', error => { result = { code: 1, error: String(error) }; resolve(result); }); child.once('exit', (code, signal) => { result = { code, signal }; resolve(result); }); });
  return { child, exited, result: () => result };
};
const owner = start('connection-owner', loopbackProfile, join(repo, 'apps/brunch-agent/src/evaluations/real-provider-a5/browser-owner.ts'), [join(session.directory, 'session.json')]);
let controller;
let ready;
let failure;
try {
  const readyPath = join(session.directory, 'ready.json');
  const deadline = Date.now() + 35000;
  while (!existsSync(readyPath)) { assert(!owner.result() && Date.now() < deadline, 'Owner did not become ready'); await delay(50); }
  const raw = readPrivateJson(readyPath);
  const binding = { session, ownerPid: owner.child.pid, chromePid: raw.chromePid, readinessSha256: digest(readFileSync(readyPath)) };
  ready = readBrowserReadiness(binding);
  const bindingPath = join(session.directory, 'binding.json');
  privateJson(bindingPath, binding);
  controller = start('connection-controller', join(repo, 'apps/brunch-agent/src/evaluations/real-provider-a5/paid-provider.sb'), join(output, 'connection-controller.mjs'), [repo, bindingPath, session.runId, session.executionId, join(output, 'connection-controller.json')]);
  const result = await Promise.race([controller.exited, delay(30000, null, { ref: false })]);
  assert.equal(result?.code, 0, 'Paid-profile controller attachment check failed');
} catch (error) { failure = error; }
finally {
  if (controller && !controller.result()) { controller.child.kill('SIGTERM'); await controller.exited; }
  writeFileSync(join(session.directory, 'stop'), 'parent connection check complete\n', { mode: 0o600 });
  const exit = await Promise.race([owner.exited, delay(16000, null, { ref: false })]);
  const cleanupPath = join(session.directory, 'cleanup.json');
  const cleanup = existsSync(cleanupPath) ? readPrivateJson(cleanupPath) : undefined;
  const bindingPath = join(session.directory, 'binding.json');
  if (existsSync(bindingPath)) unlinkSync(bindingPath);
  const report = { session, ownerPid: owner.child.pid, controllerPid: controller?.child.pid, ownerExit: exit, controllerExit: controller?.result(), cleanup, bindingRemoved: !existsSync(bindingPath), failure: failure ? String(failure) : undefined, providerRequests: 0 };
  privateJson(join(output, 'connection-check.json'), report);
  assert.equal(exit?.code, 0, 'Owner cleanup did not complete');
  assert(cleanup?.cleanupComplete && cleanup.chromeGone && cleanup.profileRemoved && cleanup.endpointClosed === 'ECONNREFUSED');
  for (const pid of [owner.child.pid, controller?.child.pid, ready?.chromePid]) {
    if (!pid) continue;
    assert.throws(() => process.kill(pid, 0), error => error.code === 'ESRCH');
  }
}
if (failure) throw failure;
console.log('R2 paid-controller to separate loopback-browser connection and cleanup passed; no provider request');
