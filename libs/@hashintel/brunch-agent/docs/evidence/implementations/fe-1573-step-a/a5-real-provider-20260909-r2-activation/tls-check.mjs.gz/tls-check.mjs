import assert from 'node:assert/strict';
import { connect, checkServerIdentity } from 'node:tls';
import { isIP } from 'node:net';
const ip = process.argv[2];
assert.equal(isIP(ip), 4);
const hostname = 'api.anthropic.com';
const started = Date.now();
const result = await new Promise((resolve, reject) => {
  const socket = connect({ host: ip, port: 443, servername: hostname, rejectUnauthorized: true });
  socket.setTimeout(10000, () => socket.destroy(new Error('Pinned TLS check timed out')));
  socket.once('error', reject);
  socket.once('secureConnect', () => {
    try {
      assert(socket.authorized, 'TLS peer was not authorized');
      assert.equal(socket.remoteAddress, ip);
      const certificate = socket.getPeerCertificate();
      assert.equal(checkServerIdentity(hostname, certificate), undefined);
      const observation = { hostname, ip, authorized: socket.authorized, protocol: socket.getProtocol(), cipher: socket.getCipher().name, certificate: { subject: certificate.subject, issuer: certificate.issuer, fingerprint256: certificate.fingerprint256, validFrom: certificate.valid_from, validTo: certificate.valid_to }, elapsedMs: Date.now() - started, at: new Date().toISOString(), httpRequests: 0, credentialsSent: false };
      socket.end();
      socket.once('close', () => resolve(observation));
    } catch (error) { socket.destroy(); reject(error); }
  });
});
console.log(JSON.stringify(result, null, 2));
