**The overlap-conservation blocker is resolved by `5f49529c8c`. No remaining concrete blocker in this narrow recheck.**

Inspected the shared-core change and focused tests before any producer conclusions:

- `libs/@hashintel/brunch-agent/packages/core/src/update-workpiece.ts:35–41,60–66` separates explicit declarations from the accumulating carried relations. Previously carried relations no longer suppress later overlapping relations.
- Unique unchanged same-span eligibility remains intact at `:53–59`.
- All retained source references still undergo revalidation at `:72–92`, before the state setter in `packages/core/src/flue.ts:129`.

**Executed results**

1. **Unchanged original mounted discriminator:** `/tmp/a5-independent-core.USwLHi/overlap.integration.mts` now **passes: 10 observations, 29 synthetic requests, zero paid calls**. Both relations survive carry and reopen at ordinal 2. Canonical carry input still omits evidence; canonical output retains both.
   - Evidence: `/var/folders/2c/ptn6jcrj61lck_yzfz_p3b5m0000gn/T/m7-a5-evidence-57SQD7/evidence-relations.json`

2. **Independent built-core controls: 9/9 passed**
   - Same-span relations in both orders.
   - Crossing partial-overlap relations in both orders.
   - Explicit new declaration overrides both overlapping old relations while preserving a disjoint relation.
   - Move, edit and duplicate ambiguity each prevent automatic carry.
   - Invalid **later** carried source rejects before any state write, preserving the previous state.
   - Probe: `/tmp/a5-overlap-recheck.owcCvA/controls.mjs`

Verified Java/Node descendant network guards and ran both probes under `deny-network.sb`. Before execution, core/app build sourcemap sources matched correction `5f49529c8c`—4 core and 23 app source entries. No tracked edits, builds, installs, existing-store changes or paid calls.

This closes my specific conservation finding, not broader A5 or mission acceptance.
