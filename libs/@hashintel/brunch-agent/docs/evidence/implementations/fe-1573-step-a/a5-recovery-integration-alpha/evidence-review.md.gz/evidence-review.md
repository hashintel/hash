## Finding: unchanged overlapping evidence is silently lost (P2)

**Location:** `libs/@hashintel/brunch-agent/packages/core/src/update-workpiece.ts:57–63`

The carry loop checks overlap against `relations`, which contains both new declarations **and relations already carried during that loop**. Consequently, one carried relation suppresses subsequent overlapping relations, even when all passages satisfy the admitted unique, unchanged, same-span condition.

**Reachable sequence, reproduced through the built mounted ChatAgent:**

1. Obtain the source ID and candidate span through `brunch_workpiece`.
2. Settle `"# TEST account\nReserve one crew.\n\nTiming remains unknown."` with two valid relations at the returned `[15,32)` span:
   - `elicited`, referencing the discovered true-user ID;
   - `formalism-constraint`, with no message IDs.
3. Both relations settle successfully with `evidenceValidated: true`.
4. Append `"\nUnrelated context."` using `update_workpiece`, omitting evidence.
5. The next revision settles successfully but retains **only the elicited relation**. Reopening confirms the loss.

The text occurs exactly once in both revisions and remains at the same span. No new declaration overrides either relation. This violates unchanged-passage evidence conservation; it is not ambiguous text continuity, semantic relevance assessment, or the disclosed runtime-recovery boundary.

**Test evidence:** A fresh temporary copy of `apps/brunch-agent/test/workpiece-evidence.integration.ts`, modified only to add the second relation and expect its preservation, reached the mounted boundary and failed its carry assertion. Retained history records the successful two-relation first revision and successful one-relation carried revision.

- Probe: `/tmp/a5-independent-core.USwLHi/overlap.integration.mts`
- Raw results: `/var/folders/2c/ptn6jcrj61lck_yzfz_p3b5m0000gn/T/m7-a5-evidence-NU7svm/failure.json`

## Other reviewed outcomes

- **Source acquisition works on the admitted browser-bound route.** The unchanged integration test passed: **10 observations, 29 synthetic requests, zero paid calls**. Its positive factory consumes model-facing source IDs and candidate spans, then queries settled locators; private calculations serve only as assertions.
- All declared source references are checked before mutation, regardless of relation kind (`update-workpiece.ts:69–89`). Additional built-tool controls passed duplicate-ID, assistant, prepared-purpose, foreign/missing-source, and valid-first/invalid-second relation refusals.
- Input attempts to forge `revisionId`, hash, ordinal, or `evidenceValidated` did not forge settlement. Evidence-bearing async state drift and cancellation refused without replacing the intervening authority (`flue.ts:106–145`).
- Candidate lookup remains explicitly unsettled and state-free. Exact UTF-16 overlapping spans passed execution; source/tests also cover duplicate counts, truncation, size/query limits, current hashes and no-current refusal. Flexible headings are not schema gates.
- Missing evidence does not acquire a validation flag or manufactured support.

**Verification boundaries:** Compared fixed product sources against the base; reviewed scoped source/tests without producer conclusions. Checked core/app build sourcemap source identity against `fb90244b23`. Verified Java/Node descendant network guards, then ran probes under `deny-network.sb` using Node 24. No tracked changes, rebuilds, installations, existing-store writes, or paid calls.

**One correctness finding; no additional blocker identified within this review scope.**
