# TEST synthetic transport attempts

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 1, turn turn_01M21Z9K7RBS3QRQD1C04M64BK, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 2, turn turn_01M21Z9KE5KTVQP3KMB4BATBV5, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 3, turn turn_01M21Z9KJB9KY8R0Z8DWQDE5WC, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 4, turn turn_01M21Z9KT10932PYMVRYNGQM50, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, not-started, invocation not-started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, unknown, invocation started, reserved USD 7, catalogue estimate USD unknown. JSON usage-ledger.json is authoritative.

- Request accounting v1: run TEST-a5-driver, sequence 5, turn turn_01M21Z9M449QZ8A71GPX7H6Y0Y, complete, invocation started, reserved USD 7, catalogue estimate USD 0.0006000000000000001. JSON usage-ledger.json is authoritative.
