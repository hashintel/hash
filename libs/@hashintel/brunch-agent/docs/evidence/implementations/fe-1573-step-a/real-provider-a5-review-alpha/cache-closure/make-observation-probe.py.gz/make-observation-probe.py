from pathlib import Path
import re
root=Path.cwd()
src=root/'apps/brunch-agent/test/real-provider-a5-terminal.integration.ts'
text=src.read_text()
text=re.sub(r'from "(\.[^"]+)"',lambda m:'from "'+(src.parent/m.group(1)).resolve().as_uri()+'"',text)
text=text.replace('"@earendil-works/pi-ai/providers/anthropic"','"'+(root/'node_modules/@earendil-works/pi-ai/dist/providers/anthropic.js').as_uri()+'"')
text=text.replace('"@flue/sdk"','"'+(root/'node_modules/@flue/sdk/dist/index.mjs').as_uri()+'"')
text=text.replace('"TEST-a5-terminal-"','"TEST-cache-review-observed-"')
text=text.replace('      "complete-initial-mixed",\n','      "complete-initial-mixed",\n      "write-below-retained-hour",\n      "complete-supported-write-decrease",\n',1)
needle='  return [\n    {\n      type: "message_start",'
assert needle in text
text=text.replace(needle,'''  if (scenario === "write-below-retained-hour")
    Object.assign(deltaUsage, {cache_creation_input_tokens:39, cache_read_input_tokens:81});
  if (scenario === "complete-supported-write-decrease")
    Object.assign(deltaUsage, {cache_creation_input_tokens:40, cache_read_input_tokens:80, cache_creation:partition(40,0)});
'''+needle)
text=text.replace('  for (const control of [\n','  for (const control of [\n    "write-below-retained-hour",\n    "complete-supported-write-decrease",\n',1)
needle='        "complete-initial-one-hour": {'
text=text.replace(needle,'''        "complete-supported-write-decrease": {
          input:100, cacheRead:80, cacheWrite:40, cacheWrite1h:40, usd:0.000864,
        },
'''+needle)
text=text.replace('    outcomes.push({','    save(`${control}-after-next.json`, {state:ledger(), dispatches:dispatches-before});\n    outcomes.push({',1)
Path('/tmp/a5-cache-review.aQk6JE/observation.integration.ts').write_text(text)
