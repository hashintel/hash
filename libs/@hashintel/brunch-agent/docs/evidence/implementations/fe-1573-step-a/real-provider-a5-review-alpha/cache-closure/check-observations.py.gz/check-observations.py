from pathlib import Path
import json,math
root=Path('/tmp/a5-cache-review.aQk6JE')
summaries=[]
for directory in root.glob('TEST-cache-review-observed-*'):
 result=json.loads((directory/'result.json').read_text())
 for item in result['outcomes']:
  name=item['control']; first=item['firstState']; row=first['calls'][0]
  after=json.loads((directory/(name+'-after-next.json')).read_text())
  raw=next(x['body'] for x in result['retained'] if x['scenario']==name)
  # Independently parse retained raw frames, not helper attestation output.
  frames=[]
  for block in raw.replace('\r\n','\n').split('\n\n'):
   lines=[line[6:] for line in block.split('\n') if line.startswith('data: ')]
   if lines:frames.append(json.loads('\n'.join(lines)))
  if name.startswith('complete'):
   initial=frames[0]['message']['usage']; current=dict(initial)
   for frame in frames:
    if frame['type']=='message_delta':
     for key,value in frame.get('usage',{}).items():
      if value is not None:current[key]=value
   raw_values=[current['input_tokens'],current.get('cache_read_input_tokens',0),current.get('cache_creation_input_tokens',0),current.get('cache_creation',{}).get('ephemeral_1h_input_tokens',0),current['output_tokens']]
   usage=row['terminal']['usage']; native_values=[usage['input'],usage['cacheRead'],usage['cacheWrite'],usage['cacheWrite1h'],usage['output']]
   assert raw_values==native_values,(name,raw_values,native_values)
   i,r,w,h,o=raw_values; expected=(3*i+0.3*r+3.75*(w-h)+6*h+15*o)/1e6
   assert row['status']=='complete' and math.isclose(row['actualUsd'],expected,abs_tol=1e-12)
   assert after['dispatches']==2 and len(after['state']['calls'])==2
   for second_row in after['state']['calls']:
    assert second_row['status']=='complete' and math.isclose(second_row['actualUsd'],expected,abs_tol=1e-12)
   assert math.isclose(after['state']['totals']['spentUsd'],expected*2,abs_tol=1e-12)
   assert after['state']['totals']['outstandingReservedUsd']==0
   summary={'control':name,'rawAndNativeInputReadWrite1hOutput':raw_values,'usd':expected,'dispatches':2,'hold':0}
  else:
   assert row['status']=='unknown' and 'actualUsd' not in row and first['totals']['outstandingReservedUsd']==7
   assert after['dispatches']==1 and after['state']['totals']['outstandingReservedUsd']==7
   assert len(after['state']['calls'])==1 and after['state']['calls'][0]['status']=='unknown'
   summary={'control':name,'status':'unknown','dispatches':1,'hold':7}
  summaries.append(summary)
for directory in root.glob('TEST-review-bypass-*'):
 for name in ['input-regression','delta-one-hour-cache']:
  first=json.loads((directory/(name+'-first.json')).read_text()); after=json.loads((directory/(name+'-second.json')).read_text())
  assert first['failed'] and first['state']['calls'][0]['status']=='unknown'
  assert 'actualUsd' not in first['state']['calls'][0]
  assert after['failed'] and after['dispatches']==1 and after['state']['totals']['outstandingReservedUsd']==7
  summaries.append({'exactPriorProbe':name,'status':'unknown','hold':7,'secondFailed':True,'dispatches':1})
with (root/'independent-observations.json').open('x') as out:json.dump(summaries,out,indent=2)
print(json.dumps(summaries,indent=2))
