# Independent read-only A5 paid-run readiness review

## Scope and identity

Reviewed fixed HEAD `f93d62a5404dcd3379971dc5940b59e610f18586`, implementation `efeb4921ca39d7da8878016b022ed8628b8b5416`, base `c41aeb54ca`. The worktree was clean before and after review. Read root/package AGENTS guidance and the current Brunch MISSION, including the bounded first-run envelope and AFK delegation. Proposed run: one built ChatAgent participant, `anthropic/claude-sonnet-4-6`, at most 20 underlying calls / US$15, 4,096 output tokens per call and US$7 hold. No reservation was active or activated by this review.

No tracked source edits, installation, rebuild, real-mode launch, external DNS resolution, provider egress opening, paid request or auth-validity request occurred. Existing narrow tests/preflight and the additional synthetic accounting discriminator ran under `native-local-delivery/deny-network.sb`. All review outputs are in this fresh owned temporary directory. No TLS handshake or provider acceptance was tested.

## Concrete blocker: incomplete native terminal usage can settle as complete

`apps/brunch-agent/src/evaluations/real-provider-a5.ts:247–281` validates native response model identity, but not terminal usage completeness before releasing buffered bytes to Pi. The installed Pi parser preserves initial usage when final usage is absent; `apps/brunch-agent/src/provider-accounting/request-ledger.ts:403–431` can then settle that partial usage as complete.

The offline discriminator supplied the installed native Anthropic provider with synthetic SSE containing a correct `message_start.model`, initial usage of 100 input / 1 output token, text output, `message_delta` with `stop_reason: "end_turn"` but no final usage, and `message_stop`. The provider returned `stopReason: "stop"` with the initial 101-token usage. Passing that actual normalized result through the production `RequestLedger` produced `status: "complete"`, `actualUsd: 0.000315`, releasing the US$7 hold. The new driver's native-response checks would admit those frames.

This is a malformed-response discriminator, not evidence that Anthropic normally omits usage. It nevertheless contradicts the required missing/uncertain-accounting stop: the run could continue on an underestimated settlement.

Necessary local correction: before releasing a successful buffered response, require valid native terminal output-usage evidence rather than relying solely on normalized positive totals. Missing evidence must leave accounting unknown and stop subsequent dispatch. Add this exact negative control beside the existing tests. No upstream change or new infrastructure is required.

Artifacts: `missing-terminal-usage.mjs`, `missing-terminal-usage-transform.log`, `TEST-terminal-usage-ledger.json`, and `TEST-attempt.md` in this directory. This discriminator exercised the installed native provider and production ledger directly, not the full mounted browser path. Its fetch returned synthetic bytes and never invoked HTTPS. The first strip-only launch failed before executing the test because Node strip-only mode does not support TypeScript parameter properties; that failure is retained in `missing-terminal-usage.log`. The subsequent `--experimental-transform-types` launch passed and produced the falsifying observation.

The parent subsequently reported accepting this blocker after its own independent replay at `/tmp/m7-paid-terminal-owner.E2t8Ne`, with correction delegated offline and no allocation/egress granted. That statement records the parent's report; this reviewer has not inspected that replay or any correction.

## Separate retention-callback cleanup observation

`apps/brunch-agent/src/evaluations/real-provider-a5/transport.ts:72–74,106–108` invokes `save()` from incoming/outgoing error listeners without a catch. `save()` invokes the caller's retention callback, which can throw during artifact writing or native model/response validation. A retention/model-validation failure during a network error can therefore escape as an uncaught exception instead of rejecting the transport promise and allowing orderly driver cleanup.

This was identified by source inspection, not an additional fault-injection test. The previously persisted unknown ledger entry and stale writer lock still fail closed; this observation does not establish unaccounted dispatch or manufactured successful usage. It can impair final artifacts, controlled shutdown and preservation of the original transport error. Keep it separate from the independently reproduced terminal-usage blocker.

## Other reviewed boundaries

### Native real mode and actual product wiring

Real mode uses `pinnedNativeRequest`; the scripted transport is imported only in explicit dry mode. The driver loads existing `dist/app.mjs`, uses the mounted ChatAgent route, existing accounting/admission registration, and actual Chrome client-result transport. No real-mode faux fallback, rewritten assistant response or scripted successful mutation was found. The final result explicitly remains unadjudicated; completed submissions alone do not establish A5 success. This review did not execute a fresh real-browser dry run or claim a fresh integrated paid path.

### Reservation, dispatch and repair bounds

Named active reservation checks, canonical ledger resolution, an exclusive writer lock, production pre-dispatch journaling, turn identity checks, single-dispatch checks and zero-retry settings provide concrete controls. Unknown/pending-journal entries block continuation. The selected catalogue calculation is US$6.06144 against the US$7 hold, with 4,096 output tokens. The driver's lock supplements—not replaces—the integration owner's global sole-writer delegation. These controls remain useful, but terminal-usage missettlement weakens dollar accounting.

Rejection IDs are deduplicated across cumulative history; browser failures are also inspected at HTTP delivery. A third rejected canonical operation blocks further provider dispatch. Failed submissions are not automatically repaired by the driver.

### Network layering

The paid policy accurately permits outbound TCP 443 generally, plus loopback; it is not an OS Anthropic destination filter. Native HTTPS enforces exact endpoint/POST, owner-supplied numeric lookup, verified TLS/SNI, and no proxy, redirect following or retry. Chrome gets a narrower loopback sandbox and only PATH/HOME/TMPDIR environment entries. This is a layered trusted-driver boundary, not protection against arbitrary parent-process HTTPS code.

Known environment limits remain: numeric/hostname remote filters were previously rejected; a broader paid profile cannot be applied inside the restrictive dry parent. Standalone paid-profile application, a real TLS handshake and provider acceptance remain unproved. Synthetic HTTPS-options tests establish none of those.

### Buffering, model IDs, failures and partial output

Native bytes are retained before parsing; redirects and model mismatches stop. The installed Pi parser rejects missing `message_stop`, pending stop reason and SSE error events. Abort/error accounting remains uncertain rather than guessed. Those protections do not detect the reproduced missing-final-usage case. The retention-callback cleanup observation above is a separate error-path limitation.

### Fixture labels and credentials

The fixture clearly labels synthetic user testimony, prepared topology and non-Vestera scope. Request artifacts omit provider headers/options/environment; preflight records credential availability, not credentials or validity. A credential-pattern scan of retained textual/compressed readiness evidence found zero matches. This is a bounded pattern scan, not a comprehensive secret certification; screenshots were excluded from that scan.

## Verification results

- HEAD exactly matched the requested revision; `git status --short` / `git status --porcelain` were empty before and after.
- The deny-network profile's working-file Git object identity matched the HEAD object: `ed8fca7b2aecc3c96b013e15094156be40018130`.
- Node resolved to `/Users/lunelson/.local/share/mise/installs/node/22.21.1/bin/node`, version `v22.21.1`.
- `verifyManifest` verified every listed file identity and the selected model catalogue against the retained manifest. The manifest identifies implementation `efeb4921ca39d7da8878016b022ed8628b8b5416` and runtime `v22.21.1`. This checked consistency with the retained manifest, not independent build provenance.
- Built `apps/brunch-agent/dist/app.mjs` SHA-256: `9cc9cc8b6f9d90a3bf5f70ff26a23f91b3ffe8a05e91e19aeabb5989a0213f7f`.
- Built `apps/petrinaut-website/dist/index.html` SHA-256: `564f0d5d8b4c19f75a70dc3cc957e36880b11a88c9f05e236880c50e22d9caca`.
- Existing `real-provider-a5.test.ts`: 22/22 tests passed under the deny-network profile (`tests.log`).
- Driver preflight passed under the deny-network profile (`preflight.log`, `preflight/manifest.json`, `preflight/preflight.json`). It did not invoke a provider or validate credentials.
- Additional synthetic native-provider/ledger discriminator reproduced the blocker (`missing-terminal-usage-transform.log`).

## Exact verification commands

Commands below record what was executed, not instructions to rerun into these existing output paths. Preserve existing artifacts. The repository working directory was `/Users/lunelson/.herdr/worktrees/hash/m7-real-provider`.

### Initial identities and write set

```bash
pwd
git status --short
git rev-parse HEAD
git show -s --format='%H %s' efeb4921ca39d7da8878016b022ed8628b8b5416
git diff --name-only c41aeb54ca f93d62a5404dcd3379971dc5940b59e610f18586

command -v node
node --version
git hash-object libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
ls -l node_modules/.bin/vitest node_modules/vitest/vitest.mjs /usr/bin/sandbox-exec
git status --porcelain
shasum -a 256 apps/brunch-agent/dist/app.mjs apps/petrinaut-website/dist/index.html
```

### Manifest verification, narrow existing tests and preflight

```bash
OUT=$(mktemp -d /tmp/a5-independent-review.XXXXXX)
echo "$OUT"
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
/usr/bin/sandbox-exec -f "$PROFILE" node --experimental-strip-types --input-type=module -e 'import { verifyManifest } from "./apps/brunch-agent/src/evaluations/real-provider-a5/manifest.ts"; import {sha256} from "./apps/brunch-agent/src/evaluations/real-provider-a5/preflight.ts"; import {readFileSync} from "node:fs"; const p="libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/real-provider-a5-readiness/manifest.json"; const m=verifyManifest(p,sha256(readFileSync(p))); console.log("Manifest file identities match",m.commit,m.runtime)' > "$OUT/identities.log" 2>&1
ID=$?
echo "identities=$ID"
if [ "$ID" = 0 ]; then
  (cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5.test.ts) > "$OUT/tests.log" 2>&1
  echo "tests=$?"
  /usr/bin/sandbox-exec -f "$PROFILE" node --experimental-strip-types apps/brunch-agent/src/evaluations/real-provider-a5.ts preflight "$OUT/preflight" > "$OUT/preflight.log" 2>&1
  echo "preflight=$?"
fi
```

The generated `OUT` was `/tmp/a5-independent-review.rQW0D9`; all three exit codes were zero.

### Additional offline falsifier

The complete executed probe source is preserved as `/tmp/a5-independent-review.rQW0D9/missing-terminal-usage.mjs`. It creates only TEST ledger/journal files with exclusive-create flags, supplies `TEST-not-a-credential` explicitly and uses a synthetic fetch response. No real transport is invoked.

```bash
/usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-strip-types /tmp/a5-independent-review.rQW0D9/missing-terminal-usage.mjs > /tmp/a5-independent-review.rQW0D9/missing-terminal-usage.log 2>&1
echo probe=$?
git status --porcelain

/usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-transform-types /tmp/a5-independent-review.rQW0D9/missing-terminal-usage.mjs > /tmp/a5-independent-review.rQW0D9/missing-terminal-usage-transform.log 2>&1
echo probe=$?
```

The strip-only command returned 1 before probe execution; transform-types returned 0 with the falsifying complete settlement.

### Credential-shaped pattern scan and final worktree check

```bash
python3 - <<'PY'
import pathlib,gzip,re
root=pathlib.Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/real-provider-a5-readiness')
hits=[]
for p in root.rglob('*'):
 if not p.is_file() or p.suffix=='.png': continue
 data=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
 if re.search(rb'sk-ant-[A-Za-z0-9_-]{20,}|(?i:authorization)["\s:]+Bearer\s+[A-Za-z0-9._-]{20,}',data):hits.append(str(p))
print('Credential-shaped matches:',len(hits))
PY
rg -n 'const complete =|current.status = "complete"|usage.output <=|incoming.on\("error"|outgoing.on\("error"|save\(\);' apps/brunch-agent/src/provider-accounting/request-ledger.ts apps/brunch-agent/src/evaluations/real-provider-a5/transport.ts
git status --porcelain
```

## Remaining activation-time checks and authority limits

After correction and focused re-review, activation still requires a freshly reviewed manifest, authoritative reservation and sole-writer delegation, exact model configuration, reviewed numeric IP, and explicit integration-owner acceptance of the port-only layering. Standalone paid-profile application must be verified at its actual execution boundary; the restrictive offline parent cannot establish that a broader paid profile works. Real TLS and provider acceptance remain questions for a properly reserved run, not this review.

No shipping, budget activation, policy acceptance, utility acceptance or mission verdict is supplied. Those decisions remain with the parent/owner. This report preserves the original review and its evidence; it does not assess the pending correction.
