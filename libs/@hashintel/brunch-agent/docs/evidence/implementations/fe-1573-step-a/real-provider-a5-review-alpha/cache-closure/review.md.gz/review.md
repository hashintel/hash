# Independent focused cache/input attestation re-review

## Result

**No remaining concrete blocker found at this bounded raw-input/cache attestation seam.** The exact previous late-one-hour tier-loss counterexample now remains **unknown**, retains **US$7**, has **no actualUsd**, and refuses the next mounted submission before a second HTTPS dispatch. The exact previous uncompensated input-loss case has the same result. Both were rerun using the unchanged prior reviewer discriminator, not merely the worker's new control names.

This conclusion covers the explicit evaluation raw gate with the pinned native parser and catalogue. It does not fix or accept generic normalized-only accounting, establish a universal vendor usage rule, certify invoices, accept a final instrument manifest, or authorize egress/reservation/paid execution.

## Identity and scope

- Reviewed code `008b576b6107175ee02d80ed91bd55ba6d79c0f0`, evidence/HEAD `862f6d72345d3313ff09c8f00d986e9577abe4d1`.
- Worktree clean before and after review. Applicable AGENTS/MISSION previously read and verified unchanged since the preceding review.
- All five `bounded-source-pins.json` file hashes matched actual files: attester, terminal integration, installed native parser, estimator, and SDK message types.
- Compared all 3,312 v4 manifest pins: only `native-response.ts` and `real-provider-a5-terminal.integration.ts` differ. V4 SHA-256 remains `1de43141dfbe68902af2bf1d62f52bbdaf72c2f10e6277abc6c0fa759b62b243`. **V4 is not the current final instrument**; no new final manifest was generated or accepted here.
- Deny-network profile working-file/HEAD Git object identity: `ed8fca7b2aecc3c96b013e15094156be40018130`. Node `/Users/lunelson/.local/share/mise/installs/node/22.21.1/bin/node`, `v22.21.1`.
- No tracked source edits, installation, rebuild, auth/credential check, DNS lookup, provider connection, real-mode launch, live-ledger access or paid call. All execution used the identity-checked deny-network profile and fresh owned TEST outputs. Prior failures and artifacts were preserved.

## Correction inspection

`apps/brunch-agent/src/evaluations/real-provider-a5/native-response.ts:30–86` now maintains comparison registers only. It does not replace bytes, inject SDK counters or settle the ledger. Initial defaults and omitted/null delta carry match the pinned parser. Every explicit cache partition must contain valid one-hour/five-minute counts summing to effective cache writes; its one-hour share must equal what Pi retained at message_start. The effective write total must still cover that retained share. Both changed one-hour directions refuse before raw bytes reach Pi; supported total/five-minute updates remain possible.

The inspected installed parser sets `cacheWrite1h` only at message_start (`api/anthropic-messages.js:386–390`), and updates explicit non-null input/read/write totals on deltas (`:540–549`). The installed estimator (`models.js:371–390`) prices one-hour writes at twice input rate, five-minute writes as `cacheWrite - cacheWrite1h`, and uses input+read+write as aggregate input. Thus a raw partition with unchanged one-hour count and matching effective total is faithfully representable, whereas a changed one-hour share is not. The new checks close the demonstrated lost-tier settlement without modifying the parser.

The initial partition type is not guessed: pinned SDK `messages.d.ts:164–172` requires both TTL counters; `Usage` calls it a TTL breakdown (`:1395–1403`). Its message documentation defines total input as input+cache-created+cache-read (`:649–650`); `MessageDeltaUsage` describes cumulative counts (`:659–675`). Null delta fields are carried by the actual parser.

### Input-loss interpretation

The aggregate nondecrease gate is a conservative interpretation of those pinned cumulative, disjoint-used-token fields. It is **not scalar monotonicity**: input, reads or writes can individually decrease if a supported redistribution preserves aggregate input and the retained cache tier remains representable. The probes below prove this parser compatibility, not that Anthropic promises to emit each synthetic redistribution. I found no concrete supported-case refusal under this local interpretation. If the provider later reports aggregate retractions/provisional estimates, this instrument will refuse rather than infer a free correction; deciding whether to accept such a contract remains owner-held. No universal vendor rule is claimed.

Absent/null cache partitions retain the pinned parser's initial/default one-hour interpretation; this review does not infer an unreported TTL. New provider billing fields or invoice semantics are outside this bounded conclusion.

## Actual boundary verification, not counts alone

The existing focused suite passed **26/26**, including the current mounted child (**25 controls / 34 synthetic HTTPS dispatches**). I did not rerun or independently claim the reported full 313-test app suite.

I also ran a temporary derivative of the current mounted probe that records the actual ledger after every second submission and adds two narrow controls. It retains actual built registration, native provider/SDK, pinned real-mode transport, admission and RequestLedger; only auth and HTTPS events are synthetic. This run covered **27 controls / 37 synthetic HTTPS dispatches**, zero paid calls. The added controls were:

- Retained one-hour40, then write39/read81: aggregate is preserved, but writes cannot cover the retained tier. Result: unknown, US$7 held, next dispatch refused.
- Initial input100/read20/write100/one-hour40, then input100/read80/write40/one-hour40/five-minute0: a supported decrease in total writes, compensated by reads. Result: complete at US$0.000864, no hold, and a second correctly counted/settled request. This falsifies accidental scalar write monotonicity.

An independent Python checker parsed the retained raw SSE and compared raw effective input/read/write/one-hour/output counters with actual native terminal ledger usage. It separately calculated costs from the pinned rates, checked each actual second ledger row and doubled total, and checked every negative retained one unknown row/US$7/no second dispatch. It passed; `independent-observations.json` records the results.

All positive rows below have output20, zero hold, two completed ledger rows and two HTTPS dispatches:

| Control | Native input / read / write / one-hour | First catalogue USD |
| --- | --- | --- |
| Initial one-hour | 100 / 0 / 100 / 100 | 0.0012 |
| Initial five-minute | 100 / 0 / 100 / 0 | 0.000975 |
| Initial mixed | 100 / 20 / 100 / 40 | 0.001071 |
| Late supported five-minute | 100 / 0 / 100 / 0 | 0.000975 |
| Mixed supported redistribution | 80 / 50 / 150 / 40 | 0.0012075 |
| Input100 → input0/read100 | 0 / 100 / 0 / 0 | 0.00033 |
| Mixed initial + null delta fields | 100 / 20 / 100 / 40 | 0.001071 |
| Supported write decrease, added by reviewer | 100 / 80 / 40 / 40 | 0.000864 |
| Ordinary complete and multiline CRLF | 100 / 0 / 0 / 0 | 0.0006 |

Negative cases independently checked in actual first and after-next ledgers: late one-hour increase/decrease; initial/late partition contradiction; uncompensated input loss; writes below retained one-hour; missing terminal usage under HTTP200/201; missing/null/string/negative/fractional/regressed output; missing stop; incoming/outgoing socket errors combined with throwing retention callbacks. Each retained one unknown entry without `actualUsd`, US$7 outstanding, and one dispatch after the attempted second submission. Connection-error logs on these cases are expected failed submissions, not test execution failures.

The exact prior reviewer probe was separately rerun from `/tmp/a5-focused-review.nVLNoh/bypass.integration.ts`, unchanged. Both its `input-regression` and `delta-one-hour-cache` first submissions failed; second submissions failed with dispatch count still1 and hold7. Its diagnostic `passed:true` is not used as a safety verdict; the ledger assertions were checked separately.

## Evidence and exact commands

All new outputs are under `/tmp/a5-cache-review.aQk6JE/`:

- `focused-tests.log`: narrow existing tests and their mounted child.
- `exact-prior-bypass.log` and `TEST-review-bypass-*/`: exact prior counterexamples against corrected code, including first/second ledgers and raw bytes.
- `make-observation-probe.py`, `observation.integration.ts`, `observed-mounted.log`, `TEST-cache-review-observed-*/`: reproducible temporary derivative with added controls and after-next snapshots.
- `check-observations.py`, `independent-check.log`, `independent-observations.json`: independent raw-versus-native cost and second-dispatch checks.

Commands below record executed verification, not instructions to overwrite these outputs. Repository cwd was `/Users/lunelson/.herdr/worktrees/hash/m7-real-provider`.

```bash
git rev-parse HEAD
git status --short
git diff --stat 9cef6310816e9e630851c7df2c188039df2f6077 HEAD
git hash-object libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
git rev-parse HEAD:libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb
command -v node
node --version
git diff 9cef6310816e9e630851c7df2c188039df2f6077 HEAD -- AGENTS.md apps/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/AGENTS.md libs/@hashintel/brunch-agent/MISSION.md

OUT=$(mktemp -d /tmp/a5-cache-review.XXXXXX)
echo "$OUT"
PROFILE="$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb"
python3 - <<'PY'
import json,hashlib,pathlib
root=pathlib.Path('libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a')
pins=json.loads((root/'real-provider-a5-cache-attestation/bounded-source-pins.json').read_text())
for name,digest in pins['files'].items():
 assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
print('bounded pins verified',len(pins['files']))
p=root/'real-provider-a5-final-freeze/manifest-terminal-v4.json'; b=p.read_bytes(); m=json.loads(b)
changed=[name for name,digest in m['files'].items() if hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()!=digest]
print('v4 sha256',hashlib.sha256(b).hexdigest(),'pins',len(m['files']),'changed',changed)
PY
(cd apps/brunch-agent && TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts --no-cache test/real-provider-a5.test.ts) > "$OUT/focused-tests.log" 2>&1
echo tests=$?
TMPDIR="$OUT" /usr/bin/sandbox-exec -f "$PROFILE" node --experimental-strip-types /tmp/a5-focused-review.nVLNoh/bypass.integration.ts > "$OUT/exact-prior-bypass.log" 2>&1
echo exact=$?

python3 /tmp/a5-cache-review.aQk6JE/make-observation-probe.py
TMPDIR=/tmp/a5-cache-review.aQk6JE /usr/bin/sandbox-exec -f "$PWD/libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb" node --experimental-strip-types /tmp/a5-cache-review.aQk6JE/observation.integration.ts > /tmp/a5-cache-review.aQk6JE/observed-mounted.log 2>&1
echo observed=$?
git status --short
git rev-parse HEAD

python3 /tmp/a5-cache-review.aQk6JE/check-observations.py > /tmp/a5-cache-review.aQk6JE/independent-check.log 2>&1
echo check=$?
```

All four execution/check exit codes were0. The complete generator and checker source are retained beside this report. The temporary derivative rebases imports to existing installed/repository modules, adds only the two described raw input mutations and expected outcomes, and saves after-next snapshots; it does not replace runtime, native parsing or accounting.

## Remaining parent-owned gates

A new merged-instrument freeze and its independent hash verification remain necessary; retained v1–v4 manifests are not silently promoted. Egress layering, standalone paid-profile execution, reviewed numeric IP, authoritative reservation/sole writer and policy acceptance remain parent-owned. No real TLS handshake, provider acceptance, billed-cost reconciliation, browser utility or mission verdict is established by these synthetic tests. No paid activation is granted by this review.
