# Independent typed-state checkpoint review

## Verdict

**One confirmed P1 explanation-safety blocker: aggregate state-field queries bypass descendant changes and can select an obsolete creation basis for current migrated/corrected values.** The scripted leaf-cell path and mechanical record audit pass, but do not discharge the newly exposed aggregate field/pointer contract. Do not integrate this checkpoint as satisfying typed-state explanation safety until the aggregate discriminator is addressed and re-proved.

Target was `/Users/lunelson/.herdr/worktrees/hash/m7-typed-state`, fixed source `3b98cb287275c60c45087e4dc2500f626a39f163`, evidence HEAD `1031d34c1e56769453533fd85af45767438c1fdd`, base `dd748a4239`. Fifteen changed source/config paths comprise the worker's thirteen-file delta plus the parent's two inventory files (`788a9dcc1e`). Read target root/app/Brunch AGENTS, ALPHA MISSION's construction/native-schema/typed-state/protected contracts, and the checkpoint handoff/class table. No source changes, installs, rebuilds, provider/DNS calls, live-ledger reads, paid profiles, restored product history or other-worktree mutation. All new outputs are in this fresh owned directory; target finished clean at the same HEAD.

## P1 — Aggregate queries can inherit obsolete basis despite derived descendants

**Locations:** `apps/brunch-agent/src/conversation/why.ts:468-489` (`covers`/`affects`), `:505-529` (governing selection and derived refusal); newly exposed aggregate field/pointer selection in `libs/@hashintel/brunch-agent/packages/plugin-sdcpn/src/root-state.ts:118-145`. The mounted tool explicitly advertises top-level state fields and relative JSON pointers (`why.ts:629-640`).

`covers(effectPath, queriedPath)` recognizes an effect on the queried path or an ancestor of it. It does **not** recognize effects below the queried path, except when the literal field is `entity`. Consequently scenario cell migrations/corrections do not affect queries for `initialState`, `/initialState/content`, or a row parent; element append/type changes do not affect a type's `elements` query. Governing selection falls back to the original parent creation effect, and the derived refusal checks only that selected old change. The current target value nevertheless contains the later derived/corrected children.

### Reproduction on this independent Chrome run's actual reachable history

`aggregate-why.mjs` passes **unmodified `primary/history.json`**, its actual settled revision/binding, and normal queries accepted by the production `parseConstructionWhyInput` into the exported production `explainRootArc`. It does not fabricate a net/result/history or load anything into the product store. This is an offline deterministic product-function discriminator using a captured reachable state, not a second browser/HTTP query replay; the mounted tool delegates directly to this same function. Full outputs are in `aggregate-why.json`; exact results and failing safety assertion are in `aggregate-why.log`, exit **1**.

| Accepted ordinary query | Actual current value | Returned governing change/revision | Problem/control |
| --- | --- | --- | --- |
| scenario `TestInitial`, field `initialState` | `[[2,true],[3,false]]` under test-queue | `typed-scenario` / `typed-revision-one`, partially-supported | Creation basis predates both migrations and explicit correction; current aggregate still contains a derived false cell. |
| same scenario, field `/initialState/content/test-queue/1` | `[3,false]` | `typed-scenario` / revision one, partially-supported | Row contains a revision-two explicit 3 and a still-derived false, yet selects creation as current governing change. |
| same scenario, leaf `/initialState/content/test-queue/1/0` | `3` | `typed-explicit-initial` / revision two, partially-supported | Positive leaf control correctly selects the later explicit cause. |
| same scenario, leaf `/initialState/content/test-queue/1/1` | `false` | `typed-active`, **refused**, no governing basis | Negative leaf control correctly recognizes the still-derived cell. Aggregating it must not bypass this refusal. |
| type `TestCorrectedAttributes`, field `elements` | integer value + appended boolean active | `typed-type` / revision one, partially-supported | Creation originally contained only the string attribute; current aggregate ignores later nested changes. |

The output's generic operation-only/utility-unassessed disclaimer does not repair the wrong structured `recordedChange`/`governing` selection. This is not a demand for useful semantic coverage or token-identity machinery: the existing contract already forbids migrated/default fields acquiring the whole request basis and requires origin/current change to remain distinct.

**Minimum correction obligation:** account for descendant changes when adjudicating an aggregate field, and refuse an aggregate whose current parts cannot honestly share the selected basis (including still-derived cells). Preserve working leaf queries and origin history. Merely reversing `covers` and crediting the latest explicit initial-state call to the whole aggregate would also be wrong: unchanged false still has no new explicit cause. A conservative explicit aggregate refusal is preferable to inventing a provenance/composition engine. Add the parent/row/type-elements discriminator alongside the existing leaf controls. No fix implemented here.

A read-only delegated reviewer inspected the exact supplied source paths and independently confirmed this descendant-overlap failure after I identified and probed it; no guessed-path/helper-only hypothetical was credited.

## Independent runs and pins

| Check | Result |
| --- | --- |
| Existing process-tree guard | Pass: shell → Java/Node external EPERM under deny/commit/loopback profiles, local allowance only in browser profile. `guard.log`, exit0. |
| Source/build/runtime manifest | **11,685 file hashes checked, zero missing/mismatched**, `pin-check.json`. Protected Git-object declarations were read as metadata, not live ledger contents. |
| Primary real Chrome | Once, fresh output, **exit0: 71 synthetic requests, 52 callbacks, 12 records**, `primary/summary.json`. No page/server/blocked-origin/callback errors. |
| Checkpoint independent audit | **exit0**, reconstructs all 12 full raw records; **10 applied, one no-op, one stale; 37 created, five updated, zero deleted, seven derived entries**. `audit.log`, `audit.json`. |
| Additional independent raw check | Python implementation recomputes each pre/post hash, enforces nonoverlapping pointers, reconstructs each full post, and checks omission/default separation. `independent-raw-check.json`. |
| Required-assertion falsifier | Fresh output with `M7_FALSIFY_TYPED_ASSERTION=1`, **exit1**. Exact `First actual typed read is empty: 0 !== 1` surfaces in the outside callback assertion. `falsifier.log`. |
| Plugin focused tests | **32 passed / 3 files**: root-state, root-node, native-input. |
| Host focused tests | **18 passed / 2 files**: typed-state and transition recorder. |
| App focused tests | **31 passed / 2 files**: reconciliation and provider-admission. |
| Aggregate safety discriminator | **Fails**, as detailed above. This failure is retained and not treated as a green result. |

All units/offline audits/discriminators used target `deny-network.sb`. The only Chrome runs were the requested primary and required negative falsifier, under target loopback-only. No reported broad 66-task portfolio, legacy browser campaign or prior red run is claimed as independently replayed here.

## What the inspected implementation and successful probes establish

### Native inputs and raw/default distinction

`root-state.ts:27-49` uses each exact Petrinaut native schema with the existing envelope, preserving metadata after composition. The six new exports are checked against the **canonical owner**, not merely against themselves (`test/root-state.test.ts:90-108`). Canonical optional `parameterOverrides` remains optional in input JSON Schema; executable native validation supplies the canonical default.

`parseObservedStateInput` validates without substituting the parsed/defaulted object for raw input. `stateMutationTarget` selects authored fields from that raw request. The recorder compares the canonical parsed execution projection for state operations (`website/.../transition-record.ts:85-96`), rather than requiring raw omission to equal callback normalization; changed nondefault fields still fail before execution.

Actual admitted history and transition request omit `parameterOverrides`; canonical post has `{}` and that field is derived. The additional independent raw check also searches actual captured native serialized historical `tool_use` inputs for `typed-scenario` and confirms every encountered input omits the key. The host test explicitly exercises raw omission → canonical parsed callback `{}` → observed post `{}`, while a forged name fails without a callback. Explicit authored `{}` is separately tested as direct. No schema copy, manual default/backfill, mutation of historical input or relaxed base hash is involved.

### Actual effects, migration and leaf explanation

Expected detached footprints invoke canonical owning actions rather than copied migration logic. Actual browser pre/post observations remain independently hashed and compared to the complete expected definition. `deriveNodeEffects` partitions new scenario containers/entities, nested element fields and cell-level diffs without overlapping parent/child effects. Raw omitted defaults, migrated cells and generated/sanitized kernel fields are derived. Applying all effect entries reconstructs every complete actual post in both the supplied audit and the independent Python check.

The actual sequence appends the boolean attribute, migrates two false cells, converts the string attribute to integer with two canonical migrated cells, and explicitly changes only two initial-state cells. The generated transition kernel and later place-induced kernel sanitization supply two further actual derived entries; together with the omitted scenario default this yields seven. Leaf migrated/default/kernel why refusals work; explicit changed leaf-cell correction selects its second-revision cause. These working leaves do not neutralize the aggregate blocker.

### Identity, bases, host and controls

Every admitted mutation still requires a settled basis and prior verified full read/exact raw hash via existing ChatAgent wiring. New type/element/scenario guards check root/nested identities against verified current/history data, reject unearned nested/component/code/ad-hoc footprints, and validate references to existing places/parameters. Type-element identity is parent-scoped; row/cell paths are explicitly positional values, not token continuity.

Actual mixed proposals for all six new names, a multiple-browser proposal, duplicates, missing/retired element, no-op, stale after UI deletion, duplicate-result replay, foreign/conflicting results and external why refusal cross the existing controls without extra mutation results. Candidate standalone derived-arc preflight runs before callback only when an observation-bound request is present; focused host proof checks unchanged live hash and zero callback calls. Legacy callback/error behavior remains covered by existing recorder tests; no new actual-browser standalone-derived-arc success is claimed.

### Reopen, presentation and oracle honesty

Raw full reopened state matches the last applied definition modulo object-key order, retaining distinct raw hashes and without aliasing mutation bases. Screenshot `primary/reopened-positive-why.png` was inspected: actual TEST workpiece and structured why, named type and connected net are visible. Minimal panel polish/overlap remains outside this review. Positive labels still denote partially-supported operation-level/revision-local linkage, not elicited evidence or useful coverage.

The new primary wraps response callbacks, increments only after assertions, records/rethrows failures and checks callback errors outside the faux boundary; final count52 is asserted outside. Falsification independently proves the required first-read assertion reaches a failing process. Normalization/default assertions, full record checks and native schema checks also execute outside callbacks. The primary misses the aggregate query discriminator, rather than falsely passing a failed leaf assertion.

Post-correction compilation output is the exact canonical clean diagnostic string. This establishes compilation only, not scenario execution, simulation, behavioral rules, meaningful inventory/rates or semantic utility. Expected admission/foreign/conflict failure stack traces and the SQLite experimental warning remain in the raw logs.

## Remaining limits

No general removal/epoch/move, parameter, additional arc-type/connectivity, code/ad-hoc scenario, nested net/component, layout/title or full primitive-conversion portfolio is earned. Broader source/evidence/Voice/Stop/runtime/accounting/process-retention regressions retain prior bounds; no new paid/provider/genuine/utility or mission/lane acceptance is made. The present blocker is in deterministic explanation selection for newly admitted aggregate state queries, not a claim that the mechanical schema/migration/browser records failed.

## Commands and artifacts

All commands targeted the new typed worktree. Logs and separate exit files are retained.

```sh
R=/Users/lunelson/.herdr/worktrees/hash/m7-typed-state
O=/tmp/m7-typed-review.WjrqZt
E=libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/native-local-delivery
cd "$R"
git status --short
git rev-parse HEAD
git diff dd748a4239 3b98cb287275c60c45087e4dc2500f626a39f163 -- apps libs/@hashintel/brunch-agent/packages > "$O/exact.diff"
git diff --word-diff=plain dd748a4239 3b98cb287275c60c45087e4dc2500f626a39f163 -- apps libs/@hashintel/brunch-agent/packages > "$O/semantic.diff"
node "$E/verify-network-guard.mjs" > "$O/guard.log" 2>&1

cd "$R/apps/brunch-agent"
M7_TYPED_STATE_OUTPUT="$O/primary" sandbox-exec -f "../../$E/loopback-only.sb" node --experimental-strip-types test/typed-state.integration.ts > "$O/primary.log" 2>&1
M7_TYPED_STATE_OUTPUT="$O/falsifier" M7_FALSIFY_TYPED_ASSERTION=1 sandbox-exec -f "../../$E/loopback-only.sb" node --experimental-strip-types test/typed-state.integration.ts > "$O/falsifier.log" 2>&1
sandbox-exec -f "../../$E/deny-network.sb" node ../../node_modules/vitest/vitest.mjs run --config vitest.config.ts test/reconciliation.test.ts test/provider-admission.test.ts > "$O/app-tests.log" 2>&1

cd "$R"
sandbox-exec -f "$E/deny-network.sb" node libs/@hashintel/brunch-agent/docs/evidence/implementations/fe-1573-step-a/typed-state-checkpoint/audit.mjs "$O/primary" "$O/audit.json" > "$O/audit.log" 2>&1
sandbox-exec -f "$R/$E/deny-network.sb" node --experimental-strip-types "$O/aggregate-why.mjs" > "$O/aggregate-why.log" 2>&1

cd "$R/libs/@hashintel/brunch-agent/packages/plugin-sdcpn"
sandbox-exec -f ../../docs/evidence/implementations/fe-1573-step-a/native-local-delivery/deny-network.sb node ../../../../../node_modules/vitest/vitest.mjs run test/root-state.test.ts test/root-node.test.ts test/native-input.test.ts > "$O/plugin-tests.log" 2>&1

cd "$R/apps/petrinaut-website"
sandbox-exec -f "../../$E/deny-network.sb" node ../../node_modules/vitest/vitest.mjs run src/main/app/local-storage-demo/typed-state.test.ts src/main/app/local-storage-demo/transition-record.test.ts > "$O/host-tests.log" 2>&1
```

Read-only Python recursively checked source/build/runtime manifest hashes and independently recomputed hashes/reconstructed actual effects/checked native omission. `production.diff` is the focused app/host/normalization/effect exact diff. `aggregate-why.mjs` is retained in full and imports actual production code, with outputs from this review's untouched captured history. `final-status.txt`/`final-head.txt` confirm repository state. No correction or integration action was taken.
